"""
Fluxo LangGraph — Consulta de Dúvidas para Profissionais de Saúde

Permite que médicos, enfermeiros, psicólogos e outros profissionais do
hospital façam perguntas clínicas especializadas em saúde da mulher e
recebam respostas fundamentadas em evidências, protocolos do MS/FEBRASGO/
INCA e boas práticas clínicas.

Fluxo de nós:
    1. classify_question   → categoriza a dúvida por tema e complexidade
    2. retrieve_context    → monta contexto clínico relevante
    3. generate_answer     → gera resposta fundamentada
    4. add_references      → anexa referências e guidelines
    5. audit_log_qa        → registra para auditoria educacional
"""

from __future__ import annotations

import logging
from datetime import datetime
from enum import Enum
from typing import Annotated, TypedDict, Optional, Literal

from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enumerações do módulo
# ---------------------------------------------------------------------------

class QuestionCategory(str, Enum):
    GYNECOLOGY        = "ginecologia"
    OBSTETRICS        = "obstetricia"
    ONCOLOGY          = "oncologia"
    DOMESTIC_VIOLENCE = "violencia_domestica"
    MENTAL_HEALTH     = "saude_mental"
    PREVENTIVE        = "preventivo_rastreamento"
    PHARMACOLOGY      = "farmacologia"
    PROCEDURES        = "procedimentos"
    GENERAL           = "geral"


class ComplexityLevel(str, Enum):
    SIMPLE   = "simples"    # resposta direta, protocolo claro
    MODERATE = "moderada"   # requer contextualização clínica
    COMPLEX  = "complexa"   # requer raciocínio multidisciplinar / revisão de evidências


# ---------------------------------------------------------------------------
# Estado do fluxo
# ---------------------------------------------------------------------------

class ProfessionalQAState(TypedDict):
    messages: Annotated[list, add_messages]
    # Identificação
    professional_id: str          # CRM / identificador do profissional
    professional_role: str        # especialidade (ginecologia, enfermagem, etc.)
    question_id: str              # UUID da dúvida
    # Pergunta
    question_text: str
    patient_context: Optional[str]   # contexto clínico anonimizado, se informado
    # Classificação
    category: Optional[QuestionCategory]
    complexity: Optional[ComplexityLevel]
    keywords: list[str]
    # Resposta
    clinical_context: Optional[str]
    answer: Optional[str]
    references: list[dict]           # [{source, year, recommendation}]
    caveats: list[str]               # alertas e limitações da resposta
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _log(state: dict, step: str, details: dict = None) -> list[dict]:
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "step": step,
        "professional_hash": hash(state.get("professional_id", "")),
        **(details or {}),
    }
    return state.get("audit_log", []) + [entry]


# ---------------------------------------------------------------------------
# Bases de conhecimento embutidas (mock — em produção: RAG sobre guidelines)
# ---------------------------------------------------------------------------

KEYWORD_CATEGORY_MAP: dict[str, QuestionCategory] = {
    # Ginecologia
    "endometriose": QuestionCategory.GYNECOLOGY,
    "mioma": QuestionCategory.GYNECOLOGY,
    "ovário": QuestionCategory.GYNECOLOGY,
    "cisto": QuestionCategory.GYNECOLOGY,
    "corrimento": QuestionCategory.GYNECOLOGY,
    "dispareunia": QuestionCategory.GYNECOLOGY,
    "menstruação": QuestionCategory.GYNECOLOGY,
    "menopausa": QuestionCategory.GYNECOLOGY,
    "anticoncepção": QuestionCategory.PHARMACOLOGY,
    "anticoncepcional": QuestionCategory.PHARMACOLOGY,
    # Obstetrícia
    "gestação": QuestionCategory.OBSTETRICS,
    "gravidez": QuestionCategory.OBSTETRICS,
    "pré-eclâmpsia": QuestionCategory.OBSTETRICS,
    "eclâmpsia": QuestionCategory.OBSTETRICS,
    "trabalho de parto": QuestionCategory.OBSTETRICS,
    "amamentação": QuestionCategory.OBSTETRICS,
    "puerpério": QuestionCategory.OBSTETRICS,
    # Oncologia
    "câncer": QuestionCategory.ONCOLOGY,
    "tumor": QuestionCategory.ONCOLOGY,
    "mamografia": QuestionCategory.ONCOLOGY,
    "papanicolau": QuestionCategory.PREVENTIVE,
    "rastreamento": QuestionCategory.PREVENTIVE,
    # Violência
    "violência": QuestionCategory.DOMESTIC_VIOLENCE,
    "abuso": QuestionCategory.DOMESTIC_VIOLENCE,
    "notificação compulsória": QuestionCategory.DOMESTIC_VIOLENCE,
    # Saúde mental
    "depressão": QuestionCategory.MENTAL_HEALTH,
    "ansiedade": QuestionCategory.MENTAL_HEALTH,
    "psiquiátrico": QuestionCategory.MENTAL_HEALTH,
    "suicídio": QuestionCategory.MENTAL_HEALTH,
}

# Biblioteca de respostas clínicas estruturadas por categoria
# Em produção: substituir por RAG (Retrieval-Augmented Generation) sobre corpus de guidelines
CLINICAL_KNOWLEDGE: dict[QuestionCategory, dict] = {
    QuestionCategory.GYNECOLOGY: {
        "context": (
            "Área: Ginecologia Geral | Referências: FEBRASGO, UpToDate, Protocolos MS"
        ),
        "base_caveats": [
            "A resposta é de caráter orientativo; adaptar à clínica individual da paciente.",
            "Em casos de dúvida diagnóstica, valorizar exame físico e exames complementares.",
        ],
        "references": [
            {"source": "FEBRASGO — Manual de Ginecologia", "year": 2023, "recommendation": "Nível A"},
            {"source": "Ministério da Saúde — Protocolos Clínicos", "year": 2022, "recommendation": "Nível B"},
        ],
    },
    QuestionCategory.OBSTETRICS: {
        "context": (
            "Área: Obstetrícia | Referências: FEBRASGO, WHO, UpToDate, MS"
        ),
        "base_caveats": [
            "Sempre considerar idade gestacional e comorbidades maternas.",
            "Emergências obstétricas requerem avaliação presencial imediata.",
        ],
        "references": [
            {"source": "FEBRASGO — Assistência Pré-Natal", "year": 2023, "recommendation": "Nível A"},
            {"source": "WHO Recommendations for Antenatal Care", "year": 2023, "recommendation": "Nível A"},
            {"source": "MS — Cadernos de Atenção Básica n.32", "year": 2022, "recommendation": "Nível B"},
        ],
    },
    QuestionCategory.ONCOLOGY: {
        "context": (
            "Área: Oncologia Ginecológica | Referências: INCA, SBM, FEBRASGO"
        ),
        "base_caveats": [
            "Estadiamento e decisão terapêutica devem ser multidisciplinares.",
            "Rastreamento segue protocolos do INCA conforme faixa etária e risco.",
        ],
        "references": [
            {"source": "INCA — Controle do Câncer do Colo do Útero", "year": 2023, "recommendation": "Nível A"},
            {"source": "SBM — Diretrizes de Mastologia", "year": 2023, "recommendation": "Nível A"},
        ],
    },
    QuestionCategory.DOMESTIC_VIOLENCE: {
        "context": (
            "Área: Violência Doméstica e Sexual | Referências: MS, OMS, Lei Maria da Penha"
        ),
        "base_caveats": [
            "Notificação compulsória obrigatória (SINAN) conforme Lei 10.778/2003.",
            "Abordagem deve ser feita em ambiente seguro, sem o acompanhante.",
            "Não confrontar nem questionar a veracidade do relato da paciente.",
        ],
        "references": [
            {"source": "MS — Atenção Integral às Mulheres em Situação de Violência", "year": 2022, "recommendation": "Protocolo Obrigatório"},
            {"source": "Lei Maria da Penha — Lei 11.340/2006", "year": 2006, "recommendation": "Legislação"},
            {"source": "OMS — Responding to intimate partner violence", "year": 2023, "recommendation": "Nível A"},
        ],
    },
    QuestionCategory.MENTAL_HEALTH: {
        "context": (
            "Área: Saúde Mental na Mulher | Referências: CFM, CFP, MS, DSM-5"
        ),
        "base_caveats": [
            "Em gestantes, avaliar risco-benefício de psicofármacos cuidadosamente.",
            "Risco de suicídio requer avaliação imediata e acionamento da psiquiatria.",
        ],
        "references": [
            {"source": "MS — Saúde Mental na Atenção Básica", "year": 2023, "recommendation": "Nível B"},
            {"source": "DSM-5-TR — Critérios Diagnósticos", "year": 2022, "recommendation": "Referência Diagnóstica"},
        ],
    },
    QuestionCategory.PREVENTIVE: {
        "context": (
            "Área: Prevenção e Rastreamento | Referências: INCA, USPSTF, MS"
        ),
        "base_caveats": [
            "Protocolos de rastreamento consideram faixa etária e fatores de risco individuais.",
            "Comunicar resultados alterados com linguagem acessível e plano de seguimento claro.",
        ],
        "references": [
            {"source": "INCA — Rastreamento Câncer Colo e Mama", "year": 2023, "recommendation": "Nível A"},
            {"source": "USPSTF Recommendations", "year": 2023, "recommendation": "Grau B"},
        ],
    },
    QuestionCategory.PHARMACOLOGY: {
        "context": (
            "Área: Farmacologia Ginecológico-Obstétrica | Referências: RENAME, FEBRASGO, FDA"
        ),
        "base_caveats": [
            "Sempre verificar categoria de risco na gestação (FDA) antes de prescrever.",
            "Interações medicamentosas devem ser checadas em bases atualizadas (Micromedex).",
            "Dosagem pode variar conforme função renal/hepática.",
        ],
        "references": [
            {"source": "RENAME 2023 — Relação Nacional de Medicamentos Essenciais", "year": 2023, "recommendation": "Protocolo MS"},
            {"source": "FEBRASGO — Farmacologia na Gestação", "year": 2023, "recommendation": "Nível B"},
        ],
    },
    QuestionCategory.PROCEDURES: {
        "context": (
            "Área: Procedimentos Ginecológico-Obstétricos | Referências: FEBRASGO, CFM"
        ),
        "base_caveats": [
            "Consentimento informado obrigatório antes de qualquer procedimento.",
            "Indicações e contraindicações devem seguir resolução CFM vigente.",
        ],
        "references": [
            {"source": "FEBRASGO — Manuais de Procedimentos", "year": 2023, "recommendation": "Consenso"},
            {"source": "CFM — Resoluções Vigentes", "year": 2024, "recommendation": "Obrigatório"},
        ],
    },
    QuestionCategory.GENERAL: {
        "context": "Área: Saúde da Mulher — Geral",
        "base_caveats": [
            "Resposta de caráter geral; individualizar conforme quadro clínico.",
        ],
        "references": [
            {"source": "UpToDate — Gynecology & Obstetrics", "year": 2024, "recommendation": "Evidência atual"},
            {"source": "MS — Protocolos Clínicos e Diretrizes Terapêuticas", "year": 2023, "recommendation": "Nível B"},
        ],
    },
}

# Respostas clínicas detalhadas por tópico-chave
TOPIC_ANSWERS: dict[str, str] = {
    "pré-eclâmpsia": """
**Pré-eclâmpsia — Resumo Clínico para Equipe**

**Diagnóstico:** PA ≥ 140×90 mmHg em 2 aferições com intervalo ≥ 4h após 20ª semana, associada a:
- Proteinúria ≥ 300mg/24h ou relação P/Cr ≥ 0,3, OU
- Sinais de gravidade (sem exigência de proteinúria):
  PA ≥ 160×110, trombocitopenia (<100k), disfunção hepática, IRA, EAP, sintomas neurológicos.

**Conduta geral:**
- Internação em PE grave
- Sulfato de magnésio (MgSO4): 4-6g IV ataque → 1-2g/h manutenção (profilaxia eclâmpsia)
- Anti-hipertensivo: Hidralazina 5-10mg IV ou Nifedipino 10mg VO em emergência hipertensiva
- Resolução da gestação: individualizar conforme IG e gravidade (≥37s: parto; <34s: corticoide + avaliação)

**Monitorização:** diurese, reflexos patelares, magnésio sérico, sinais de toxicidade (hiporreflexia, FR <12).
""",

    "endometriose": """
**Endometriose — Abordagem Clínica**

**Suspeita diagnóstica:** dismenorreia progressiva, dispareunia profunda, infertilidade, dor pélvica crônica.
O diagnóstico definitivo é cirúrgico (laparoscopia + histopatológico), mas a USG transvaginal pode identificar endometriomas.

**Estadiamento:** ASRM I-IV (mínima a grave).

**Tratamento:**
- Hormonal 1ª linha: progestágenos (dienogeste 2mg/dia), ACO contínuo, DIU levonorgestrel
- Analgesia: AINEs no período menstrual
- Cirúrgico: indicado em endometriomas ≥4cm, falha clínica, infertilidade
- Análogos GnRH: uso limitado a 6 meses por efeitos adversos ósseos; add-back therapy recomendado

**Rastreamento de CA-125:** elevado em ~80% dos casos moderados-graves, mas não específico para diagnóstico.
""",

    "anticoncepção": """
**Anticoncepção — Guia Rápido para Prescrição**

**Método hormonal combinado (estrogênio + progestogênio):**
- ACO: eficácia >99% com uso correto; contraindicado em tabagistas >35a, migrânea com aura, TEV, amamentação <6m
- Anel vaginal (NuvaRing): inserção mensal, mesmas contraindicações do ACO
- Adesivo transdérmico: troca semanal (3 semanas + 1 sem pausa)

**Método só progestogênio (OMS Cat. 1 para maioria das situações):**
- Minipílula (desogestrel 75mcg): opção na amamentação, migrânea com aura, HAS
- Injetável trimestral (DMPA): boa opção para aderência difícil; impacto na DMO com uso prolongado
- DIU hormonal (LNG): altamente eficaz, reduz fluxo, pode induzir amenorreia
- Implante subdérmico (etonogestrel): >99,9% eficácia, 3 anos

**DIU de cobre:** não hormonal, 10 anos, também usado como contracepção de emergência até 5 dias após relação.

**Contracepção de emergência:**
- Levonorgestrel 1,5mg: até 72h (eficaz até 120h com menor eficácia)
- UPA (acetato de ulipristal): até 120h, superior ao LNG especialmente 72-120h
""",

    "notificação compulsória": """
**Notificação Compulsória de Violência — Obrigações do Profissional**

**Base legal:** Lei 10.778/2003 — obrigatória para qualquer suspeita ou confirmação de violência contra a mulher.

**O que notificar:** violência física, sexual, psicológica, negligência — em todos os ciclos de vida.

**Como notificar:**
1. Ficha de Notificação/Investigação de Violência Interpessoal (SINAN)
2. Encaminhar à vigilância epidemiológica do município
3. Quando envolve criança/adolescente: comunicar ao Conselho Tutelar (ECA, art. 13)
4. Quando há risco iminente: acionar segurança e serviço social do hospital

**Documentação no prontuário:**
- Descrever objetivamente os achados clínicos (sem julgamentos)
- Fotografar lesões com consentimento
- Anotar relato da paciente entre aspas
- Prontuário restrito / sigilo reforçado

**Importante:** a notificação NÃO depende do consentimento da vítima.
""",

    "amamentação": """
**Amamentação — Orientações Clínicas**

**Benefícios:** redução de infecções no RN, otimização do neurodesenvolvimento, redução do risco de câncer de mama na mãe.

**AME recomendado:** até 6 meses exclusivo (OMS/MS); complementar até 2 anos ou mais.

**Pega correta:** boca bem aberta, aréola incluída, lábios evertidos, sem dor após os primeiros dias.

**Complicações comuns:**
- Ingurgitamento: amamentar frequentemente, compressas mornas antes e frias após
- Fissuras: verificar pega; lanolina pura; não suspender AME
- Mastite: antibiótico (cefalexina 500mg 6/6h por 10-14 dias); NÃO suspender AME
- Abscesso: drenagem + antibiótico; suspender mama afetada temporariamente

**Medicamentos compatíveis com AME:** paracetamol, ibuprofeno, cefalosporinas, amoxicilina, metronidazol (dose única).

**Contraindicações absolutas:** HIV+ (no Brasil), HTLV, galactosemia no RN, uso de quimioterápicos ou amiodarona.
""",

    "menopausa": """
**Menopausa — Manejo Clínico**

**Diagnóstico:** amenorreia ≥12 meses sem outra causa, após 40 anos. FSH >40 UI/L confirma falência ovariana.

**Sintomas vasomotores:**
- 1ª linha: Terapia Hormonal da Menopausa (THM) — mais eficaz
- Alternativas não hormonais: paroxetina 7,5-20mg/dia, venlafaxina 37,5-75mg/dia, gabapentina

**THM — indicação e contraindicações:**
- Indicada em sintomas moderados-graves com QV prejudicada, sem contraindicações
- Contraindicações: CA mama ou endométrio ativo, TEV, DCV recente, hepatopatia grave
- Iniciar preferencialmente até 10 anos da menopausa (janela de oportunidade)
- Via transdérmica: menor risco trombótico vs. oral

**Saúde óssea:**
- Densitometria: 65 anos (sem FR) ou 60 anos (com FR) ou qualquer idade pós-fratura
- Osteopenia/osteoporose: suplementação Ca + vit D + avaliação de bifosfonatos

**Genitourinário:** estriol tópico vaginal é seguro mesmo em CA mama em uso de IA (discutir com oncologista).
""",
}


# ---------------------------------------------------------------------------
# Nós do grafo
# ---------------------------------------------------------------------------

def classify_question(state: ProfessionalQAState) -> ProfessionalQAState:
    """Nó 1 — Categoriza a dúvida por tema e complexidade."""
    question = state["question_text"].lower()

    # Detectar categoria por palavras-chave
    detected_category = QuestionCategory.GENERAL
    detected_keywords: list[str] = []

    for keyword, category in KEYWORD_CATEGORY_MAP.items():
        if keyword in question:
            detected_category = category
            detected_keywords.append(keyword)

    # Avaliar complexidade pelo tamanho e termos técnicos
    word_count = len(question.split())
    has_patient_context = bool(state.get("patient_context"))
    technical_terms = ["protocolo", "conduta", "dose", "contraindicação", "diagnóstico diferencial",
                       "estadiamento", "manejo", "prognóstico", "comorbidade"]
    technical_count = sum(1 for t in technical_terms if t in question)

    if technical_count >= 2 or (has_patient_context and word_count > 30):
        complexity = ComplexityLevel.COMPLEX
    elif technical_count == 1 or word_count > 15:
        complexity = ComplexityLevel.MODERATE
    else:
        complexity = ComplexityLevel.SIMPLE

    logger.info(
        f"QA Profissional [{state['question_id']}]: categoria={detected_category.value}, "
        f"complexidade={complexity.value}, keywords={detected_keywords}"
    )

    return {
        **state,
        "category": detected_category,
        "complexity": complexity,
        "keywords": detected_keywords,
        "current_step": "classified",
        "audit_log": _log(state, "classify_question", {
            "category": detected_category.value,
            "complexity": complexity.value,
            "keyword_count": len(detected_keywords),
        }),
    }


def retrieve_context(state: ProfessionalQAState) -> ProfessionalQAState:
    """Nó 2 — Recupera contexto clínico relevante para a categoria."""
    category = state.get("category", QuestionCategory.GENERAL)
    knowledge = CLINICAL_KNOWLEDGE.get(category, CLINICAL_KNOWLEDGE[QuestionCategory.GENERAL])

    # Contexto base da categoria
    context_parts = [knowledge["context"]]

    # Acrescentar contexto do paciente (anonimizado), se fornecido
    if state.get("patient_context"):
        context_parts.append(f"\n📋 Contexto clínico informado pelo profissional:\n{state['patient_context']}")

    # Acrescentar contexto da especialidade do profissional
    role = state.get("professional_role", "")
    if role:
        context_parts.append(f"\n👤 Solicitante: {role}")

    clinical_context = "\n".join(context_parts)

    return {
        **state,
        "clinical_context": clinical_context,
        "references": knowledge["references"],
        "caveats": knowledge["base_caveats"],
        "current_step": "context_retrieved",
        "audit_log": _log(state, "retrieve_context", {"category": category.value}),
    }


def generate_answer(state: ProfessionalQAState) -> ProfessionalQAState:
    """Nó 3 — Gera resposta clínica estruturada."""
    question = state["question_text"].lower()
    category = state.get("category", QuestionCategory.GENERAL)
    complexity = state.get("complexity", ComplexityLevel.SIMPLE)
    keywords = state.get("keywords", [])

    # Tentar resposta específica por tópico
    answer = None
    for topic, topic_answer in TOPIC_ANSWERS.items():
        if topic in question or topic in keywords:
            answer = topic_answer
            break

    # Fallback: resposta estruturada genérica por categoria
    if not answer:
        category_summaries = {
            QuestionCategory.GYNECOLOGY: (
                "Para dúvidas ginecológicas específicas, consulte os Manuais FEBRASGO (2023) e as "
                "Diretrizes do Ministério da Saúde. Avalie: anamnese dirigida (ciclo menstrual, "
                "atividade sexual, contraceptivos), exame especular + colposcopia se indicado, "
                "US transvaginal como exame de imagem de primeira linha."
            ),
            QuestionCategory.OBSTETRICS: (
                "Na assistência pré-natal, siga o Caderno de Atenção Básica nº 32 (MS) e os "
                "protocolos FEBRASGO. Identifique risco gestacional na primeira consulta, estratifique "
                "e encaminhe ao serviço de referência conforme nível de complexidade."
            ),
            QuestionCategory.PREVENTIVE: (
                "Para rastreamento: Papanicolau — 25 a 64 anos, anualmente (INCA). Mamografia — "
                "40 a 74 anos, anualmente (FEBRASGO). Densitometria óssea — ≥65 anos ou ≥60 anos "
                "com FR. Ajustar conforme histórico familiar e risco individual."
            ),
            QuestionCategory.MENTAL_HEALTH: (
                "Aplique rastreamento sistemático: PHQ-9 para depressão, GAD-7 para ansiedade. "
                "Em gestantes, considerar psicoterapia como primeira linha. Psicofármacos: "
                "sertralina e fluoxetina têm maior segurança na gestação. Sempre envolver "
                "psicologia e psiquiatria nos casos complexos."
            ),
            QuestionCategory.PHARMACOLOGY: (
                "Consulte a RENAME 2023 e o SCTIE/MS para protocolos terapêuticos. "
                "Na gestação, verificar categoria FDA; preferir medicamentos Categoria A ou B. "
                "Na amamentação, consultar LactMed (NIH) para verificar compatibilidade."
            ),
            QuestionCategory.DOMESTIC_VIOLENCE: (
                "Siga o Protocolo MS de Atenção Integral à Mulher em Situação de Violência. "
                "Notificação compulsória via SINAN. Acionar assistente social. Documentar "
                "objetivamente os achados. Oferecer profilaxia IST e contracepção de emergência "
                "em casos de violência sexual."
            ),
            QuestionCategory.GENERAL: (
                "Consulte as diretrizes FEBRASGO, protocolos do Ministério da Saúde e UpToDate "
                "para embasamento em evidências atualizadas. Para dúvidas específicas de conduta, "
                "detalhe o quadro clínico para uma resposta mais precisa."
            ),
        }
        answer = category_summaries.get(category, category_summaries[QuestionCategory.GENERAL])

    # Adicionar nota de complexidade
    if complexity == ComplexityLevel.COMPLEX:
        answer += (
            "\n\n⚠️ **Caso complexo:** recomenda-se discussão multidisciplinar e/ou "
            "consulta com especialista de referência antes de definir conduta."
        )

    return {
        **state,
        "answer": answer,
        "current_step": "answer_generated",
        "audit_log": _log(state, "generate_answer", {
            "complexity": complexity.value,
            "answer_length": len(answer),
        }),
    }


def add_references(state: ProfessionalQAState) -> ProfessionalQAState:
    """Nó 4 — Formata referências e produz a resposta final completa."""
    answer = state.get("answer", "")
    references = state.get("references", [])
    caveats = state.get("caveats", [])

    # Montar resposta formatada completa
    final_parts = [answer]

    if caveats:
        final_parts.append("\n\n---\n**⚠️ Alertas importantes:**")
        final_parts.extend(f"- {c}" for c in caveats)

    if references:
        final_parts.append("\n\n**📚 Referências:**")
        final_parts.extend(
            f"- {r['source']} ({r['year']}) — {r['recommendation']}"
            for r in references
        )

    final_parts.append(
        "\n\n*Esta resposta tem caráter educativo e de suporte à decisão clínica. "
        "Não substitui o julgamento clínico individualizado nem a consulta às fontes primárias.*"
    )

    full_response = "\n".join(final_parts)

    return {
        **state,
        "current_step": "references_added",
        "audit_log": _log(state, "add_references", {"ref_count": len(references)}),
        "messages": state["messages"] + [AIMessage(content=full_response)],
    }


def audit_log_qa(state: ProfessionalQAState) -> ProfessionalQAState:
    """Nó 5 — Finaliza com registro de auditoria educacional."""
    logger.info(
        f"QA concluída [{state['question_id']}] | "
        f"Profissional: {hash(state['professional_id'])} | "
        f"Categoria: {state.get('category', 'N/A')} | "
        f"Complexidade: {state.get('complexity', 'N/A')}"
    )
    return {
        **state,
        "current_step": "completed",
        "audit_log": _log(state, "audit_finalized", {
            "question_id": state["question_id"],
            "category": state.get("category", QuestionCategory.GENERAL).value
            if state.get("category") else "geral",
            "status": "completed",
        }),
    }


# ---------------------------------------------------------------------------
# Construtor do grafo
# ---------------------------------------------------------------------------

def build_professional_qa_graph() -> StateGraph:
    """Constrói e compila o grafo de dúvidas de profissionais."""
    graph = StateGraph(ProfessionalQAState)

    graph.add_node("classify_question", classify_question)
    graph.add_node("retrieve_context", retrieve_context)
    graph.add_node("generate_answer", generate_answer)
    graph.add_node("add_references", add_references)
    graph.add_node("audit_log_qa", audit_log_qa)

    graph.set_entry_point("classify_question")
    graph.add_edge("classify_question", "retrieve_context")
    graph.add_edge("retrieve_context", "generate_answer")
    graph.add_edge("generate_answer", "add_references")
    graph.add_edge("add_references", "audit_log_qa")
    graph.add_edge("audit_log_qa", END)

    return graph.compile(checkpointer=MemorySaver())
