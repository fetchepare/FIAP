"""
Orquestrador Unificado de Intake — Saúde da Mulher
===================================================

Fluxo mestre que, ao receber os dados de uma paciente em uma única entrada,
percorre automaticamente e em sequência as seguintes etapas:

    ETAPA 1 — verify_pending_exams
        Verifica exames ginecológicos pendentes (papanicolau, mamografia,
        densitometria, sorologias) com base no perfil e histórico.

    ETAPA 2 — screen_reproductive_needs
        Avalia queixas reprodutivas e sugere linha terapêutica adequada,
        considerando desejo de gestar, comorbidades e sensibilidades.

    ETAPA 3 — detect_vd_signals  [CONDICIONAL]
        Analisa notas de consulta em busca de sinais físicos, comportamentais
        e contextuais de violência doméstica. Se detectados → aciona protocolo
        e escala automaticamente a urgência.

    ETAPA 4 — coordinate_team  [CONDICIONAL]
        Se VD detectada, emergência obstétrica, ou caso complexo → monta
        automaticamente o plano de atendimento multidisciplinar com
        Ginecologista, Psicóloga e Assistente Social.

    ETAPA 5 — compile_summary
        Consolida todas as etapas num sumário clínico estruturado, pronto
        para o prontuário.

Cada etapa é executada de forma independente — uma falha não bloqueia as
demais. O grafo usa arestas condicionais para decidir em tempo real se
ETAPA 3 e ETAPA 4 são necessárias.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Annotated, TypedDict, Optional, Literal

from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


# ===========================================================================
# Estado unificado
# ===========================================================================

class IntakeState(TypedDict):
    """Estado compartilhado por todas as etapas do fluxo de intake."""
    messages: Annotated[list, add_messages]

    # ── Entrada ─────────────────────────────────────────────────────────────
    patient_id: str
    professional_id: str
    intake_id: str                   # UUID da sessão de intake

    # Dados da paciente
    patient_name: str                # só para exibição — não persiste em logs
    age: int
    consultation_notes: str          # notas livres da consulta atual
    reproductive_complaint: str      # queixa reprodutiva em texto livre
    wants_to_conceive: bool
    hormone_contraindication: bool
    comorbidities: list[str]
    previous_treatments: list[str]
    children_in_household: bool

    # Histórico de exames (datas, None = nunca realizado)
    last_papanicolau: Optional[str]
    last_mammography: Optional[str]
    last_bone_density: Optional[str]
    last_hiv_test: Optional[str]
    last_hepatitis_b: Optional[str]
    family_history: list[str]

    # ── Resultados por etapa ─────────────────────────────────────────────────
    # Etapa 1
    pending_exams: list[dict]        # [{exam, reason, urgency, guideline}]
    exam_summary: Optional[str]

    # Etapa 2
    reproductive_condition: Optional[str]
    treatment_suggestion: Optional[str]
    non_pharmacological: list[str]
    referrals: list[str]
    sensitivity_notes: list[str]

    # Etapa 3
    vd_detected: bool
    vd_alert_level: Optional[str]   # CRITICO / ALTO / MODERADO / VIGILÂNCIA / None
    vd_physical_signs: list[str]
    vd_behavioral_signs: list[str]
    vd_contextual_signs: list[str]
    vd_immediate_actions: list[str]
    vd_legal_obligations: list[str]
    vd_safety_plan: list[str]
    vd_documentation_id: Optional[str]
    sinan_required: bool

    # Etapa 4
    team_required: bool
    team_assignments: list[dict]
    followup_schedule: list[dict]
    coordination_plan: Optional[str]

    # Etapa 5
    clinical_summary: Optional[str]
    overall_urgency: str             # EMERGÊNCIA / URGÊNCIA / PRIORITÁRIO / ELETIVO
    alerts_count: int

    # ── Controle ─────────────────────────────────────────────────────────────
    current_step: str
    completed_steps: list[str]
    audit_log: list[dict]
    error: Optional[str]


# ===========================================================================
# Helpers
# ===========================================================================

def _now() -> str:
    return datetime.utcnow().isoformat()


def _audit(state: IntakeState, step: str, details: dict = None) -> list[dict]:
    entry = {
        "ts": _now(),
        "step": step,
        "intake_id": state.get("intake_id", ""),
        **(details or {}),
    }
    return state.get("audit_log", []) + [entry]


def _months_since(date_str: Optional[str]) -> Optional[float]:
    """Retorna quantos meses desde a data informada, ou None se não informada."""
    if not date_str:
        return None
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d")
        delta = datetime.utcnow() - d
        return delta.days / 30.44
    except Exception:
        return None


# ===========================================================================
# ETAPA 1 — Verificar exames ginecológicos pendentes
# ===========================================================================

EXAM_PROTOCOLS = [
    {
        "id": "papanicolau",
        "label": "Papanicolau (Colpocitologia Oncótica)",
        "guideline": "INCA — anual entre 25-64 anos; a cada 3 anos após 2 normais consecutivos",
        "overdue_months": 12,
        "age_min": 25,
        "age_max": 64,
        "urgency": "alta",
        "check_field": "last_papanicolau",
    },
    {
        "id": "mamografia",
        "label": "Mamografia",
        "guideline": "FEBRASGO — anual entre 40-74 anos; a partir de 35 se histórico familiar",
        "overdue_months": 12,
        "age_min": 40,
        "age_max": 74,
        "urgency": "alta",
        "check_field": "last_mammography",
        "family_history_trigger": ["cancer mama", "câncer mama", "ca mama"],
        "family_history_age_override": 35,
    },
    {
        "id": "densitometria",
        "label": "Densitometria Óssea",
        "guideline": "IOF/FEBRASGO — a cada 2 anos a partir de 65 anos (ou 60 com fatores de risco)",
        "overdue_months": 24,
        "age_min": 60,
        "age_max": 120,
        "urgency": "media",
        "check_field": "last_bone_density",
    },
    {
        "id": "hiv",
        "label": "Teste HIV",
        "guideline": "MS — pelo menos uma vez na vida; anual se fator de risco",
        "overdue_months": None,  # None = se nunca realizou
        "age_min": 15,
        "age_max": 120,
        "urgency": "media",
        "check_field": "last_hiv_test",
    },
    {
        "id": "hepatite_b",
        "label": "Hepatite B (Anti-HBs / HBsAg)",
        "guideline": "MS — rastreamento na gestação e populações em risco",
        "overdue_months": None,
        "age_min": 15,
        "age_max": 120,
        "urgency": "baixa",
        "check_field": "last_hepatitis_b",
    },
]


def verify_pending_exams(state: IntakeState) -> IntakeState:
    """
    ETAPA 1 — Verifica quais exames ginecológicos preventivos estão pendentes
    com base na idade, histórico familiar e datas dos últimos exames.
    """
    age = state.get("age", 0)
    family_history = [h.lower() for h in state.get("family_history", [])]
    pending: list[dict] = []

    for protocol in EXAM_PROTOCOLS:
        age_min = protocol.get("age_min", 0)
        age_max = protocol.get("age_max", 120)

        # Verificar override por histórico familiar
        if "family_history_trigger" in protocol and "family_history_age_override" in protocol:
            if any(t in family_history for t in protocol["family_history_trigger"]):
                age_min = protocol["family_history_age_override"]

        if not (age_min <= age <= age_max):
            continue

        field_val = state.get(protocol["check_field"])  # type: ignore
        months_since = _months_since(field_val)
        overdue_months = protocol.get("overdue_months")

        is_pending = False
        reason = ""

        if overdue_months is None:
            # Exame que deve ser feito pelo menos uma vez
            if field_val is None:
                is_pending = True
                reason = "Nunca realizado — recomendado ao menos uma vez"
        else:
            if field_val is None:
                is_pending = True
                reason = f"Nunca realizado — recomendado a cada {overdue_months} meses"
            elif months_since and months_since >= overdue_months:
                months_ago = round(months_since)
                is_pending = True
                reason = f"Último há {months_ago} meses — prazo recomendado: {overdue_months} meses"

        if is_pending:
            pending.append({
                "exame": protocol["label"],
                "motivo": reason,
                "urgencia": protocol["urgency"],
                "diretriz": protocol["guideline"],
            })

    # Montar sumário
    if pending:
        lines = [f"**📋 Exames Preventivos Pendentes ({len(pending)} identificados):**\n"]
        urgent = [p for p in pending if p["urgencia"] == "alta"]
        others = [p for p in pending if p["urgencia"] != "alta"]
        for p in urgent:
            lines.append(f"🔴 **{p['exame']}**\n   {p['motivo']}\n   _{p['diretriz']}_")
        for p in others:
            lines.append(f"🟡 **{p['exame']}**\n   {p['motivo']}\n   _{p['diretriz']}_")
        exam_summary = "\n".join(lines)
    else:
        exam_summary = "✅ Exames preventivos em dia — nenhum pendente identificado para o perfil desta paciente."

    logger.info(f"Intake [{state['intake_id']}] Etapa 1: {len(pending)} exame(s) pendente(s)")

    return {
        **state,
        "pending_exams": pending,
        "exam_summary": exam_summary,
        "current_step": "exams_verified",
        "completed_steps": state.get("completed_steps", []) + ["verify_exams"],
        "audit_log": _audit(state, "verify_pending_exams", {"pending_count": len(pending)}),
    }


# ===========================================================================
# ETAPA 2 — Avaliar e sugerir tratamentos reprodutivos
# ===========================================================================

# Mapa compacto de condição → tratamentos (extraído do advanced_flows para evitar import circular)
CONDITION_MAP = {
    "sop": "Síndrome dos Ovários Policísticos",
    "policístico": "Síndrome dos Ovários Policísticos",
    "endometriose": "Endometriose",
    "mioma": "Miomatose Uterina",
    "infertil": "Infertilidade",
    "engravidar": "Infertilidade",
    "fiv": "Infertilidade",
    "menopausa": "Menopausa e Climatério",
    "climatério": "Menopausa e Climatério",
    "fogacho": "Menopausa e Climatério",
    "menstruação irregular": "Distúrbio Menstrual",
    "dismenorreia": "Distúrbio Menstrual",
    "amenorreia": "Distúrbio Menstrual",
    "sangramento": "Distúrbio Menstrual",
    "abortamento": "Abortamento Recorrente",
    "aborto recorrente": "Abortamento Recorrente",
}

FIRST_LINE_TREATMENTS = {
    "Síndrome dos Ovários Policísticos": {
        True:  ["Indução ovulação: citrato de clomifeno 50-150mg D2-D6", "Metformina adjuvante", "Perda de peso prioritária"],
        False: ["AOC (etinilestradiol + progestogênio)", "Metformina 500-2000mg/dia", "Mudança de estilo de vida"],
    },
    "Endometriose": {
        True:  ["Avaliação reserva ovariana (AMH)", "Cirurgia se endometrioma ≥4cm", "FIV em casos moderados-graves"],
        False: ["Dienogeste 2mg/dia", "AOC contínuo", "DIU de levonorgestrel", "AINEs perimenstrual"],
    },
    "Miomatose Uterina": {
        True:  ["Miomectomia histeroscópica/laparoscópica", "Análogos GnRH pré-op 2-3 meses"],
        False: ["DIU de levonorgestrel", "AOC ou progestogênios", "Ácido tranexâmico se sangramento agudo"],
    },
    "Infertilidade": {
        True:  ["Investigação do casal: espermograma + HSG + AMH", "Indução ovulatória se anovulação", "IUI ou FIV conforme causa"],
        False: ["N/A — condição vinculada ao desejo de conceber"],
    },
    "Menopausa e Climatério": {
        True:  ["Doação de óvulos se falência completa"],
        False: ["THM transdérmica (menor risco trombótico)", "Estriol tópico vaginal", "ISRS/IRSN se THM contraindicada"],
    },
    "Distúrbio Menstrual": {
        True:  ["Investigar causa: TSH, prolactina, FSH/LH, US", "Indução ovulatória se anovulação"],
        False: ["AOC para regularização", "AINEs para dismenorreia", "DIU de levonorgestrel se menorragia"],
    },
    "Abortamento Recorrente": {
        True:  ["Cariótipo do casal", "Pesquisa síndrome antifosfolípide", "Progesterona vaginal 200mg até 12 sem", "Suporte emocional estruturado"],
        False: ["N/A"],
    },
}

SENSITIVITY_BY_CONDITION = {
    "Infertilidade": "Abordar com empatia; incluir parceiro; oferecer suporte psicológico desde o início.",
    "Abortamento Recorrente": "Validar o luto gestacional. Evitar minimizações. Garantir acompanhamento psicológico.",
    "Endometriose": "Validar a dor — frequentemente subestimada. Respeitar o desejo reprodutivo na escolha terapêutica.",
    "Síndrome dos Ovários Policísticos": "Não responsabilizar a paciente pelo peso. Abordar alterações estéticas com sensibilidade.",
    "Menopausa e Climatério": "Desmistificar a menopausa como 'fim da vida'. Valorizar a sexualidade e qualidade de vida.",
    "Miomatose Uterina": "Respeitar o desejo de preservação uterina. Informar alternativas antes de propor cirurgia.",
    "Distúrbio Menstrual": "Validar o impacto na qualidade de vida. Não normalizar dor menstrual intensa.",
}


def screen_reproductive_needs(state: IntakeState) -> IntakeState:
    """
    ETAPA 2 — Avalia a queixa reprodutiva e sugere tratamento de primeira linha,
    considerando desejo de gestar, contraindicações e sensibilidades específicas.
    """
    complaint = state.get("reproductive_complaint", "").lower()
    wants_conceive = state.get("wants_to_conceive", False)
    hormone_ci = state.get("hormone_contraindication", False)

    # Detectar condição
    condition_name = "Queixa Reprodutiva Geral"
    for keyword, name in CONDITION_MAP.items():
        if keyword in complaint:
            condition_name = name
            break

    # Buscar tratamentos
    treatments = FIRST_LINE_TREATMENTS.get(condition_name, {}).get(wants_conceive, ["Avaliar individualmente."])

    # Filtrar hormônios se contraindicado
    if hormone_ci:
        treatments = [t for t in treatments if not any(
            w in t.lower() for w in ["aoc", "estradiol", "thm", "dienogeste", "estriol"]
        )]
        if not treatments:
            treatments = ["Contraindicação hormonal — discutir alternativas não hormonais com especialista."]

    # Montar sugestão
    desejo_label = "com desejo de gestar" if wants_conceive else "sem desejo de gestar"
    suggestion_lines = [
        f"**🌸 Condição identificada:** {condition_name}",
        f"**Contexto:** {desejo_label}",
        "",
        "**Tratamentos de primeira linha sugeridos:**",
    ] + [f"  {i+1}. {t}" for i, t in enumerate(treatments)]

    sensitivity = SENSITIVITY_BY_CONDITION.get(condition_name, "Iniciar com escuta ativa. Respeitar o tempo da paciente.")
    sensitivity_notes = [
        sensitivity,
        "Garantir privacidade e sigilo durante toda a consulta.",
        "Respeitar a autonomia da paciente nas decisões terapêuticas.",
    ]

    # Encaminhamentos padrão
    referrals = []
    if condition_name == "Infertilidade":
        referrals = ["Reprodução assistida", "Urologia/Andrologia (fator masculino)", "Psicologia"]
    elif condition_name == "Endometriose":
        referrals = ["Cirurgia minimamente invasiva", "Reprodução assistida se infertilidade associada"]
    elif condition_name in ("Menopausa e Climatério",):
        referrals = ["Cardiologia se fator de risco cardiovascular", "Reumatologia se osteoporose"]

    logger.info(f"Intake [{state['intake_id']}] Etapa 2: condição={condition_name}")

    return {
        **state,
        "reproductive_condition": condition_name,
        "treatment_suggestion": "\n".join(suggestion_lines),
        "non_pharmacological": [
            "Estilo de vida saudável (dieta, atividade física regular)",
            "Redução do estresse — impacto direto no eixo reprodutivo",
            "Suplementação de ácido fólico 400-800mcg/dia se desejo de gestar",
        ],
        "referrals": referrals,
        "sensitivity_notes": sensitivity_notes,
        "current_step": "reproductive_screened",
        "completed_steps": state.get("completed_steps", []) + ["screen_reproductive"],
        "audit_log": _audit(state, "screen_reproductive", {"condition": condition_name}),
    }


# ===========================================================================
# ETAPA 3 — Detectar sinais de violência doméstica
# ===========================================================================

PHYSICAL_SIGNS_LIST = [
    "hematoma", "equimose", "fratura", "lesão", "queimadura", "corte",
    "cicatriz", "trauma", "mordida", "estrangulamento", "marca", "roxo",
    "lesão genital", "costela", "ruptura timpânica",
]

BEHAVIORAL_SIGNS_LIST = [
    "evasiva", "nervosa", "medo", "choro", "contradição",
    "acompanhante fala", "não mantém contato", "submissa", "tremendo",
    "surpresa com gentileza", "ansiedade extrema", "não consegue responder",
]

CONTEXTUAL_SIGNS_LIST = [
    "parceiro não deixa", "explicação inconsistente", "demora em buscar",
    "múltiplas visitas", "lesões em diferentes estágios", "isolamento",
    "dependência financeira", "gravidez não desejada repetida",
    "histórico de tentativa de suicídio", "abuso durante a gravidez",
]

VD_CRITICAL_KEYWORDS = [
    "ameaça de morte", "arma", "vai me matar", "tentou me matar",
    "não me deixa sair", "me bateu grávida",
]

IMMEDIATE_ACTIONS_VD = {
    "CRITICO": [
        "🚨 Acionar segurança hospitalar IMEDIATAMENTE",
        "🚨 Isolar a paciente do acompanhante com pretexto clínico",
        "🚨 Acionar psicologia de plantão — crise aguda",
        "🚨 Notificar SINAN ainda neste atendimento",
        "🚨 Não liberar sem plano de segurança documentado",
        "🚨 Oferecer Casa Abrigo e contato da Delegacia da Mulher",
    ],
    "ALTO": [
        "⚠️ Separar a paciente do acompanhante para conversa privada",
        "⚠️ Preencher ficha SINAN antes do fim do atendimento",
        "⚠️ Acionar assistente social ainda neste atendimento",
        "⚠️ Documentar e fotografar lesões com consentimento",
        "⚠️ Elaborar plano de segurança com a paciente",
    ],
    "MODERADO": [
        "Criar espaço privado para conversa acolhedora",
        "Perguntar diretamente sobre violência sem julgamento",
        "Registrar suspeita no prontuário com linguagem clínica",
        "Agendar retorno com psicologia",
        "Notificar SINAN se houver confirmação",
    ],
    "VIGILÂNCIA": [
        "Registrar observação no prontuário",
        "Manter vínculo terapêutico para facilitar revelação futura",
        "Não pressionar — cada pessoa revela no seu tempo",
    ],
}

LEGAL_OBLIGATIONS = [
    "Lei 10.778/2003 — Notificação SINAN obrigatória, independente de consentimento",
    "Lei Maria da Penha (11.340/2006) — informar sobre medidas protetivas disponíveis",
]

SAFETY_PLAN = [
    "Perguntar: 'Você tem um lugar seguro para ir se precisar sair rapidamente?'",
    "Orientar sobre documentos essenciais acessíveis (RG, CPF, certidões dos filhos)",
    "Guardar contatos de emergência em local secreto",
    "Central de Atendimento à Mulher — Ligue 180 (24h, gratuito, sigiloso)",
]


def detect_vd_signals(state: IntakeState) -> IntakeState:
    """
    ETAPA 3 — Analisa as notas de consulta em busca de sinais de violência
    doméstica. Se detectados, calcula o nível de alerta e gera protocolo.
    """
    notes = state.get("consultation_notes", "").lower()
    children = state.get("children_in_household", False)

    physical   = [s for s in PHYSICAL_SIGNS_LIST   if s in notes]
    behavioral = [s for s in BEHAVIORAL_SIGNS_LIST  if s in notes]
    contextual = [s for s in CONTEXTUAL_SIGNS_LIST  if s in notes]

    immediate_risk = any(kw in notes for kw in VD_CRITICAL_KEYWORDS) or len(physical) >= 3

    # Calcular nível
    if immediate_risk or (len(physical) >= 2 and len(behavioral) >= 2):
        level = "CRITICO"
    elif len(physical) >= 2 or (len(physical) >= 1 and (len(behavioral) + len(contextual)) >= 2):
        level = "ALTO"
    elif len(physical) == 1 or (len(behavioral) + len(contextual)) >= 3:
        level = "MODERADO"
    elif (len(physical) + len(behavioral) + len(contextual)) >= 1:
        level = "VIGILÂNCIA"
    else:
        level = None  # sem sinais detectados

    vd_detected = level is not None

    legal = list(LEGAL_OBLIGATIONS)
    if children:
        legal.append("ECA Art. 13 — Notificação ao Conselho Tutelar OBRIGATÓRIA (crianças em risco)")

    import hashlib
    doc_id = None
    if vd_detected:
        doc_id = "VDA-" + hashlib.sha256(
            f"{state['patient_id']}{_now()}".encode()
        ).hexdigest()[:10]

    logger.info(
        f"Intake [{state['intake_id']}] Etapa 3: VD={'SIM nível '+level if vd_detected else 'NÃO'}"
    )

    return {
        **state,
        "vd_detected": vd_detected,
        "vd_alert_level": level,
        "vd_physical_signs": physical,
        "vd_behavioral_signs": behavioral,
        "vd_contextual_signs": contextual,
        "vd_immediate_actions": IMMEDIATE_ACTIONS_VD.get(level, []) if level else [],
        "vd_legal_obligations": legal if vd_detected else [],
        "vd_safety_plan": SAFETY_PLAN if vd_detected else [],
        "vd_documentation_id": doc_id,
        "sinan_required": level in ("CRITICO", "ALTO", "MODERADO") if level else False,
        "current_step": "vd_screened",
        "completed_steps": state.get("completed_steps", []) + ["detect_vd"],
        "audit_log": _audit(state, "detect_vd", {
            "detected": vd_detected,
            "level": level,
            "physical": len(physical),
            "behavioral": len(behavioral),
        }),
    }


def route_after_vd(state: IntakeState) -> Literal["coordinate_team", "compile_summary"]:
    """
    Aresta condicional: se VD detectada ou caso complexo → coordenar equipe.
    Caso contrário → pular direto para sumário.
    """
    pending_urgent = any(e.get("urgencia") == "alta" for e in state.get("pending_exams", []))
    needs_team = (
        state.get("vd_detected", False) or
        state.get("vd_alert_level") in ("CRITICO", "ALTO") or
        (state.get("reproductive_condition") in ("Infertilidade", "Abortamento Recorrente")) or
        pending_urgent
    )
    return "coordinate_team" if needs_team else "compile_summary"


# ===========================================================================
# ETAPA 4 — Coordenar atendimento multidisciplinar
# ===========================================================================

TEAM_BY_SITUATION = {
    "vd_critical": [
        {"papel": "ginecologista",   "prioridade": "imediata", "acao": "Avaliação de lesões, profilaxia IST, notificação SINAN"},
        {"papel": "psicologa",       "prioridade": "imediata", "acao": "Acolhimento em crise aguda — avaliação de risco de suicídio"},
        {"papel": "assistente_social","prioridade": "imediata", "acao": "Acionar Casa Abrigo, plano de fuga, contato emergencial"},
        {"papel": "seguranca_hospitalar","prioridade": "imediata", "acao": "Garantir segurança física — impedir acesso do agressor"},
    ],
    "vd": [
        {"papel": "ginecologista",   "prioridade": "alta",  "acao": "Avaliação clínica completa, SINAN, profilaxia"},
        {"papel": "psicologa",       "prioridade": "alta",  "acao": "Suporte ao trauma, TEPT, plano terapêutico"},
        {"papel": "assistente_social","prioridade": "alta",  "acao": "Rede de apoio, recursos jurídicos, plano de segurança"},
        {"papel": "enfermeira",      "prioridade": "media", "acao": "Coleta de materiais, cuidados de enfermagem"},
    ],
    "infertilidade": [
        {"papel": "ginecologista",   "prioridade": "alta",  "acao": "Investigação e tratamento — reprodução assistida"},
        {"papel": "psicologa",       "prioridade": "alta",  "acao": "Suporte ao casal — luto por infertilidade"},
        {"papel": "assistente_social","prioridade": "baixa", "acao": "Orientação sobre cobertura de plano, adoção se desejado"},
    ],
    "abortamento_recorrente": [
        {"papel": "ginecologista",   "prioridade": "alta",  "acao": "Investigação etiológica + pré-natal de alto risco"},
        {"papel": "psicologa",       "prioridade": "alta",  "acao": "Luto gestacional — suporte estruturado"},
        {"papel": "assistente_social","prioridade": "media", "acao": "Rede de apoio e recursos assistenciais"},
    ],
    "exames_urgentes": [
        {"papel": "ginecologista",   "prioridade": "alta",  "acao": "Agendar e solicitar exames preventivos pendentes"},
        {"papel": "enfermeira",      "prioridade": "alta",  "acao": "Coleta e orientação sobre exames"},
    ],
    "geral": [
        {"papel": "ginecologista",   "prioridade": "alta",  "acao": "Avaliação clínica e condução do caso"},
        {"papel": "psicologa",       "prioridade": "media", "acao": "Suporte emocional se indicado"},
    ],
}


def coordinate_team(state: IntakeState) -> IntakeState:
    """
    ETAPA 4 — Monta o plano de atendimento multidisciplinar automaticamente,
    com base no que foi detectado nas etapas anteriores.
    """
    vd_detected = state.get("vd_detected", False)
    vd_level = state.get("vd_alert_level")
    condition = state.get("reproductive_condition", "")
    pending_urgent = any(e.get("urgencia") == "alta" for e in state.get("pending_exams", []))

    # Selecionar perfil de equipe
    if vd_detected and vd_level == "CRITICO":
        team_key = "vd_critical"
    elif vd_detected:
        team_key = "vd"
    elif "Infertilidade" in condition:
        team_key = "infertilidade"
    elif "Abortamento" in condition:
        team_key = "abortamento_recorrente"
    elif pending_urgent:
        team_key = "exames_urgentes"
    else:
        team_key = "geral"

    assignments = TEAM_BY_SITUATION.get(team_key, TEAM_BY_SITUATION["geral"])

    # Cronograma de seguimento
    today = datetime.utcnow()
    followup = [
        {"data": (today + timedelta(days=3)).strftime("%d/%m/%Y"),
         "responsavel": "Assistente Social",
         "objetivo": "Verificar segurança e rede de apoio"},
        {"data": (today + timedelta(days=7)).strftime("%d/%m/%Y"),
         "responsavel": "Psicóloga",
         "objetivo": "Sessão de acompanhamento"},
        {"data": (today + timedelta(days=14)).strftime("%d/%m/%Y"),
         "responsavel": "Ginecologista",
         "objetivo": "Reavaliação clínica"},
        {"data": (today + timedelta(days=30)).strftime("%d/%m/%Y"),
         "responsavel": "Equipe",
         "objetivo": "Reunião multidisciplinar — revisão do plano"},
    ]

    # Montar plano de coordenação
    prioIcon = {"imediata": "🚨", "alta": "⚠️", "media": "🟡", "baixa": "🟢"}
    plan_lines = ["**👥 PLANO DE ATENDIMENTO MULTIDISCIPLINAR**\n"]
    for a in assignments:
        icon = prioIcon.get(a["prioridade"], "•")
        plan_lines.append(
            f"{icon} **{a['papel'].upper().replace('_',' ')}** — {a['acao']}"
            f"  _(prioridade: {a['prioridade']})_"
        )

    plan_lines.append("\n**Protocolo de comunicação:**")
    if vd_detected:
        plan_lines.append("🔒 Comunicação CRIPTOGRAFADA — não discutir caso em locais abertos")
    plan_lines.append("• Prontuário como canal central — todos registram evoluções no mesmo documento")
    plan_lines.append("• Reunião de equipe em até 24h (VD/urgência) ou 72h (demais)")
    plan_lines.append("• A paciente é informada de cada etapa — ela é parte ativa do plano")

    logger.info(f"Intake [{state['intake_id']}] Etapa 4: equipe={team_key}, {len(assignments)} membros")

    return {
        **state,
        "team_required": True,
        "team_assignments": assignments,
        "followup_schedule": followup,
        "coordination_plan": "\n".join(plan_lines),
        "current_step": "team_coordinated",
        "completed_steps": state.get("completed_steps", []) + ["coordinate_team"],
        "audit_log": _audit(state, "coordinate_team", {
            "team_key": team_key,
            "members": len(assignments),
        }),
    }


# ===========================================================================
# ETAPA 5 — Compilar sumário clínico
# ===========================================================================

def compile_summary(state: IntakeState) -> IntakeState:
    """
    ETAPA 5 — Consolida os resultados de todas as etapas em um sumário
    clínico estruturado, pronto para o prontuário.
    """
    pending_exams = state.get("pending_exams", [])
    vd_detected   = state.get("vd_detected", False)
    vd_level      = state.get("vd_alert_level")
    team_required = state.get("team_required", False)

    # Calcular urgência geral
    if vd_level == "CRITICO":
        overall_urgency = "EMERGÊNCIA"
    elif vd_level == "ALTO":
        overall_urgency = "URGÊNCIA"
    elif vd_level == "MODERADO" or any(e.get("urgencia") == "alta" for e in pending_exams):
        overall_urgency = "PRIORITÁRIO"
    else:
        overall_urgency = "ELETIVO"

    alerts = []
    if vd_detected:
        alerts.append(f"🚨 Violência Doméstica — Nível {vd_level}")
    if any(e.get("urgencia") == "alta" for e in pending_exams):
        alerts.append(f"🔴 {len([e for e in pending_exams if e.get('urgencia')=='alta'])} exame(s) preventivo(s) urgente(s) pendente(s)")
    if state.get("sinan_required"):
        alerts.append("⚖️ SINAN — Notificação compulsória obrigatória")

    # Montar sumário completo
    sections = [
        f"# SUMÁRIO CLÍNICO DE INTAKE",
        f"**Data:** {datetime.utcnow().strftime('%d/%m/%Y %H:%M')} UTC",
        f"**ID do Intake:** {state.get('intake_id', 'N/A')}",
        f"**Urgência Geral:** {overall_urgency}",
        "",
    ]

    if alerts:
        sections.append("## ⚠️ ALERTAS")
        sections.extend(f"- {a}" for a in alerts)
        sections.append("")

    sections.append("## 1. EXAMES PREVENTIVOS")
    sections.append(state.get("exam_summary", "Não avaliado."))
    sections.append("")

    sections.append("## 2. QUESTÃO REPRODUTIVA")
    sections.append(state.get("treatment_suggestion", "Nenhuma queixa reprodutiva informada."))
    if state.get("referrals"):
        sections.append("\n**Encaminhamentos:**")
        sections.extend(f"- {r}" for r in state.get("referrals", []))
    sections.append("")

    if vd_detected:
        sections.append("## 3. VIOLÊNCIA DOMÉSTICA")
        sinais = (
            state.get("vd_physical_signs", []) +
            state.get("vd_behavioral_signs", []) +
            state.get("vd_contextual_signs", [])
        )
        sections.append(f"**Nível de alerta:** {vd_level}")
        sections.append(f"**Sinais detectados:** {', '.join(sinais) if sinais else 'Suspeita por contexto'}")
        sections.append(f"**ID documentação:** {state.get('vd_documentation_id', 'N/A')}")
        sections.append("\n**Ações imediatas:**")
        sections.extend(f"- {a}" for a in state.get("vd_immediate_actions", []))
        sections.append("")

    if team_required:
        sections.append("## 4. COORDENAÇÃO MULTIDISCIPLINAR")
        sections.append(state.get("coordination_plan", "Plano não disponível."))
        sections.append("")

    sections.append("## 5. ABORDAGEM TRAUMA-INFORMED")
    sections.extend(f"- {n}" for n in state.get("sensitivity_notes", []))
    sections.append("")

    sections.append("---")
    sections.append(f"_Sumário gerado automaticamente pelo sistema de intake. "
                    f"Etapas concluídas: {', '.join(state.get('completed_steps', []))}_")

    clinical_summary = "\n".join(sections)

    logger.info(
        f"Intake [{state['intake_id']}] CONCLUÍDO | urgência={overall_urgency} | "
        f"alertas={len(alerts)} | etapas={state.get('completed_steps', [])}"
    )

    return {
        **state,
        "clinical_summary": clinical_summary,
        "overall_urgency": overall_urgency,
        "alerts_count": len(alerts),
        "current_step": "completed",
        "completed_steps": state.get("completed_steps", []) + ["compile_summary"],
        "audit_log": _audit(state, "compile_summary", {
            "urgency": overall_urgency,
            "alerts": len(alerts),
        }),
        "messages": state.get("messages", []) + [AIMessage(content=clinical_summary)],
    }


# ===========================================================================
# Construção do grafo
# ===========================================================================

def build_unified_intake_graph() -> StateGraph:
    """
    Constrói e compila o grafo de intake unificado.

    Fluxo:
        verify_pending_exams
            → screen_reproductive_needs
                → detect_vd_signals
                    → [condicional]
                        → coordinate_team → compile_summary
                        → compile_summary (direto se não necessário)
    """
    graph = StateGraph(IntakeState)

    graph.add_node("verify_pending_exams",    verify_pending_exams)
    graph.add_node("screen_reproductive",     screen_reproductive_needs)
    graph.add_node("detect_vd_signals",       detect_vd_signals)
    graph.add_node("coordinate_team",         coordinate_team)
    graph.add_node("compile_summary",         compile_summary)

    graph.set_entry_point("verify_pending_exams")

    graph.add_edge("verify_pending_exams", "screen_reproductive")
    graph.add_edge("screen_reproductive",  "detect_vd_signals")

    graph.add_conditional_edges(
        "detect_vd_signals",
        route_after_vd,
        {
            "coordinate_team": "coordinate_team",
            "compile_summary":  "compile_summary",
        },
    )

    graph.add_edge("coordinate_team", "compile_summary")
    graph.add_edge("compile_summary", END)

    return graph.compile(checkpointer=MemorySaver())
