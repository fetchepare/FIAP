"""
Fluxos LangGraph — Atendimento Especializado em Saúde da Mulher

Implementa os 4 fluxos clínicos como StateGraphs:
1. Triagem Ginecológica
2. Detecção de Violência Doméstica
3. Fluxo Obstétrico
4. Prevenção e Rastreamento

Cada fluxo é um grafo de estados com nós de processamento,
decisões condicionais e rastreamento de auditoria embutido.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from enum import Enum
from typing import Annotated, TypedDict, Optional, Literal

from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enumerações clínicas
# ---------------------------------------------------------------------------

class UrgencyLevel(str, Enum):
    EMERGENCY = "EMERGENCIA"
    URGENT = "URGENCIA"
    PRIORITY = "PRIORITARIO"
    ELECTIVE = "ELETIVO"


class ViolenceRisk(str, Enum):
    HIGH = "ALTO"
    MEDIUM = "MEDIO"
    LOW = "BAIXO"
    NONE = "NENHUM"


class ObstetricRisk(str, Enum):
    HIGH = "ALTO"
    USUAL = "HABITUAL"
    LOW = "BAIXO"


# ---------------------------------------------------------------------------
# Estados dos fluxos (TypedDicts)
# ---------------------------------------------------------------------------

class GynecologicalTriageState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    symptoms: str
    symptom_duration: Optional[str]
    associated_symptoms: list[str]
    relevant_history: Optional[str]
    # Resultados intermediários
    risk_analysis: Optional[dict]
    urgency_level: Optional[UrgencyLevel]
    red_flags: list[str]
    recommended_exams: list[str]
    initial_guidance: Optional[str]
    scheduling_type: Optional[str]
    # Controle de fluxo
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


class DomesticViolenceState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    professional_id: str
    # Sinais detectados
    alert_signs: list[str]
    physical_signs: list[str]
    behavioral_signs: list[str]
    # Avaliação
    risk_level: Optional[ViolenceRisk]
    immediate_danger: bool
    children_at_risk: bool
    # Protocolo
    security_protocol_activated: bool
    team_notified: list[str]
    documentation_id: Optional[str]
    followup_scheduled: bool
    # Controle
    current_step: str
    audit_log: list[dict]  # logs encriptados
    error: Optional[str]


class ObstetricState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    gestational_age_weeks: int
    gestational_age_days: int
    obstetric_history: str       # G_P_A_
    comorbidities: list[str]
    current_vitals: dict
    recent_exams: dict
    fetal_wellbeing: Optional[dict]
    # Avaliação
    gestational_risk: Optional[ObstetricRisk]
    risk_factors: list[str]
    trimester_guidance: Optional[str]
    recommended_exams: list[str]
    next_appointment: Optional[str]
    urgent_alerts: list[str]
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


class PreventionState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    age: int
    last_exams: dict       # {exam_name: date_str}
    family_history: list[str]
    comorbidities: list[str]
    reproductive_history: dict
    # Resultados
    overdue_exams: list[dict]
    upcoming_exams: list[dict]
    preventive_guidance: Optional[str]
    scheduled_appointments: list[dict]
    reminders_set: bool
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


# ---------------------------------------------------------------------------
# Helpers de auditoria
# ---------------------------------------------------------------------------

def _log_step(state: dict, step: str, details: dict = None) -> list[dict]:
    """Adiciona entrada ao log de auditoria do estado."""
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "step": step,
        "patient_id_hash": hash(state.get("patient_id", "")),
        **(details or {}),
    }
    return state.get("audit_log", []) + [entry]


# ===========================================================================
# FLUXO 1: TRIAGEM GINECOLÓGICA
# ===========================================================================

def analyze_symptoms(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó 1: Analisa os sintomas relatados com NLP."""
    logger.info("Triagem: analisando sintomas")

    symptoms_text = state["symptoms"].lower()

    # Lógica de detecção de sinais de alerta
    red_flags = []

    emergency_keywords = [
        "hemorragia", "sangramento intenso", "perda de consciência",
        "dor abdominal intensa súbita", "febre alta", "vômito com sangue"
    ]
    urgent_keywords = [
        "sangramento", "dor pélvica", "corrimento com odor", "nódulo",
        "atraso menstrual", "gravidez", "dispareunia intensa"
    ]

    for kw in emergency_keywords:
        if kw in symptoms_text:
            red_flags.append(f"EMERGÊNCIA: {kw}")

    for kw in urgent_keywords:
        if kw in symptoms_text and not any("EMERGÊNCIA" in f for f in red_flags):
            red_flags.append(f"Atenção: {kw}")

    risk_analysis = {
        "symptom_count": len(symptoms_text.split(",")),
        "duration": state.get("symptom_duration", "não informado"),
        "flags_detected": len(red_flags),
        "analysis_timestamp": datetime.utcnow().isoformat(),
    }

    return {
        **state,
        "risk_analysis": risk_analysis,
        "red_flags": red_flags,
        "current_step": "symptoms_analyzed",
        "audit_log": _log_step(state, "analyze_symptoms", {"flags": len(red_flags)}),
    }


def classify_urgency(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó 2: Classifica nível de urgência."""
    red_flags = state.get("red_flags", [])

    if any("EMERGÊNCIA" in f for f in red_flags):
        urgency = UrgencyLevel.EMERGENCY
        scheduling = "encaminhamento_imediato_pronto_socorro"
    elif len(red_flags) >= 2:
        urgency = UrgencyLevel.URGENT
        scheduling = "consulta_24h"
    elif len(red_flags) == 1:
        urgency = UrgencyLevel.PRIORITY
        scheduling = "consulta_72h"
    else:
        urgency = UrgencyLevel.ELECTIVE
        scheduling = "agendamento_regular"

    return {
        **state,
        "urgency_level": urgency,
        "scheduling_type": scheduling,
        "current_step": "urgency_classified",
        "audit_log": _log_step(state, "classify_urgency", {"urgency": urgency.value}),
    }


def suggest_exams(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó 3: Sugere exames baseados nos sintomas."""
    symptoms = state["symptoms"].lower()
    exams = []

    # Mapeamento sintoma → exame (simplificado; em produção: via RAG + LLM)
    exam_map = {
        "sangramento": ["hemograma", "beta-hCG", "US pélvico transvaginal", "coagulograma"],
        "dor pélvica": ["US pélvico", "urina tipo I", "vaginal swab", "beta-hCG"],
        "corrimento": ["bacterioscopia", "cultura vaginal", "VDRL", "HIV"],
        "nódulo": ["US mama", "mamografia se > 40 anos", "core biopsy se indicado"],
        "irregularidade menstrual": ["TSH", "prolactina", "FSH/LH", "US pélvico"],
        "menopausa": ["FSH", "estradiol", "densitometria óssea", "perfil lipídico"],
    }

    for symptom_key, exam_list in exam_map.items():
        if symptom_key in symptoms:
            exams.extend(exam_list)

    # Remove duplicatas mantendo ordem
    seen = set()
    unique_exams = [e for e in exams if not (e in seen or seen.add(e))]

    return {
        **state,
        "recommended_exams": unique_exams[:8],  # máximo 8 sugestões
        "current_step": "exams_suggested",
        "audit_log": _log_step(state, "suggest_exams", {"exam_count": len(unique_exams)}),
    }


def generate_triage_guidance(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó 4: Gera orientações iniciais."""
    urgency = state.get("urgency_level", UrgencyLevel.ELECTIVE)
    red_flags = state.get("red_flags", [])
    exams = state.get("recommended_exams", [])

    if urgency == UrgencyLevel.EMERGENCY:
        guidance = (
            "🚨 EMERGÊNCIA: Encaminhar imediatamente ao pronto-socorro obstétrico/ginecológico. "
            "Não aguardar exames ambulatoriais."
        )
    elif urgency == UrgencyLevel.URGENT:
        guidance = (
            f"⚠️ Sinais de alerta identificados: {', '.join(red_flags)}. "
            "Consulta ginecológica em até 24 horas. "
            f"Exames prioritários: {', '.join(exams[:3])}."
        )
    else:
        guidance = (
            f"Agendamento eletivo recomendado. "
            f"Exames sugeridos para avaliação: {', '.join(exams[:4])}. "
            "Retornar imediatamente se surgir piora dos sintomas."
        )

    return {
        **state,
        "initial_guidance": guidance,
        "current_step": "guidance_generated",
        "audit_log": _log_step(state, "generate_guidance"),
        "messages": state["messages"] + [AIMessage(content=guidance)],
    }


def schedule_appointment(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó 5: Finaliza com agendamento."""
    scheduling_type = state.get("scheduling_type", "agendamento_regular")

    schedule_map = {
        "encaminhamento_imediato_pronto_socorro": "PS Obstétrico — imediato",
        "consulta_24h": "Ginecologia — urgência 24h",
        "consulta_72h": "Ginecologia — prioritário 72h",
        "agendamento_regular": "Ginecologia — eletivo",
    }

    return {
        **state,
        "current_step": "completed",
        "audit_log": _log_step(state, "schedule_appointment", {
            "scheduling": schedule_map.get(scheduling_type, scheduling_type)
        }),
    }


def route_by_urgency(state: GynecologicalTriageState) -> Literal["suggest_exams", "emergency_alert"]:
    """Condicional: emergências vão direto para alerta."""
    if state.get("urgency_level") == UrgencyLevel.EMERGENCY:
        return "emergency_alert"
    return "suggest_exams"


def emergency_triage_alert(state: GynecologicalTriageState) -> GynecologicalTriageState:
    """Nó de emergência: aciona equipe imediatamente."""
    alert_msg = (
        "🚨 EMERGÊNCIA GINECOLÓGICA — Equipe acionada. "
        f"Paciente: {state['patient_id']} | "
        f"Sinais: {', '.join(state.get('red_flags', []))}"
    )
    logger.critical(alert_msg)
    return {
        **state,
        "current_step": "emergency_alerted",
        "messages": state["messages"] + [AIMessage(content=alert_msg)],
        "audit_log": _log_step(state, "emergency_alert", {"alert": "ACIONADO"}),
    }


def build_gynecological_triage_graph() -> StateGraph:
    """Constrói e compila o grafo de triagem ginecológica."""
    graph = StateGraph(GynecologicalTriageState)

    graph.add_node("analyze_symptoms", analyze_symptoms)
    graph.add_node("classify_urgency", classify_urgency)
    graph.add_node("suggest_exams", suggest_exams)
    graph.add_node("generate_guidance", generate_triage_guidance)
    graph.add_node("schedule_appointment", schedule_appointment)
    graph.add_node("emergency_alert", emergency_triage_alert)

    graph.set_entry_point("analyze_symptoms")
    graph.add_edge("analyze_symptoms", "classify_urgency")
    graph.add_conditional_edges(
        "classify_urgency",
        route_by_urgency,
        {"suggest_exams": "suggest_exams", "emergency_alert": "emergency_alert"},
    )
    graph.add_edge("suggest_exams", "generate_guidance")
    graph.add_edge("generate_guidance", "schedule_appointment")
    graph.add_edge("schedule_appointment", END)
    graph.add_edge("emergency_alert", END)

    checkpointer = MemorySaver()
    return graph.compile(checkpointer=checkpointer)


# ===========================================================================
# FLUXO 2: DETECÇÃO DE VIOLÊNCIA DOMÉSTICA
# ===========================================================================

def detect_alert_signs(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 1: Detecção de sinais de alerta."""
    physical_indicators = [
        "hematoma", "equimose", "fratura", "lesão", "queimadura",
        "marca", "corte", "cicatriz", "lesão genital"
    ]
    behavioral_indicators = [
        "evasiva", "nervosa", "acompanhante fala por ela", "contradição",
        "medo", "choro", "ansiedade", "depressão", "insônia",
        "não mantém contato visual"
    ]

    messages_text = " ".join(
        m.content for m in state["messages"] if hasattr(m, "content")
    ).lower()

    physical_found = [i for i in physical_indicators if i in messages_text]
    behavioral_found = [i for i in behavioral_indicators if i in messages_text]
    all_signs = physical_found + behavioral_found

    return {
        **state,
        "physical_signs": physical_found,
        "behavioral_signs": behavioral_found,
        "alert_signs": all_signs,
        "current_step": "signs_detected",
        "audit_log": _log_step(state, "detect_signs", {
            "physical": len(physical_found),
            "behavioral": len(behavioral_found),
        }),
    }


def assess_violence_risk(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 2: Avaliação do nível de risco."""
    physical = len(state.get("physical_signs", []))
    behavioral = len(state.get("behavioral_signs", []))
    total = physical + behavioral

    if physical >= 2 or total >= 4:
        risk = ViolenceRisk.HIGH
        immediate_danger = True
    elif physical == 1 or total >= 2:
        risk = ViolenceRisk.MEDIUM
        immediate_danger = False
    elif total == 1:
        risk = ViolenceRisk.LOW
        immediate_danger = False
    else:
        risk = ViolenceRisk.NONE
        immediate_danger = False

    return {
        **state,
        "risk_level": risk,
        "immediate_danger": immediate_danger,
        "current_step": "risk_assessed",
        "audit_log": _log_step(state, "assess_risk", {
            "risk_level": risk.value,
            "immediate_danger": immediate_danger,
        }),
    }


def activate_security_protocol(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 3: Ativa protocolo de segurança — SEMPRE que há risco identificado."""
    risk = state.get("risk_level", ViolenceRisk.NONE)

    if risk == ViolenceRisk.NONE:
        return {
            **state,
            "security_protocol_activated": False,
            "current_step": "protocol_skipped",
            "audit_log": _log_step(state, "security_protocol", {"activated": False}),
        }

    # Em produção: notificar sistema hospitalar, criar registro restrito,
    # ativar criptografia end-to-end para este caso
    logger.warning(
        f"PROTOCOLO VD ATIVADO — Paciente: {hash(state['patient_id'])} — "
        f"Risco: {risk.value} — Profissional: {state['professional_id']}"
    )

    return {
        **state,
        "security_protocol_activated": True,
        "current_step": "protocol_activated",
        "audit_log": _log_step(state, "security_protocol", {
            "activated": True,
            "risk_level": risk.value,
            "encryption": "E2E_ATIVADO",
        }),
    }


def notify_specialized_team(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 4: Notifica equipe multidisciplinar (com interrupt_before para aprovação humana)."""
    risk = state.get("risk_level")
    notified = []

    if risk in (ViolenceRisk.HIGH, ViolenceRisk.MEDIUM):
        notified = ["ginecologista_responsavel", "psicologa", "assistente_social"]
        if state.get("immediate_danger"):
            notified.append("seguranca_hospitalar")
        if state.get("children_at_risk"):
            notified.append("conselho_tutelar")

    elif risk == ViolenceRisk.LOW:
        notified = ["psicologa"]

    # Em produção: integrar com sistema de notificação hospitalar
    for team_member in notified:
        logger.info(f"Notificando: {team_member} — caso {hash(state['patient_id'])}")

    return {
        **state,
        "team_notified": notified,
        "current_step": "team_notified",
        "audit_log": _log_step(state, "notify_team", {"notified": notified}),
    }


def create_secure_documentation(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 5: Cria documentação segura no prontuário restrito."""
    import hashlib

    doc_id = hashlib.sha256(
        f"{state['patient_id']}{datetime.utcnow().isoformat()}".encode()
    ).hexdigest()[:12]

    return {
        **state,
        "documentation_id": f"VD-{doc_id}",
        "current_step": "documented",
        "audit_log": _log_step(state, "create_documentation", {
            "doc_id": f"VD-{doc_id}",
            "restricted_access": True,
            "encrypted": True,
        }),
    }


def schedule_followup(state: DomesticViolenceState) -> DomesticViolenceState:
    """Nó 6: Agenda seguimento e retorno."""
    return {
        **state,
        "followup_scheduled": True,
        "current_step": "completed",
        "audit_log": _log_step(state, "schedule_followup"),
        "messages": state["messages"] + [AIMessage(
            content=(
                "✅ Protocolo de violência doméstica concluído. "
                f"Equipe notificada: {', '.join(state.get('team_notified', []))}. "
                f"Registro ID: {state.get('documentation_id')}. "
                "Seguimento agendado conforme protocolo institucional."
            )
        )],
    }


def route_violence_risk(state: DomesticViolenceState) -> Literal["notify_team", "end_no_risk"]:
    if state.get("risk_level") == ViolenceRisk.NONE:
        return "end_no_risk"
    return "notify_team"


def build_domestic_violence_graph() -> StateGraph:
    """Constrói o grafo de detecção de violência doméstica."""
    graph = StateGraph(DomesticViolenceState)

    graph.add_node("detect_signs", detect_alert_signs)
    graph.add_node("assess_risk", assess_violence_risk)
    graph.add_node("activate_protocol", activate_security_protocol)
    graph.add_node("notify_team", notify_specialized_team)
    graph.add_node("create_documentation", create_secure_documentation)
    graph.add_node("schedule_followup", schedule_followup)

    graph.set_entry_point("detect_signs")
    graph.add_edge("detect_signs", "assess_risk")
    graph.add_edge("assess_risk", "activate_protocol")
    graph.add_conditional_edges(
        "activate_protocol",
        route_violence_risk,
        {"notify_team": "notify_team", "end_no_risk": END},
    )
    graph.add_edge("notify_team", "create_documentation")
    graph.add_edge("create_documentation", "schedule_followup")
    graph.add_edge("schedule_followup", END)

    checkpointer = MemorySaver()
    # interrupt_before: exige aprovação humana antes de notificar equipe
    return graph.compile(
        checkpointer=checkpointer,
        interrupt_before=["notify_team"],
    )


# ===========================================================================
# FLUXO 3: OBSTÉTRICO
# ===========================================================================

def evaluate_obstetric_risk(state: ObstetricState) -> ObstetricState:
    """Avalia risco gestacional baseado em dados clínicos."""
    comorbidities = state.get("comorbidities", [])
    ga_weeks = state.get("gestational_age_weeks", 0)
    vitals = state.get("current_vitals", {})
    risk_factors = []

    # Avalia comorbidades
    high_risk_comorbidities = ["diabetes", "hipertensão", "lúpus", "cardiopatia", "gemelar"]
    for c in comorbidities:
        if any(h in c.lower() for h in high_risk_comorbidities):
            risk_factors.append(f"Comorbidade de alto risco: {c}")

    # Avalia PA
    systolic = vitals.get("systolic_bp", 0)
    if systolic >= 160:
        risk_factors.append("PA sistólica ≥ 160 mmHg — suspeita PE grave")
    elif systolic >= 140:
        risk_factors.append("PA sistólica ≥ 140 mmHg")

    # Prematuridade
    if ga_weeks < 34:
        risk_factors.append(f"Prematuridade extrema ({ga_weeks} semanas)")
    elif ga_weeks < 37:
        risk_factors.append(f"Pré-termo ({ga_weeks} semanas)")

    if len(risk_factors) >= 2:
        risk = ObstetricRisk.HIGH
    elif len(risk_factors) == 1:
        risk = ObstetricRisk.USUAL
    else:
        risk = ObstetricRisk.LOW

    return {
        **state,
        "gestational_risk": risk,
        "risk_factors": risk_factors,
        "current_step": "risk_evaluated",
        "audit_log": _log_step(state, "evaluate_obstetric_risk", {
            "risk": risk.value,
            "factors": len(risk_factors),
        }),
    }


def generate_obstetric_guidance(state: ObstetricState) -> ObstetricState:
    """Gera orientações específicas por trimestre."""
    ga = state.get("gestational_age_weeks", 0)

    if ga < 14:
        trimester = "1º trimestre"
        guidance_items = [
            "Ácido fólico 400mcg/dia (já prescrito ou iniciar)",
            "Evitar automedicação, álcool e tabaco",
            "Vacinas: Influenza, dTpa, hepatite B (conforme esquema)",
            "Atividade física moderada liberada",
            "Náuseas: refeições fracionadas, gengibre, B6 se necessário",
        ]
    elif ga < 28:
        trimester = "2º trimestre"
        guidance_items = [
            "Sulfato ferroso 40mg/dia + ácido fólico",
            "GTT 75g entre 24-28 semanas (rastreio DMG)",
            "US morfológico 20-24 semanas",
            "Movimentos fetais: registrar diariamente a partir de 20 sem",
            "Atividade física: caminhadas, natação, yoga pré-natal",
        ]
    elif ga < 37:
        trimester = "3º trimestre"
        guidance_items = [
            "Streptococcus agalactiae (35-37 semanas)",
            "CTG: monitorização fetal conforme risco",
            "Plano de parto: discutir via de parto",
            "Sinais de alerta do parto prematuro",
            "Preparação para amamentação: aulas de pré-natal",
        ]
    else:
        trimester = "Termo / Pós-termo"
        guidance_items = [
            "Monitorização fetal intensiva",
            "Avaliação de maturidade pulmonar se indicado",
            "Discussão sobre indução do trabalho de parto",
        ]

    guidance = f"**{trimester} ({ga} semanas)**\n" + "\n".join(
        f"- {item}" for item in guidance_items
    )

    alerts = []
    for factor in state.get("risk_factors", []):
        if "PE grave" in factor or "PA" in factor:
            alerts.append("🚨 Avaliar internação imediata — suspeita de pré-eclâmpsia grave")
        elif "prematuridade" in factor.lower():
            alerts.append("⚠️ Corticoterapia para maturidade pulmonar fetal se < 34 semanas")

    return {
        **state,
        "trimester_guidance": guidance,
        "urgent_alerts": alerts,
        "current_step": "guidance_generated",
        "audit_log": _log_step(state, "generate_guidance"),
    }


def schedule_obstetric_exams(state: ObstetricState) -> ObstetricState:
    """Define próximos exames e consulta."""
    ga = state.get("gestational_age_weeks", 0)
    risk = state.get("gestational_risk", ObstetricRisk.LOW)

    exams = []
    if ga < 14:
        exams = ["US 1º trimestre + TN", "PAPP-A + beta-hCG livre", "sorologias"]
    elif 24 <= ga <= 28:
        exams = ["GTT 75g", "US morfológico", "hemograma", "urocultura"]
    elif 30 <= ga <= 37:
        exams = ["Streptococcus agalactiae", "CTG se indicado", "US obstétrico"]
    else:
        exams = ["CTG", "US com Doppler", "perfil biofísico fetal"]

    interval_weeks = 2 if risk == ObstetricRisk.HIGH else 4

    return {
        **state,
        "recommended_exams": exams,
        "next_appointment": f"Em {interval_weeks} semanas ({risk.value} risco)",
        "current_step": "completed",
        "audit_log": _log_step(state, "schedule_exams"),
    }


def route_obstetric_risk(state: ObstetricState) -> Literal["guidance", "obstetric_emergency"]:
    alerts = state.get("urgent_alerts", [])
    if any("🚨" in a for a in alerts):
        return "obstetric_emergency"
    return "guidance"


def obstetric_emergency_node(state: ObstetricState) -> ObstetricState:
    """Nó de emergência obstétrica."""
    return {
        **state,
        "current_step": "emergency",
        "messages": state["messages"] + [AIMessage(
            content="🚨 EMERGÊNCIA OBSTÉTRICA — Acionar obstetra de plantão imediatamente."
        )],
        "audit_log": _log_step(state, "obstetric_emergency", {"level": "CRITICAL"}),
    }


def build_obstetric_graph() -> StateGraph:
    graph = StateGraph(ObstetricState)

    graph.add_node("evaluate_risk", evaluate_obstetric_risk)
    graph.add_node("guidance", generate_obstetric_guidance)
    graph.add_node("schedule_exams", schedule_obstetric_exams)
    graph.add_node("obstetric_emergency", obstetric_emergency_node)

    graph.set_entry_point("evaluate_risk")
    graph.add_conditional_edges(
        "evaluate_risk",
        route_obstetric_risk,
        {"guidance": "guidance", "obstetric_emergency": "obstetric_emergency"},
    )
    graph.add_edge("guidance", "schedule_exams")
    graph.add_edge("schedule_exams", END)
    graph.add_edge("obstetric_emergency", END)

    return graph.compile(checkpointer=MemorySaver())


# ===========================================================================
# FLUXO 4: PREVENÇÃO E RASTREAMENTO
# ===========================================================================

def identify_overdue_exams(state: PreventionState) -> PreventionState:
    """Identifica exames preventivos em atraso."""
    from datetime import date

    today = date.today()
    age = state["age"]
    last_exams = state.get("last_exams", {})
    family_history = state.get("family_history", [])

    # Protocolo de rastreamento (simplificado)
    protocols = {
        "papanicolau": {"min_age": 25, "max_age": 65, "interval_years": 1, "after_two_negatives": 3},
        "mamografia": {"min_age": 40, "max_age": 74, "interval_years": 1},
        "densitometria_ossea": {"min_age": 65, "interval_years": 2},
        "colesterol": {"min_age": 20, "interval_years": 5},
        "glicemia": {"min_age": 45, "interval_years": 3},
        "hiv": {"min_age": 15, "interval_years": 1},
        "hepatite_b": {"min_age": 0, "interval_years": 5},
    }

    # Regras especiais por histórico familiar
    if any("mama" in h.lower() for h in family_history):
        protocols["mamografia"]["min_age"] = 30
    if any("colorretal" in h.lower() for h in family_history):
        protocols["colonoscopia"] = {"min_age": 40, "interval_years": 5}

    overdue = []
    upcoming = []

    for exam, rule in protocols.items():
        if age < rule.get("min_age", 0):
            continue
        if age > rule.get("max_age", 200):
            continue

        last_date_str = last_exams.get(exam)
        interval = rule["interval_years"]

        if not last_date_str:
            overdue.append({
                "exam": exam,
                "last_done": None,
                "due_date": "imediato",
                "priority": "alta",
                "guideline": "INCA / MS / FEBRASGO",
            })
        else:
            try:
                last_date = date.fromisoformat(last_date_str)
                months_since = (today - last_date).days / 30
                months_interval = interval * 12

                if months_since > months_interval:
                    overdue.append({
                        "exam": exam,
                        "last_done": last_date_str,
                        "due_date": "vencido",
                        "months_overdue": round(months_since - months_interval),
                        "priority": "alta" if months_since > months_interval * 1.5 else "média",
                        "guideline": "Protocolo Institucional",
                    })
                elif months_since > months_interval * 0.8:
                    upcoming.append({
                        "exam": exam,
                        "due_in_months": round(months_interval - months_since),
                    })
            except ValueError:
                pass

    return {
        **state,
        "overdue_exams": overdue,
        "upcoming_exams": upcoming,
        "current_step": "exams_identified",
        "audit_log": _log_step(state, "identify_exams", {
            "overdue": len(overdue),
            "upcoming": len(upcoming),
        }),
    }


def generate_preventive_guidance(state: PreventionState) -> PreventionState:
    """Gera orientações preventivas personalizadas."""
    overdue = state.get("overdue_exams", [])
    age = state["age"]

    guidance_parts = ["**Orientações preventivas personalizadas:**\n"]

    if overdue:
        guidance_parts.append(
            f"⚠️ {len(overdue)} exame(s) em atraso identificado(s). "
            "Priorize o agendamento conforme urgência indicada.\n"
        )

    if age >= 50:
        guidance_parts.append("- Atenção redobrada à saúde cardiovascular e óssea nesta fase\n")
    if age >= 40:
        guidance_parts.append("- Mamografia anual recomendada (FEBRASGO/INCA)\n")

    guidance_parts.append(
        "- Manter calendário vacinal adulto atualizado (Influenza, dTpa, COVID-19)\n"
        "- Atividade física regular: 150 min/semana de intensidade moderada\n"
        "- Alimentação saudável e controle do peso corporal\n"
    )

    return {
        **state,
        "preventive_guidance": "".join(guidance_parts),
        "current_step": "guidance_generated",
        "audit_log": _log_step(state, "generate_guidance"),
    }


def schedule_and_remind(state: PreventionState) -> PreventionState:
    """Agenda exames e configura lembretes automáticos."""
    overdue = state.get("overdue_exams", [])
    scheduled = []

    for exam_info in overdue:
        scheduled.append({
            "exam": exam_info["exam"],
            "priority": exam_info.get("priority", "média"),
            "action": "agendar_ambulatorio",
            "reminder_days": 7 if exam_info.get("priority") == "alta" else 30,
        })

    return {
        **state,
        "scheduled_appointments": scheduled,
        "reminders_set": len(scheduled) > 0,
        "current_step": "completed",
        "audit_log": _log_step(state, "schedule_and_remind", {
            "scheduled": len(scheduled),
            "reminders": len(scheduled) > 0,
        }),
        "messages": state["messages"] + [AIMessage(
            content=(
                f"✅ Verificação preventiva concluída. "
                f"{len(overdue)} exame(s) em atraso. "
                f"{len(scheduled)} agendamento(s) solicitado(s).\n\n"
                + (state.get("preventive_guidance") or "")
            )
        )],
    }


def build_prevention_graph() -> StateGraph:
    graph = StateGraph(PreventionState)

    graph.add_node("identify_exams", identify_overdue_exams)
    graph.add_node("generate_guidance", generate_preventive_guidance)
    graph.add_node("schedule_remind", schedule_and_remind)

    graph.set_entry_point("identify_exams")
    graph.add_edge("identify_exams", "generate_guidance")
    graph.add_edge("generate_guidance", "schedule_remind")
    graph.add_edge("schedule_remind", END)

    return graph.compile(checkpointer=MemorySaver())


# ===========================================================================
# Factory de fluxos
# ===========================================================================

class ClinicalFlowOrchestrator:
    """Ponto de entrada para todos os fluxos LangGraph."""

    def __init__(self):
        self.gynecological_triage = build_gynecological_triage_graph()
        self.domestic_violence = build_domestic_violence_graph()
        self.obstetric = build_obstetric_graph()
        self.prevention = build_prevention_graph()

    async def run_triage(self, patient_id: str, symptoms: str, **kwargs) -> GynecologicalTriageState:
        config = {"configurable": {"thread_id": f"triage-{patient_id}"}}
        initial_state: GynecologicalTriageState = {
            "messages": [HumanMessage(content=symptoms)],
            "patient_id": patient_id,
            "symptoms": symptoms,
            "symptom_duration": kwargs.get("duration"),
            "associated_symptoms": kwargs.get("associated", []),
            "relevant_history": kwargs.get("history"),
            "risk_analysis": None,
            "urgency_level": None,
            "red_flags": [],
            "recommended_exams": [],
            "initial_guidance": None,
            "scheduling_type": None,
            "current_step": "start",
            "audit_log": [],
            "error": None,
        }
        return await self.gynecological_triage.ainvoke(initial_state, config=config)

    async def run_violence_screening(
        self,
        patient_id: str,
        professional_id: str,
        consultation_notes: str,
        **kwargs,
    ) -> DomesticViolenceState:
        config = {"configurable": {"thread_id": f"vd-{patient_id}"}}
        initial_state: DomesticViolenceState = {
            "messages": [HumanMessage(content=consultation_notes)],
            "patient_id": patient_id,
            "professional_id": professional_id,
            "alert_signs": [],
            "physical_signs": [],
            "behavioral_signs": [],
            "risk_level": None,
            "immediate_danger": False,
            "children_at_risk": kwargs.get("children_at_risk", False),
            "security_protocol_activated": False,
            "team_notified": [],
            "documentation_id": None,
            "followup_scheduled": False,
            "current_step": "start",
            "audit_log": [],
            "error": None,
        }
        return await self.domestic_violence.ainvoke(initial_state, config=config)

    async def run_obstetric_flow(
        self, patient_id: str, ga_weeks: int, **kwargs
    ) -> ObstetricState:
        config = {"configurable": {"thread_id": f"obs-{patient_id}"}}
        initial_state: ObstetricState = {
            "messages": [],
            "patient_id": patient_id,
            "gestational_age_weeks": ga_weeks,
            "gestational_age_days": kwargs.get("ga_days", 0),
            "obstetric_history": kwargs.get("obstetric_history", "G1P0A0"),
            "comorbidities": kwargs.get("comorbidities", []),
            "current_vitals": kwargs.get("vitals", {}),
            "recent_exams": kwargs.get("exams", {}),
            "fetal_wellbeing": None,
            "gestational_risk": None,
            "risk_factors": [],
            "trimester_guidance": None,
            "recommended_exams": [],
            "next_appointment": None,
            "urgent_alerts": [],
            "current_step": "start",
            "audit_log": [],
            "error": None,
        }
        return await self.obstetric.ainvoke(initial_state, config=config)

    async def run_prevention_check(
        self, patient_id: str, age: int, last_exams: dict, **kwargs
    ) -> PreventionState:
        config = {"configurable": {"thread_id": f"prev-{patient_id}"}}
        initial_state: PreventionState = {
            "messages": [],
            "patient_id": patient_id,
            "age": age,
            "last_exams": last_exams,
            "family_history": kwargs.get("family_history", []),
            "comorbidities": kwargs.get("comorbidities", []),
            "reproductive_history": kwargs.get("reproductive_history", {}),
            "overdue_exams": [],
            "upcoming_exams": [],
            "preventive_guidance": None,
            "scheduled_appointments": [],
            "reminders_set": False,
            "current_step": "start",
            "audit_log": [],
            "error": None,
        }
        return await self.prevention.ainvoke(initial_state, config=config)
