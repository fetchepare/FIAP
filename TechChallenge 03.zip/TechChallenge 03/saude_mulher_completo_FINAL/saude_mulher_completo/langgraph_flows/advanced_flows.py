"""
Fluxos Avançados — Saúde da Mulher

Módulo 1: Sugestão de Tratamentos para Questões Reprodutivas
    Avalia queixa reprodutiva → sugere linha terapêutica → considera
    sensibilidades (desejo de gestar, religião, preferência hormonal, etc.)

Módulo 2: Alertas para Casos Suspeitos de Violência Doméstica
    Aprofunda a detecção do fluxo base → gera alerta estruturado com
    protocolo SINAN, orientações legais e conduta clínica imediata.

Módulo 3: Coordenação Multidisciplinar
    Orquestra o atendimento entre Ginecologista, Psicóloga e Assistente
    Social → cria plano de cuidado integrado → define responsabilidades
    e prazos para cada membro da equipe.

Todos os fluxos seguem princípios de atendimento feminino trauma-informed:
    - Linguagem acolhedora e não julgadora
    - Respeito à autonomia e ao tempo da paciente
    - Privacidade e sigilo reforçados
    - Validação da experiência antes de qualquer conduta
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from enum import Enum
from typing import Annotated, TypedDict, Optional, Literal

from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


# ===========================================================================
# Enumerações
# ===========================================================================

class ReproductiveCondition(str, Enum):
    INFERTILITY          = "infertilidade"
    PCOS                 = "sindrome_ovarios_policisticos"
    ENDOMETRIOSIS        = "endometriose"
    UTERINE_FIBROIDS     = "miomatose"
    MENSTRUAL_DISORDER   = "disturbio_menstrual"
    MENOPAUSE            = "menopausa_climatério"
    RECURRENT_ABORTION   = "abortamento_recorrente"
    SEXUAL_DYSFUNCTION   = "disfuncao_sexual"
    CONTRACEPTION        = "anticoncepção"
    GENERAL              = "queixa_reprodutiva_geral"


class TreatmentLine(str, Enum):
    FIRST  = "primeira_linha"
    SECOND = "segunda_linha"
    THIRD  = "terceira_linha"  # cirúrgico / especializado


class VDAlertLevel(str, Enum):
    CRITICAL = "CRITICO"    # risco imediato à vida
    HIGH     = "ALTO"       # sinais físicos + comportamentais
    MODERATE = "MODERADO"   # sinais comportamentais isolados
    WATCH    = "VIGILÂNCIA" # suspeita leve, monitorar


class TeamRole(str, Enum):
    GYNECOLOGIST      = "ginecologista"
    PSYCHOLOGIST      = "psicologa"
    SOCIAL_WORKER     = "assistente_social"
    NURSE             = "enfermeira"
    SECURITY          = "seguranca_hospitalar"
    CHILD_COUNCIL     = "conselho_tutelar"
    LEGAL             = "juridico_hospitalar"


# ===========================================================================
# MÓDULO 1 — TRATAMENTOS REPRODUTIVOS
# ===========================================================================

class ReproductiveTreatmentState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    age: int
    main_complaint: str          # queixa principal em texto livre
    condition: Optional[ReproductiveCondition]
    wants_to_conceive: bool      # desejo de gestar
    current_contraception: Optional[str]
    comorbidities: list[str]
    previous_treatments: list[str]
    hormone_contraindication: bool
    # Saída
    treatment_line: Optional[TreatmentLine]
    treatment_plan: Optional[str]
    non_pharmacological: list[str]
    followup_plan: Optional[str]
    referrals: list[str]
    sensitivity_notes: list[str]   # notas de abordagem trauma-informed
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


# Base de tratamentos por condição (em produção: RAG sobre FEBRASGO/NICE/ACOG)
REPRODUCTIVE_TREATMENTS: dict[ReproductiveCondition, dict] = {
    ReproductiveCondition.PCOS: {
        "descricao": "Síndrome dos Ovários Policísticos (SOP)",
        "primeira_linha": {
            "sem_desejo_gestar": [
                "Anticoncepcionais orais combinados (AOC) — regularização do ciclo e hiperandrogenismo",
                "Metformina 500-2000mg/dia — melhora resistência insulínica (IMC >25 ou alteração glicêmica)",
                "Mudança de estilo de vida: perda de 5-10% do peso melhora sintomas significativamente",
                "Espironolactona 50-200mg/dia — se hirsutismo intenso e AOC insuficiente",
            ],
            "com_desejo_gestar": [
                "Citrato de clomifeno 50-150mg/dia (ciclos D2-D6) — indução da ovulação 1ª linha",
                "Metformina adjuvante — melhora taxas de ovulação",
                "Perda de peso como medida prioritária antes de indução",
                "Letrozol 2,5-7,5mg/dia — alternativa ao clomifeno (evidência crescente, off-label no Brasil)",
            ],
        },
        "segunda_linha": {
            "sem_desejo_gestar": [
                "Análogos GnRH — casos graves com falha hormonal (uso limitado a 6 meses)",
                "Avaliação dermatológica para hirsutismo refratário",
            ],
            "com_desejo_gestar": [
                "Gonadotrofinas exógenas (FSH/hMG) — monitoração ultrassonográfica obrigatória",
                "Drilling ovariano laparoscópico — alternativa quando há falha clínica",
            ],
        },
        "nao_farmacologico": [
            "Dieta com baixo índice glicêmico",
            "Atividade física regular (150 min/semana resistência + aeróbico)",
            "Controle do estresse (cortisol piora resistência insulínica)",
            "Suporte psicológico — impacto na autoimagem e fertilidade",
        ],
        "followup": "Retorno em 3 meses com US pélvico, perfil androgênico e glicemia",
        "encaminhamentos": ["endocrinologia se resistência insulínica grave", "reprodução assistida se falha após 6 ciclos"],
    },

    ReproductiveCondition.ENDOMETRIOSIS: {
        "descricao": "Endometriose",
        "primeira_linha": {
            "sem_desejo_gestar": [
                "Dienogeste 2mg/dia — progestogênio de escolha, menor efeitos androgênicos",
                "AOC contínuo (sem pausa) — reduz dismenorreia e progressão",
                "DIU de levonorgestrel — excelente para dor pélvica crônica + amenorreia",
                "AINEs no período perimenstrual para analgesia",
            ],
            "com_desejo_gestar": [
                "Tratamento cirúrgico dos endometriomas ≥4cm antes de FIV",
                "Avaliação de reserva ovariana (AMH) antes de qualquer intervenção",
                "FIV como estratégia principal em endometriose moderada-grave + infertilidade",
                "Letrozol/gonadotrofinas para indução — sob supervisão especializada",
            ],
        },
        "segunda_linha": {
            "sem_desejo_gestar": [
                "Análogos GnRH com add-back therapy (estradiol 0,5mg + noretisterona 0,1mg)",
                "Denosumabe — em investigação para endometriose refratária",
            ],
            "com_desejo_gestar": [
                "Reprodução assistida de alta complexidade",
                "Avaliação em centro de referência para endometriose profunda",
            ],
        },
        "nao_farmacologico": [
            "Fisioterapia pélvica — disfunção de assoalho pélvico associada",
            "Psicoterapia — dor crônica tem forte componente psicoafetivo",
            "Acupuntura — evidência moderada para alívio da dor",
            "Calor local (bolsa de água quente) para crise álgica",
            "Dieta anti-inflamatória (ômega-3, redução de laticínios e glúten)",
        ],
        "followup": "US transvaginal semestral; CA-125 se endometrioma para monitorar resposta",
        "encaminhamentos": ["cirurgia minimamente invasiva se falha clínica", "reprodução assistida", "clínica de dor se refratária"],
    },

    ReproductiveCondition.UTERINE_FIBROIDS: {
        "descricao": "Miomatose Uterina",
        "primeira_linha": {
            "sem_desejo_gestar": [
                "DIU de levonorgestrel — reduz sangramento até 90%, controle de sintomas",
                "AOC ou progestogênios — para regularização do ciclo",
                "AINEs — alívio da dismenorreia associada",
                "Ácido tranexâmico — sangramento agudo intenso",
            ],
            "com_desejo_gestar": [
                "Miomectomia (histeroscópica ou laparoscópica) — preserva útero",
                "Análogos GnRH pré-operatório (2-3 meses) — reduz volume e vascularização",
                "Ulipristal acetato — evidência para redução pré-cirúrgica (monitorar hepatotoxicidade)",
            ],
        },
        "segunda_linha": {
            "sem_desejo_gestar": [
                "Embolização de artérias uterinas (EAU) — alternativa minimamente invasiva",
                "HIFU (ultrassom focalizado) — disponível em centros especializados",
                "Histerectomia — tratamento definitivo quando prole completa",
            ],
            "com_desejo_gestar": [
                "Miomectomia abdominal para miomas volumosos/múltiplos",
                "FIV após miomectomia se persistir infertilidade",
            ],
        },
        "nao_farmacologico": [
            "Suplementação de ferro se anemia ferropriva associada",
            "Controle do peso (estrogênio aumenta com tecido adiposo)",
            "Atividade física regular",
        ],
        "followup": "US pélvico a cada 6 meses para monitorar crescimento",
        "encaminhamentos": ["cirurgia minimamente invasiva", "hematologia se anemia grave"],
    },

    ReproductiveCondition.INFERTILITY: {
        "descricao": "Infertilidade",
        "primeira_linha": {
            "sem_desejo_gestar": ["N/A — condição definida pelo desejo de conceber"],
            "com_desejo_gestar": [
                "Investigação do casal: espermograma + HSG + reserva ovariana (AMH, CFA, FSH D3)",
                "Correção de fatores modificáveis: peso, tabagismo, álcool, tireoide",
                "Indução da ovulação se anovulação: clomifeno ou letrozol",
                "Coito programado com monitoração folicular (US seriado)",
                "Inseminação intrauterina (IUI) — indicação: fator masculino leve, alteração cervical",
            ],
        },
        "segunda_linha": {
            "com_desejo_gestar": [
                "FIV / ICSI — fator tubário bilateral, endometriose grave, falha de IUI",
                "Diagnóstico genético pré-implantação (PGT) — abortamento recorrente ou idade ≥38 anos",
                "Doação de óvulos — falência ovariana prematura",
            ],
        },
        "nao_farmacologico": [
            "Suplementação de ácido fólico 400-800mcg/dia (ambos os parceiros)",
            "Redução de estresse — psicoterapia para casais em tratamento",
            "Evitar exposição a disruptores endócrinos (bisfenol, pesticidas)",
            "Sono regulado — impacto no eixo reprodutivo",
        ],
        "followup": "Retorno mensal durante tentativas; reavaliação diagnóstica após 6 ciclos",
        "encaminhamentos": ["reprodução assistida", "urologia/andrologia para fator masculino", "genética se suspeita cromossômica"],
    },

    ReproductiveCondition.MENOPAUSE: {
        "descricao": "Menopausa e Climatério",
        "primeira_linha": {
            "sem_desejo_gestar": [
                "Terapia Hormonal da Menopausa (THM) sistêmica — sintomas vasomotores moderados/graves",
                "Via transdérmica preferível (menor risco tromboembólico vs. oral)",
                "Estrogênio tópico vaginal — atrofia urogenital (seguro mesmo em CA mama em alguns casos)",
                "Tibolona — alternativa com efeito combinado estrogênio/progestogênio/androgênio",
            ],
            "com_desejo_gestar": [
                "Inseminação com óvulos doados — única opção após falência ovariana completa",
                "Avaliar reserva ovariana residual se perimenopausa",
            ],
        },
        "segunda_linha": {
            "sem_desejo_gestar": [
                "ISRS/IRSN — fogachos quando THM contraindicada (paroxetina 7,5mg, venlafaxina 37,5mg)",
                "Gabapentina 300mg/noite — fogachos noturnos",
                "Ospemifeno — atrofia vaginal sem uso de estrogênio local",
                "Bifosfonatos — osteoporose instalada",
            ],
        },
        "nao_farmacologico": [
            "Atividade física de resistência e aeróbica — reduz fogachos e protege ossos",
            "Isoflavonas de soja — evidência moderada para fogachos leves",
            "Técnicas de relaxamento e mindfulness — qualidade do sono",
            "Lubrificantes e umectantes vaginais — sem prescrição, para conforto imediato",
            "Suporte em grupo — validação da experiência do climatério",
        ],
        "followup": "Densitometria óssea; perfil lipídico; mamografia e preventivo anuais",
        "encaminhamentos": ["cardiologia se fator de risco cardiovascular", "reumatologia se osteoporose grave"],
    },

    ReproductiveCondition.MENSTRUAL_DISORDER: {
        "descricao": "Distúrbio Menstrual (DUB, dismenorreia, amenorreia)",
        "primeira_linha": {
            "sem_desejo_gestar": [
                "AOC — regularização em ciclos irregulares, redução de fluxo",
                "AINEs (naproxeno, ibuprofeno) — dismenorreia primária",
                "Progestogênio cíclico (D16-D25) — fase lútea insuficiente",
                "DIU de levonorgestrel — menorragia",
            ],
            "com_desejo_gestar": [
                "Investigar causa base: TSH, prolactina, FSH/LH, US pélvico",
                "Tratamento etiológico conforme diagnóstico",
                "Indução da ovulação se anovulação crônica",
            ],
        },
        "segunda_linha": {
            "sem_desejo_gestar": [
                "Análogos GnRH para casos refratários",
                "Ablação endometrial — menorragia refratária com prole completa",
            ],
        },
        "nao_farmacologico": [
            "Calor local para dismenorreia",
            "Exercício físico regular — reduz dismenorreia primária",
            "Redução de sal e cafeína no período pré-menstrual",
            "Magnésio 250mg/dia — TPM associada",
        ],
        "followup": "Reavaliação após 3 ciclos de tratamento",
        "encaminhamentos": ["hematologia se coagulopatia suspeita", "endocrinologia se alteração tireoidiana"],
    },

    ReproductiveCondition.RECURRENT_ABORTION: {
        "descricao": "Abortamento Recorrente (≥2 perdas consecutivas)",
        "primeira_linha": {
            "com_desejo_gestar": [
                "Investigação completa do casal: cariótipo, síndrome antifosfolípide, US 3D, histeroscopia",
                "Ácido fólico + vitamina D antes de nova tentativa",
                "Progesterona vaginal 200-400mg/dia até 12 semanas — em casos selecionados",
                "Anticoagulação (heparina + AAS) — síndrome antifosfolípide confirmada",
                "Suporte emocional estruturado ANTES, DURANTE e APÓS a gestação",
            ],
        },
        "segunda_linha": {
            "com_desejo_gestar": [
                "PGT-A (diagnóstico genético pré-implantação) — anomalia cromossômica do casal",
                "Cirurgia corretiva — septo uterino, mioma submucoso, incompetência istmo-cervical",
                "Imunoterapia — em investigação para casos imunológicos",
            ],
        },
        "nao_farmacologico": [
            "Psicoterapia — luto gestacional e ansiedade antecipatória",
            "Grupos de apoio para perda gestacional",
            "Evitar tabagismo, álcool e exposições tóxicas",
        ],
        "followup": "Pré-natal de alto risco assim que nova gestação confirmada",
        "encaminhamentos": ["genética médica", "hematologia (antifosfolípide)", "reprodução assistida"],
    },

    ReproductiveCondition.GENERAL: {
        "descricao": "Queixa Reprodutiva Geral",
        "primeira_linha": {
            "sem_desejo_gestar": ["Avaliar queixa específica e iniciar investigação dirigida"],
            "com_desejo_gestar": ["Investigação básica de fertilidade do casal"],
        },
        "segunda_linha": {"sem_desejo_gestar": [], "com_desejo_gestar": []},
        "nao_farmacologico": ["Estilo de vida saudável", "Suporte emocional"],
        "followup": "Retorno em 4-6 semanas",
        "encaminhamentos": ["ginecologia especializada conforme diagnóstico"],
    },
}

# Mapa de palavras-chave para condição
CONDITION_KEYWORDS: dict[str, ReproductiveCondition] = {
    "sop": ReproductiveCondition.PCOS,
    "policístico": ReproductiveCondition.PCOS,
    "ovário policístico": ReproductiveCondition.PCOS,
    "endometriose": ReproductiveCondition.ENDOMETRIOSIS,
    "endometrioma": ReproductiveCondition.ENDOMETRIOSIS,
    "mioma": ReproductiveCondition.UTERINE_FIBROIDS,
    "miomatose": ReproductiveCondition.UTERINE_FIBROIDS,
    "infertil": ReproductiveCondition.INFERTILITY,
    "fertilidade": ReproductiveCondition.INFERTILITY,
    "engravidar": ReproductiveCondition.INFERTILITY,
    "fiv": ReproductiveCondition.INFERTILITY,
    "menopausa": ReproductiveCondition.MENOPAUSE,
    "climatério": ReproductiveCondition.MENOPAUSE,
    "fogacho": ReproductiveCondition.MENOPAUSE,
    "menstruação irregular": ReproductiveCondition.MENSTRUAL_DISORDER,
    "dismenorreia": ReproductiveCondition.MENSTRUAL_DISORDER,
    "amenorreia": ReproductiveCondition.MENSTRUAL_DISORDER,
    "sangramento": ReproductiveCondition.MENSTRUAL_DISORDER,
    "abortamento": ReproductiveCondition.RECURRENT_ABORTION,
    "aborto recorrente": ReproductiveCondition.RECURRENT_ABORTION,
    "perda gestacional": ReproductiveCondition.RECURRENT_ABORTION,
}

# Notas de sensibilidade por condição
SENSITIVITY_NOTES: dict[ReproductiveCondition, list[str]] = {
    ReproductiveCondition.INFERTILITY: [
        "Abordar o tema com empatia — infertilidade causa impacto emocional profundo no casal.",
        "Respeitar o ritmo da paciente para decisões sobre reprodução assistida.",
        "Incluir o(a) parceiro(a) no processo de forma igualitária, sem culpabilização.",
        "Oferecer suporte psicológico desde o início, não apenas após falhas de tratamento.",
    ],
    ReproductiveCondition.RECURRENT_ABORTION: [
        "Validar o luto gestacional — cada perda é uma perda real, independente da idade gestacional.",
        "Evitar minimizações como 'da próxima vai'.",
        "Oferecer espaço seguro para expressar sentimentos antes de tratar clinicamente.",
        "Garantir suporte psicológico estruturado ao longo de todo o processo.",
    ],
    ReproductiveCondition.MENOPAUSE: [
        "Desmistificar a menopausa como 'fim da vida' — é uma transição natural.",
        "Respeitar a decisão da paciente sobre THM após informação completa.",
        "Valorizar a sexualidade e qualidade de vida nesta fase.",
        "Abordar mudanças corporais sem julgamento estético.",
    ],
    ReproductiveCondition.ENDOMETRIOSIS: [
        "Validar a dor — endometriose frequentemente é subestimada ou negligenciada.",
        "Respeitar o desejo reprodutivo na escolha do tratamento.",
        "Informar sobre impacto na fertilidade sem gerar ansiedade desnecessária.",
        "Reconhecer o impacto na qualidade de vida, trabalho e relacionamentos.",
    ],
    ReproductiveCondition.PCOS: [
        "Abordar mudanças estéticas (hirsutismo, acne) com sensibilidade.",
        "Não responsabilizar a paciente pelo peso — SOP tem forte componente hormonal.",
        "Discutir implicações reprodutivas de forma informativa, não alarmista.",
    ],
    ReproductiveCondition.SEXUAL_DYSFUNCTION: [
        "Criar ambiente de acolhimento total — muitas mulheres nunca falaram sobre isso com profissional.",
        "Linguagem não-julgadora e aberta a diferentes orientações sexuais.",
        "Investigar história de abuso ou trauma antes de qualquer abordagem.",
        "Incluir parceiro apenas com consentimento explícito da paciente.",
    ],
}


def identify_reproductive_condition(state: ReproductiveTreatmentState) -> ReproductiveTreatmentState:
    """Nó 1 — Identifica a condição reprodutiva pela queixa principal."""
    complaint = state["main_complaint"].lower()
    detected = ReproductiveCondition.GENERAL

    for keyword, condition in CONDITION_KEYWORDS.items():
        if keyword in complaint:
            detected = condition
            break

    logger.info(f"Condição reprodutiva identificada: {detected.value}")
    return {
        **state,
        "condition": detected,
        "current_step": "condition_identified",
        "audit_log": _audit(state, "identify_condition", {"condition": detected.value}),
    }


def build_treatment_plan(state: ReproductiveTreatmentState) -> ReproductiveTreatmentState:
    """Nó 2 — Monta o plano terapêutico baseado na condição e perfil da paciente."""
    condition = state.get("condition", ReproductiveCondition.GENERAL)
    wants_conceive = state.get("wants_to_conceive", False)
    comorbidities = state.get("comorbidities", [])
    previous = state.get("previous_treatments", [])
    hormone_ci = state.get("hormone_contraindication", False)
    age = state.get("age", 30)

    knowledge = REPRODUCTIVE_TREATMENTS.get(condition, REPRODUCTIVE_TREATMENTS[ReproductiveCondition.GENERAL])
    desire_key = "com_desejo_gestar" if wants_conceive else "sem_desejo_gestar"

    # Determinar linha de tratamento
    if previous:
        line = TreatmentLine.SECOND
        options = knowledge.get("segunda_linha", {}).get(desire_key, [])
        if not options:
            options = knowledge.get("segunda_linha", {}).get("sem_desejo_gestar", [])
    else:
        line = TreatmentLine.FIRST
        options = knowledge.get("primeira_linha", {}).get(desire_key, [])

    # Filtrar hormônios se contraindicado
    if hormone_ci:
        options = [o for o in options if not any(
            term in o.lower() for term in ["aoc", "anticoncepcional", "estrogênio", "progesterona combinada", "thm"]
        )]

    # Ajustes por comorbidade
    adjustments = []
    if any("diabetes" in c.lower() or "resistência insulínica" in c.lower() for c in comorbidities):
        adjustments.append("⚠️ Priorizar metformina e controle glicêmico no plano terapêutico.")
    if any("tireoid" in c.lower() for c in comorbidities):
        adjustments.append("⚠️ Normalizar TSH antes de iniciar tratamento hormonal ou indução ovulatória.")
    if any("hipertensão" in c.lower() or "cardio" in c.lower() for c in comorbidities):
        adjustments.append("⚠️ Evitar estrogênios orais — preferir via transdérmica ou métodos não hormonais.")
    if age >= 40 and wants_conceive:
        adjustments.append("⚠️ Idade ≥40 anos: discutir impacto na reserva ovariana e opções de reprodução assistida com urgência.")

    # Montar plano
    plan_parts = [f"**{knowledge['descricao']} — Plano Terapêutico ({line.value.replace('_',' ').title()})**\n"]

    if wants_conceive:
        plan_parts.append("🌸 *Contexto: paciente com desejo de gestar — plano orientado à fertilidade.*\n")
    else:
        plan_parts.append("💊 *Contexto: tratamento sintomático — sem desejo de gestar no momento.*\n")

    plan_parts.append("**Opções terapêuticas:**")
    for i, opt in enumerate(options, 1):
        plan_parts.append(f"{i}. {opt}")

    if adjustments:
        plan_parts.append("\n**Ajustes por comorbidades:**")
        plan_parts.extend(adjustments)

    non_pharma = knowledge.get("nao_farmacologico", [])
    referrals = knowledge.get("encaminhamentos", [])
    followup = knowledge.get("followup", "Reavaliação em 4-6 semanas.")

    return {
        **state,
        "treatment_line": line,
        "treatment_plan": "\n".join(plan_parts),
        "non_pharmacological": non_pharma,
        "followup_plan": followup,
        "referrals": referrals,
        "current_step": "plan_built",
        "audit_log": _audit(state, "build_treatment_plan", {
            "condition": condition.value,
            "line": line.value,
            "options_count": len(options),
        }),
    }


def add_sensitivity_guidance(state: ReproductiveTreatmentState) -> ReproductiveTreatmentState:
    """Nó 3 — Adiciona notas de abordagem trauma-informed e sensibilidade feminina."""
    condition = state.get("condition", ReproductiveCondition.GENERAL)
    notes = SENSITIVITY_NOTES.get(condition, [])

    # Notas universais de atendimento feminino
    universal = [
        "Iniciar a consulta com escuta ativa antes de qualquer intervenção clínica.",
        "Garantir privacidade — nunca discutir o caso em locais com outros presentes.",
        "Perguntar sobre rede de apoio (família, parceiro) antes de assumir sua existência.",
        "Respeitar o tempo da paciente para processar informações e tomar decisões.",
    ]

    all_notes = notes + universal

    # Montar mensagem final
    full_response = state.get("treatment_plan", "") + \
        "\n\n**🌸 Medidas não farmacológicas recomendadas:**\n" + \
        "\n".join(f"- {m}" for m in state.get("non_pharmacological", [])) + \
        "\n\n**📅 Seguimento:** " + (state.get("followup_plan") or "") + \
        "\n\n**🔗 Encaminhamentos sugeridos:**\n" + \
        "\n".join(f"- {r}" for r in state.get("referrals", [])) + \
        "\n\n**💜 Abordagem trauma-informed:**\n" + \
        "\n".join(f"- {n}" for n in all_notes)

    return {
        **state,
        "sensitivity_notes": all_notes,
        "current_step": "completed",
        "audit_log": _audit(state, "add_sensitivity", {"notes_count": len(all_notes)}),
        "messages": state["messages"] + [AIMessage(content=full_response)],
    }


def build_reproductive_treatment_graph() -> StateGraph:
    """Constrói o grafo de sugestão de tratamentos reprodutivos."""
    graph = StateGraph(ReproductiveTreatmentState)
    graph.add_node("identify_condition", identify_reproductive_condition)
    graph.add_node("build_plan", build_treatment_plan)
    graph.add_node("add_sensitivity", add_sensitivity_guidance)

    graph.set_entry_point("identify_condition")
    graph.add_edge("identify_condition", "build_plan")
    graph.add_edge("build_plan", "add_sensitivity")
    graph.add_edge("add_sensitivity", END)

    return graph.compile(checkpointer=MemorySaver())


# ===========================================================================
# MÓDULO 2 — ALERTAS PARA VIOLÊNCIA DOMÉSTICA (aprofundado)
# ===========================================================================

class VDAlertState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    professional_id: str
    consultation_notes: str
    # Sinais detectados
    physical_signs: list[str]
    behavioral_signs: list[str]
    contextual_signs: list[str]   # contradições, histórico, padrão
    # Avaliação
    alert_level: Optional[VDAlertLevel]
    immediate_risk: bool
    children_involved: bool
    elder_involved: bool
    # Protocolo de alerta
    sinan_required: bool
    immediate_actions: list[str]
    clinical_conduct: list[str]
    legal_obligations: list[str]
    safety_plan: list[str]
    support_resources: list[str]
    trauma_informed_approach: list[str]
    # Documentação
    documentation_id: Optional[str]
    alert_message: Optional[str]
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


PHYSICAL_SIGNS = [
    "hematoma", "equimose", "fratura", "luxação", "lesão", "queimadura",
    "marca", "corte", "cicatriz", "lesão genital", "trauma craniano",
    "costela quebrada", "ruptura timpânica", "estrangulamento", "enforcamento",
    "mordida", "afogamento", "marca de corda", "olho roxo", "dente quebrado",
]

BEHAVIORAL_SIGNS = [
    "evasiva", "nervosa", "acompanhante fala por ela", "contradição no relato",
    "medo", "choro", "ansiedade extrema", "depressão", "insônia",
    "não mantém contato visual", "submissa", "pediu para o marido sair",
    "consulta adiada várias vezes", "vestimenta cobre lesões", "tremendo",
    "não consegue responder sozinha", "olha para a porta", "surpresa com gentileza",
]

CONTEXTUAL_SIGNS = [
    "parceiro não deixa ela falar", "explicação inconsistente com lesão",
    "demora em buscar atendimento", "múltiplas visitas ao pronto-socorro",
    "lesões em diferentes estágios de cicatrização", "isolamento social",
    "afastamento de família e amigos", "dependência financeira total",
    "gravidez não desejada repetida", "histórico de tentativa de suicídio",
    "uso de substâncias como enfrentamento", "abuso durante a gravidez",
]

IMMEDIATE_ACTIONS_BY_LEVEL: dict[VDAlertLevel, list[str]] = {
    VDAlertLevel.CRITICAL: [
        "🚨 Acionar segurança hospitalar IMEDIATAMENTE",
        "🚨 Isolar a paciente do acompanhante/agressor com pretexto clínico",
        "🚨 Acionar equipe de crise e psicologia de plantão",
        "🚨 Não liberar a paciente sem plano de segurança documentado",
        "🚨 Fotografar lesões com consentimento e registrar no prontuário restrito",
        "🚨 Notificar SINAN imediatamente",
        "🚨 Se há crianças: acionar Conselho Tutelar nas próximas 24h",
        "🚨 Oferecer Casa Abrigo e contato da Delegacia da Mulher",
    ],
    VDAlertLevel.HIGH: [
        "⚠️ Separar a paciente do acompanhante para conversa privada",
        "⚠️ Preencher ficha SINAN antes do fim do atendimento",
        "⚠️ Acionar assistente social ainda neste atendimento",
        "⚠️ Fotografar e documentar lesões detalhadamente",
        "⚠️ Elaborar plano de segurança com a paciente",
        "⚠️ Fornecer lista de recursos (Central 180, Delegacia da Mulher, CRAM)",
        "⚠️ Agendar retorno em 7-14 dias com equipe multidisciplinar",
    ],
    VDAlertLevel.MODERATE: [
        "Criar espaço privado para conversa — sem julgamentos",
        "Perguntar diretamente sobre violência de forma acolhedora",
        "Oferecer materiais informativos discretamente (dentro da receita, bolsa da paciente)",
        "Registrar suspeita no prontuário com linguagem clínica objetiva",
        "Agendar retorno com psicologia",
        "Notificar SINAN se houver confirmação ou suspeita fundamentada",
    ],
    VDAlertLevel.WATCH: [
        "Manter suspeita clínica ativa — registrar no prontuário",
        "Perguntar sobre bem-estar geral em próximas consultas",
        "Construir vínculo terapêutico para facilitar revelação futura",
        "Não pressionar — cada pessoa revela no seu tempo",
    ],
}

TRAUMA_INFORMED_APPROACH = [
    "Começar com: 'Estou aqui para te ajudar, sem julgamentos. Pode me contar o que aconteceu.'",
    "Nunca perguntar 'Por que você não foi embora?' — foco na segurança, não na decisão da vítima.",
    "Acreditar no relato sem questionamentos — a dúvida retraumatiza.",
    "Respeitar se ela não quiser revelar agora — registrar suspeita e manter vínculo.",
    "Oferecer escolhas em tudo: 'Você prefere falar agora ou em outro momento?'",
    "Garantir sigilo e explicar os limites legais da confidencialidade.",
    "Validar sentimentos: 'Faz sentido você estar com medo. Isso não é culpa sua.'",
    "Não exigir registro de boletim de ocorrência como condição para atendimento.",
    "Cuidado com o próprio tom de voz e linguagem corporal — transmitir calma e segurança.",
]

SUPPORT_RESOURCES = [
    "Central de Atendimento à Mulher — Ligue 180 (24h, gratuito, sigiloso)",
    "DEAM — Delegacia Especializada de Atendimento à Mulher",
    "CRAM — Centro de Referência de Atendimento à Mulher",
    "Casa Abrigo — acolhimento emergencial com filhos",
    "Ministério Público — Promotoria da Mulher",
    "IML — Instituto Médico-Legal (lesões corporais)",
    "CREAS — Centro de Referência Especializado de Assistência Social",
    "Defensoria Pública — orientação jurídica gratuita",
]


def deep_sign_detection(state: VDAlertState) -> VDAlertState:
    """Nó 1 — Detecção aprofundada de sinais (físicos, comportamentais e contextuais)."""
    text = state["consultation_notes"].lower()

    physical = [s for s in PHYSICAL_SIGNS if s in text]
    behavioral = [s for s in BEHAVIORAL_SIGNS if s in text]
    contextual = [s for s in CONTEXTUAL_SIGNS if s in text]

    logger.info(f"VD Alert: físicos={len(physical)}, comportamentais={len(behavioral)}, contextuais={len(contextual)}")

    return {
        **state,
        "physical_signs": physical,
        "behavioral_signs": behavioral,
        "contextual_signs": contextual,
        "current_step": "signs_detected",
        "audit_log": _audit(state, "deep_sign_detection", {
            "physical": len(physical),
            "behavioral": len(behavioral),
            "contextual": len(contextual),
        }),
    }


def calculate_alert_level(state: VDAlertState) -> VDAlertState:
    """Nó 2 — Calcula nível de alerta e risco imediato."""
    physical = len(state.get("physical_signs", []))
    behavioral = len(state.get("behavioral_signs", []))
    contextual = len(state.get("contextual_signs", []))
    text = state["consultation_notes"].lower()

    # Indicadores de risco imediato à vida
    critical_keywords = [
        "ameaça de morte", "arma", "estrangulamento", "tentou me matar",
        "não me deixa sair", "está aqui fora", "vai me matar",
        "me bateu grávida", "perdeu o bebê por causa dele"
    ]
    immediate_risk = any(kw in text for kw in critical_keywords) or physical >= 3

    if immediate_risk or (physical >= 2 and behavioral >= 2):
        level = VDAlertLevel.CRITICAL
    elif physical >= 2 or (physical >= 1 and (behavioral + contextual) >= 2):
        level = VDAlertLevel.HIGH
    elif physical == 1 or (behavioral + contextual) >= 3:
        level = VDAlertLevel.MODERATE
    elif (behavioral + contextual) >= 1:
        level = VDAlertLevel.WATCH
    else:
        level = VDAlertLevel.WATCH  # default: sempre manter vigilância

    children = any(w in text for w in ["filho", "criança", "menor", "bebê", "filho dela"])
    elder = any(w in text for w in ["idosa", "mãe dela", "avó", "sogra"])

    return {
        **state,
        "alert_level": level,
        "immediate_risk": immediate_risk,
        "children_involved": children,
        "elder_involved": elder,
        "sinan_required": level in (VDAlertLevel.CRITICAL, VDAlertLevel.HIGH, VDAlertLevel.MODERATE),
        "current_step": "level_calculated",
        "audit_log": _audit(state, "calculate_alert_level", {
            "level": level.value,
            "immediate_risk": immediate_risk,
        }),
    }


def build_vd_protocol(state: VDAlertState) -> VDAlertState:
    """Nó 3 — Monta protocolo de alerta completo com conduta clínica e legal."""
    level = state.get("alert_level", VDAlertLevel.WATCH)
    immediate_actions = IMMEDIATE_ACTIONS_BY_LEVEL.get(level, [])

    clinical_conduct = [
        "Registrar todos os achados objetivamente no prontuário (lesões, relato entre aspas, comportamento)",
        "Fotografar lesões visíveis com consentimento informado",
        "Solicitar avaliação de lesões pelo IML se possível e indicado",
        "Oferecer profilaxia IST se houver suspeita de violência sexual (AZT 300mg, 3TC 150mg, início até 72h)",
        "Oferecer contracepção de emergência se violência sexual recente (até 120h)",
        "Verificar vacinação anti-hepatite B e anti-HPV",
        "Encaminhar para saúde mental — trauma agudo e TEPT são esperados",
    ]

    legal_obligations = [
        "Lei 10.778/2003 — Notificação compulsória OBRIGATÓRIA independente de consentimento da vítima",
        "Ficha de Notificação SINAN — preencher e encaminhar à Vigilância Epidemiológica",
        "Lei Maria da Penha (11.340/2006) — conhecer medidas protetivas disponíveis para informar a paciente",
    ]

    if state.get("children_involved"):
        legal_obligations.append(
            "ECA Art. 13 — Notificação ao Conselho Tutelar OBRIGATÓRIA quando há crianças em risco"
        )
    if state.get("elder_involved"):
        legal_obligations.append(
            "Estatuto do Idoso — Notificação quando há idosa em situação de risco"
        )

    safety_plan = [
        "Perguntar: 'Você tem um lugar seguro para ir se precisar sair de casa rapidamente?'",
        "Orientar sobre documentos essenciais para ter acessíveis (RG, CPF, certidão de nascimento dos filhos)",
        "Combinar um 'código' com familiar/amigo de confiança para pedir ajuda",
        "Guardar contatos de emergência em local secreto",
        "Conhecer a rota de saída mais segura da residência",
    ]

    # Montar alerta estruturado
    level_emoji = {"CRITICO": "🚨", "ALTO": "⚠️", "MODERADO": "🟡", "VIGILÂNCIA": "👁️"}
    emoji = level_emoji.get(level.value, "⚠️")

    alert_msg = (
        f"{emoji} **ALERTA DE VIOLÊNCIA DOMÉSTICA — NÍVEL {level.value}**\n\n"
        f"**Sinais identificados:**\n"
        f"- Físicos: {', '.join(state.get('physical_signs', [])) or 'Nenhum documentado'}\n"
        f"- Comportamentais: {', '.join(state.get('behavioral_signs', [])) or 'Nenhum documentado'}\n"
        f"- Contextuais: {', '.join(state.get('contextual_signs', [])) or 'Nenhum documentado'}\n\n"
        f"**Risco imediato à vida:** {'SIM — AÇÃO URGENTE' if state.get('immediate_risk') else 'Não identificado'}\n"
        f"**Crianças envolvidas:** {'SIM — Notificar Conselho Tutelar' if state.get('children_involved') else 'Não identificado'}\n"
        f"**Notificação SINAN:** {'OBRIGATÓRIA' if state.get('sinan_required') else 'Avaliar'}\n"
    )

    import hashlib
    doc_id = "VDA-" + hashlib.sha256(
        f"{state['patient_id']}{datetime.utcnow().isoformat()}".encode()
    ).hexdigest()[:10]

    return {
        **state,
        "immediate_actions": immediate_actions,
        "clinical_conduct": clinical_conduct,
        "legal_obligations": legal_obligations,
        "safety_plan": safety_plan,
        "support_resources": SUPPORT_RESOURCES,
        "trauma_informed_approach": TRAUMA_INFORMED_APPROACH,
        "documentation_id": doc_id,
        "alert_message": alert_msg,
        "current_step": "protocol_built",
        "audit_log": _audit(state, "build_protocol", {
            "doc_id": doc_id,
            "sinan": state.get("sinan_required"),
        }),
        "messages": state["messages"] + [AIMessage(content=alert_msg)],
    }


def build_vd_alert_graph() -> StateGraph:
    """Constrói o grafo de alertas de violência doméstica aprofundado."""
    graph = StateGraph(VDAlertState)
    graph.add_node("detect_signs", deep_sign_detection)
    graph.add_node("calculate_level", calculate_alert_level)
    graph.add_node("build_protocol", build_vd_protocol)

    graph.set_entry_point("detect_signs")
    graph.add_edge("detect_signs", "calculate_level")
    graph.add_edge("calculate_level", "build_protocol")
    graph.add_edge("build_protocol", END)

    return graph.compile(checkpointer=MemorySaver())


# ===========================================================================
# MÓDULO 3 — COORDENAÇÃO MULTIDISCIPLINAR
# ===========================================================================

class MultidisciplinaryState(TypedDict):
    messages: Annotated[list, add_messages]
    patient_id: str
    case_type: str         # "vd", "reproductive", "oncology", "obstetric", "mental_health"
    case_summary: str      # resumo clínico do caso
    urgency: str           # "imediata", "24h", "72h", "eletivo"
    alert_level: Optional[str]
    # Equipe
    required_roles: list[str]
    team_assignments: list[dict]    # [{role, professional, action, deadline, priority}]
    coordination_plan: Optional[str]
    communication_protocol: list[str]
    followup_schedule: list[dict]   # [{date, responsible, objective}]
    # Sensibilidade
    case_sensitivities: list[str]
    # Controle
    current_step: str
    audit_log: list[dict]
    error: Optional[str]


# Mapa de tipo de caso → equipe necessária
CASE_TEAM_MAP: dict[str, list[dict]] = {
    "vd": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "alta",
         "action": "Avaliação clínica completa, tratamento de lesões, notificação SINAN, profilaxia IST/contracepção emergência"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "alta",
         "action": "Acolhimento em crise, avaliação de TEPT, plano terapêutico de suporte ao trauma"},
        {"role": TeamRole.SOCIAL_WORKER, "priority": "alta",
         "action": "Mapeamento da rede de apoio, orientação jurídica, contato com Casa Abrigo e CRAM, plano de segurança"},
        {"role": TeamRole.NURSE, "priority": "média",
         "action": "Coleta de materiais (se violência sexual), cuidados de enfermagem, orientação sobre recursos"},
    ],
    "vd_critical": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "imediata",
         "action": "Avaliação e estabilização clínica, notificação SINAN, profilaxia completa"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "imediata",
         "action": "Crise aguda — intervenção imediata, avaliar risco de suicídio"},
        {"role": TeamRole.SOCIAL_WORKER, "priority": "imediata",
         "action": "Acionar Casa Abrigo, plano de fuga segura, contato emergencial com família"},
        {"role": TeamRole.SECURITY, "priority": "imediata",
         "action": "Garantir segurança física da paciente no hospital — impedir acesso do agressor"},
        {"role": TeamRole.LEGAL, "priority": "alta",
         "action": "Orientar sobre medida protetiva de urgência (Lei Maria da Penha)"},
    ],
    "reproductive": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "alta",
         "action": "Investigação diagnóstica, prescrição, acompanhamento clínico principal"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "média",
         "action": "Suporte emocional — impacto psicológico de condições reprodutivas, luto, ansiedade"},
        {"role": TeamRole.NURSE, "priority": "média",
         "action": "Educação em saúde, orientação sobre medicamentos, acompanhamento de adesão"},
    ],
    "infertility": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "alta",
         "action": "Investigação e tratamento — coordenar com reprodução assistida se indicado"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "alta",
         "action": "Suporte ao casal — luto por infertilidade, apoio durante tratamentos"},
        {"role": TeamRole.SOCIAL_WORKER, "priority": "baixa",
         "action": "Orientação sobre cobertura de plano de saúde, adoção se desejado"},
    ],
    "mental_health": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "média",
         "action": "Avaliar causas hormonais (TPM grave, depressão pós-parto, menopausa)"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "alta",
         "action": "Psicoterapia, avaliação diagnóstica, encaminhamento para psiquiatria se necessário"},
        {"role": TeamRole.SOCIAL_WORKER, "priority": "média",
         "action": "Suporte à rede social, CAPS se necessário, benefícios assistenciais"},
        {"role": TeamRole.NURSE, "priority": "baixa",
         "action": "Monitoramento de risco, orientação a familiares"},
    ],
    "obstetric": [
        {"role": TeamRole.GYNECOLOGIST, "priority": "alta",
         "action": "Acompanhamento pré-natal, gestão de risco, decisão sobre via de parto"},
        {"role": TeamRole.NURSE, "priority": "alta",
         "action": "Consultas de enfermagem pré-natal, vacinação, orientações gerais"},
        {"role": TeamRole.PSYCHOLOGIST, "priority": "média",
         "action": "Suporte emocional gestacional, preparação para o parto, DPP pós-natal"},
        {"role": TeamRole.SOCIAL_WORKER, "priority": "baixa",
         "action": "Suporte social — gestantes em situação de vulnerabilidade"},
    ],
}

CASE_SENSITIVITIES: dict[str, list[str]] = {
    "vd": [
        "SIGILO ABSOLUTO — não discutir o caso em locais visíveis ou com o acompanhante",
        "Toda a comunicação entre equipe via sistema seguro — não usar papel ou conversa de corredor",
        "A paciente lidera as decisões — equipe apoia, não decide por ela",
        "Cuidado com retraumatização — cada membro deve ser treinado para não repetir a mesma pergunta",
        "Se a paciente retornar ao agressor, não julgá-la — manter vínculo e porta aberta",
    ],
    "reproductive": [
        "Desejo reprodutivo é da paciente — nunca pressionar ou minimizar",
        "Privacidade sobre diagnóstico — não compartilhar com familiar sem autorização",
        "Discutir alternativas completas — a decisão final é da paciente e parceiro(a)",
    ],
    "infertility": [
        "Não usar linguagem de 'falha' — usar 'tentativa', 'processo', 'jornada'",
        "Respeitar a decisão de interromper tratamentos a qualquer momento",
        "Luto por infertilidade é real e merece espaço terapêutico",
    ],
    "mental_health": [
        "Nunca minimizar sintomas psiquiátricos com frases como 'é hormônio' ou 'vai passar'",
        "Risco de suicídio requer avaliação imediata — não deixar a paciente aguardando",
        "Coordenar medicação entre ginecologista e psiquiatra para evitar interações",
    ],
    "obstetric": [
        "Plano de parto deve ser respeitado — comunicar toda a equipe",
        "Gestante vulnerável pode precisar de assistente social desde o início do pré-natal",
        "DPP pode aparecer até 1 ano após o parto — rastrear ativamente",
    ],
}


def determine_required_team(state: MultidisciplinaryState) -> MultidisciplinaryState:
    """Nó 1 — Determina a equipe necessária conforme o tipo e urgência do caso."""
    case_type = state["case_type"].lower()
    urgency = state.get("urgency", "eletivo")
    alert_level = state.get("alert_level", "")

    # Selecionar mapa de equipe
    if case_type == "vd" and (urgency == "imediata" or alert_level == "CRITICO"):
        team_key = "vd_critical"
    elif case_type in CASE_TEAM_MAP:
        team_key = case_type
    else:
        team_key = "reproductive"  # default

    team_template = CASE_TEAM_MAP.get(team_key, CASE_TEAM_MAP["reproductive"])
    required_roles = [t["role"].value for t in team_template]

    logger.info(f"Equipe determinada para {case_type}: {required_roles}")

    return {
        **state,
        "required_roles": required_roles,
        "case_sensitivities": CASE_SENSITIVITIES.get(case_type, []),
        "current_step": "team_determined",
        "audit_log": _audit(state, "determine_team", {
            "case_type": case_type,
            "team_size": len(required_roles),
        }),
    }


def assign_responsibilities(state: MultidisciplinaryState) -> MultidisciplinaryState:
    """Nó 2 — Atribui responsabilidades, ações e prazos a cada membro da equipe."""
    case_type = state["case_type"].lower()
    urgency = state.get("urgency", "eletivo")
    alert_level = state.get("alert_level", "")

    if case_type == "vd" and (urgency == "imediata" or alert_level == "CRITICO"):
        team_key = "vd_critical"
    elif case_type in CASE_TEAM_MAP:
        team_key = case_type
    else:
        team_key = "reproductive"

    team_template = CASE_TEAM_MAP.get(team_key, [])

    # Calcular prazos baseados na urgência
    deadline_map = {
        "imediata": "AGORA — acionar imediatamente",
        "24h": "Até 24 horas",
        "72h": "Até 72 horas",
        "eletivo": "Na próxima semana",
    }

    assignments = []
    for member in team_template:
        role_priority = member["priority"]
        if role_priority == "imediata":
            deadline = "AGORA"
        elif role_priority == "alta":
            deadline = deadline_map.get(urgency, "Até 72 horas")
        elif role_priority == "média":
            deadline = "Até 7 dias"
        else:
            deadline = "Eletivo — conforme disponibilidade"

        assignments.append({
            "papel": member["role"].value,
            "prioridade": role_priority,
            "ação": member["action"],
            "prazo": deadline,
            "status": "pendente",
        })

    # Cronograma de seguimento
    today = datetime.utcnow()
    followup = [
        {"data": (today + timedelta(days=3)).strftime("%d/%m/%Y"),
         "responsável": "Assistente Social",
         "objetivo": "Verificar segurança e rede de apoio"},
        {"data": (today + timedelta(days=7)).strftime("%d/%m/%Y"),
         "responsável": "Psicóloga",
         "objetivo": "Sessão de acompanhamento — processo emocional"},
        {"data": (today + timedelta(days=14)).strftime("%d/%m/%Y"),
         "responsável": "Ginecologista",
         "objetivo": "Reavaliação clínica e exames"},
        {"data": (today + timedelta(days=30)).strftime("%d/%m/%Y"),
         "responsável": "Equipe multidisciplinar",
         "objetivo": "Reunião de caso — evolução e ajuste do plano"},
    ]

    return {
        **state,
        "team_assignments": assignments,
        "followup_schedule": followup,
        "current_step": "responsibilities_assigned",
        "audit_log": _audit(state, "assign_responsibilities", {
            "assignments": len(assignments),
        }),
    }


def generate_coordination_plan(state: MultidisciplinaryState) -> MultidisciplinaryState:
    """Nó 3 — Gera o plano de coordenação integrado e protocolo de comunicação."""
    assignments = state.get("team_assignments", [])
    followup = state.get("followup_schedule", [])
    sensitivities = state.get("case_sensitivities", [])
    case_type = state["case_type"]

    # Protocolo de comunicação
    communication = [
        "Reunião de equipe síncrona em até 24h para alinhamento do plano (VD) ou em 72h (demais casos)",
        "Prontuário eletrônico como canal principal — todos registram evoluções no mesmo documento",
        "Comunicação assíncrona segura entre membros (sem WhatsApp pessoal para casos sensíveis)",
        "Profissional de referência designado: responsável por coordenar e comunicar à paciente",
        "Feedback à paciente sobre cada etapa — ela é parte ativa do plano de cuidado",
    ]

    if case_type == "vd":
        communication.insert(0, "🔒 COMUNICAÇÃO CRIPTOGRAFADA OBRIGATÓRIA — dados da vítima nunca em canais abertos")

    # Montar plano completo
    plan_parts = [
        f"**PLANO DE COORDENAÇÃO MULTIDISCIPLINAR**\n",
        f"**Tipo de caso:** {case_type.upper()}  |  **Urgência:** {state.get('urgency', 'eletivo').upper()}\n",
        f"**Resumo:** {state.get('case_summary', 'N/A')[:200]}\n",
        "\n**👥 ATRIBUIÇÕES DA EQUIPE:**",
    ]

    for a in assignments:
        priority_icon = {"imediata": "🚨", "alta": "⚠️", "média": "🟡", "baixa": "🟢"}.get(a["prioridade"], "•")
        plan_parts.append(
            f"\n{priority_icon} **{a['papel'].upper()}**\n"
            f"   Ação: {a['ação']}\n"
            f"   Prazo: {a['prazo']}"
        )

    plan_parts.append("\n\n**📅 CRONOGRAMA DE SEGUIMENTO:**")
    for f in followup:
        plan_parts.append(f"- {f['data']} → {f['responsável']}: {f['objetivo']}")

    plan_parts.append("\n\n**📡 PROTOCOLO DE COMUNICAÇÃO:**")
    for c in communication:
        plan_parts.append(f"- {c}")

    if sensitivities:
        plan_parts.append("\n\n**💜 SENSIBILIDADES DO CASO — LEITURA OBRIGATÓRIA:**")
        for s in sensitivities:
            plan_parts.append(f"- {s}")

    coordination_plan = "\n".join(plan_parts)

    return {
        **state,
        "coordination_plan": coordination_plan,
        "communication_protocol": communication,
        "current_step": "completed",
        "audit_log": _audit(state, "generate_plan"),
        "messages": state["messages"] + [AIMessage(content=coordination_plan)],
    }


def build_multidisciplinary_graph() -> StateGraph:
    """Constrói o grafo de coordenação multidisciplinar."""
    graph = StateGraph(MultidisciplinaryState)
    graph.add_node("determine_team", determine_required_team)
    graph.add_node("assign_responsibilities", assign_responsibilities)
    graph.add_node("generate_plan", generate_coordination_plan)

    graph.set_entry_point("determine_team")
    graph.add_edge("determine_team", "assign_responsibilities")
    graph.add_edge("assign_responsibilities", "generate_plan")
    graph.add_edge("generate_plan", END)

    return graph.compile(checkpointer=MemorySaver())


# ===========================================================================
# Helper compartilhado de auditoria
# ===========================================================================

def _audit(state: dict, step: str, details: dict = None) -> list[dict]:
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "step": step,
        "patient_hash": hash(state.get("patient_id", "")),
        **(details or {}),
    }
    return state.get("audit_log", []) + [entry]
