"""
Repositórios — Hospital Santa Clara
Camada de acesso a dados para cada entidade do sistema clínico.
Todos os métodos são async-first usando SQLAlchemy + aiosqlite.
"""

from __future__ import annotations

import hashlib
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import selectinload

from .models import (
    Base, Hospital, Medico, Paciente, Prontuario,
    Consulta, TriagemGinecologica, AlertaViolencia,
    AcompanhamentoObstetrico, ExamePreventivo, LogAuditoria,
    EspecialidadeEnum, UrgenciaEnum, RiscoVDEnum,
    RiscoGestacionalEnum, StatusConsultaEnum,
)


# ---------------------------------------------------------------------------
# Engine async
# ---------------------------------------------------------------------------

_engine = None
_session_factory = None


def inicializar_db(db_url: str = "sqlite+aiosqlite:///./hospital_santa_clara.db"):
    global _engine, _session_factory
    _engine = create_async_engine(db_url, echo=False, future=True)
    _session_factory = async_sessionmaker(_engine, expire_on_commit=False)
    return _engine


async def criar_tabelas():
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@asynccontextmanager
async def get_session() -> AsyncSession:
    async with _session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


# ---------------------------------------------------------------------------
# HospitalRepo
# ---------------------------------------------------------------------------

class HospitalRepo:

    @staticmethod
    async def criar(nome: str, cnpj: str = None, endereco: str = None,
                    telefone: str = None, email: str = None) -> Hospital:
        async with get_session() as s:
            hosp = Hospital(nome=nome, cnpj=cnpj, endereco=endereco,
                            telefone=telefone, email=email)
            s.add(hosp)
            await s.flush()
            return hosp

    @staticmethod
    async def buscar_por_id(hospital_id: int) -> Optional[Hospital]:
        async with get_session() as s:
            return await s.get(Hospital, hospital_id)

    @staticmethod
    async def listar_todos() -> list[Hospital]:
        async with get_session() as s:
            result = await s.execute(select(Hospital).order_by(Hospital.nome))
            return result.scalars().all()


# ---------------------------------------------------------------------------
# MedicoRepo
# ---------------------------------------------------------------------------

class MedicoRepo:

    @staticmethod
    async def criar(hospital_id: int, nome: str, crm: str,
                    especialidade: EspecialidadeEnum, email: str = None,
                    telefone: str = None) -> Medico:
        async with get_session() as s:
            med = Medico(hospital_id=hospital_id, nome=nome, crm=crm,
                         especialidade=especialidade, email=email, telefone=telefone)
            s.add(med)
            await s.flush()
            return med

    @staticmethod
    async def buscar_por_id(medico_id: int) -> Optional[Medico]:
        async with get_session() as s:
            return await s.get(Medico, medico_id)

    @staticmethod
    async def buscar_por_crm(crm: str) -> Optional[Medico]:
        async with get_session() as s:
            result = await s.execute(select(Medico).where(Medico.crm == crm))
            return result.scalar_one_or_none()

    @staticmethod
    async def listar_por_especialidade(esp: EspecialidadeEnum) -> list[Medico]:
        async with get_session() as s:
            result = await s.execute(
                select(Medico)
                .where(Medico.especialidade == esp, Medico.ativo == True)
                .order_by(Medico.nome)
            )
            return result.scalars().all()

    @staticmethod
    async def listar_todos() -> list[Medico]:
        async with get_session() as s:
            result = await s.execute(
                select(Medico).options(selectinload(Medico.hospital)).order_by(Medico.nome)
            )
            return result.scalars().all()


# ---------------------------------------------------------------------------
# PacienteRepo
# ---------------------------------------------------------------------------

class PacienteRepo:

    @staticmethod
    def _hash_cpf(cpf: str) -> str:
        return hashlib.sha256(f"cpf:{cpf}".encode()).hexdigest()

    @staticmethod
    async def criar(hospital_id: int, nome: str, cpf: str = None,
                    data_nascimento: datetime = None, telefone: str = None,
                    email: str = None, endereco: str = None, convenio: str = None,
                    comorbidades: list = None, historico_familiar: list = None) -> Paciente:
        async with get_session() as s:
            pac = Paciente(
                hospital_id=hospital_id,
                nome=nome,
                cpf_hash=PacienteRepo._hash_cpf(cpf) if cpf else None,
                data_nascimento=data_nascimento,
                telefone=telefone,
                email=email,
                endereco=endereco,
                convenio=convenio,
                comorbidades=comorbidades or [],
                historico_familiar=historico_familiar or [],
            )
            s.add(pac)
            await s.flush()
            return pac

    @staticmethod
    async def buscar_por_id(paciente_id: int) -> Optional[Paciente]:
        async with get_session() as s:
            return await s.get(Paciente, paciente_id)

    @staticmethod
    async def buscar_por_cpf(cpf: str) -> Optional[Paciente]:
        h = PacienteRepo._hash_cpf(cpf)
        async with get_session() as s:
            result = await s.execute(select(Paciente).where(Paciente.cpf_hash == h))
            return result.scalar_one_or_none()

    @staticmethod
    async def listar_todos() -> list[Paciente]:
        async with get_session() as s:
            result = await s.execute(select(Paciente).order_by(Paciente.nome))
            return result.scalars().all()

    @staticmethod
    async def total() -> int:
        async with get_session() as s:
            result = await s.execute(select(func.count()).select_from(Paciente))
            return result.scalar()


# ---------------------------------------------------------------------------
# ProntuarioRepo
# ---------------------------------------------------------------------------

class ProntuarioRepo:

    @staticmethod
    async def criar(paciente_id: int, numero: str, observacoes: str = None) -> Prontuario:
        async with get_session() as s:
            pront = Prontuario(paciente_id=paciente_id, numero=numero, observacoes=observacoes)
            s.add(pront)
            await s.flush()
            return pront

    @staticmethod
    async def buscar_por_paciente(paciente_id: int) -> Optional[Prontuario]:
        async with get_session() as s:
            result = await s.execute(
                select(Prontuario).where(Prontuario.paciente_id == paciente_id)
            )
            return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# ConsultaRepo
# ---------------------------------------------------------------------------

class ConsultaRepo:

    @staticmethod
    async def criar(paciente_id: int, medico_id: int, especialidade: EspecialidadeEnum,
                    queixa: str, prontuario_id: int = None, conduta: str = None,
                    audit_id: str = None) -> Consulta:
        async with get_session() as s:
            c = Consulta(
                paciente_id=paciente_id,
                medico_id=medico_id,
                prontuario_id=prontuario_id,
                especialidade=especialidade,
                queixa_principal=queixa,
                conduta=conduta,
                audit_id=audit_id,
                status=StatusConsultaEnum.REALIZADA,
            )
            s.add(c)
            await s.flush()
            return c

    @staticmethod
    async def listar_por_paciente(paciente_id: int) -> list[Consulta]:
        async with get_session() as s:
            result = await s.execute(
                select(Consulta)
                .where(Consulta.paciente_id == paciente_id)
                .order_by(Consulta.data_hora.desc())
            )
            return result.scalars().all()

    @staticmethod
    async def total_hoje() -> int:
        async with get_session() as s:
            hoje = datetime.utcnow().date()
            result = await s.execute(
                select(func.count()).select_from(Consulta)
                .where(func.date(Consulta.data_hora) == hoje)
            )
            return result.scalar()


# ---------------------------------------------------------------------------
# TriagemRepo (Fluxo 1)
# ---------------------------------------------------------------------------

class TriagemRepo:

    @staticmethod
    async def salvar(
        paciente_id: int,
        sintomas: str,
        urgencia: str,
        red_flags: list,
        exames_sugeridos: list,
        orientacao: str,
        tipo_agendamento: str,
        medico_id: int = None,
        duracao: str = None,
        sintomas_associados: list = None,
        historico_relevante: str = None,
        audit_log: list = None,
    ) -> TriagemGinecologica:
        async with get_session() as s:
            t = TriagemGinecologica(
                paciente_id=paciente_id,
                medico_id=medico_id,
                sintomas=sintomas,
                duracao=duracao,
                sintomas_associados=sintomas_associados or [],
                historico_relevante=historico_relevante,
                urgencia=urgencia,
                red_flags=red_flags,
                exames_sugeridos=exames_sugeridos,
                orientacao_inicial=orientacao,
                tipo_agendamento=tipo_agendamento,
                audit_log=audit_log or [],
            )
            s.add(t)
            await s.flush()
            return t

    @staticmethod
    async def listar_por_urgencia(urgencia: UrgenciaEnum) -> list[TriagemGinecologica]:
        async with get_session() as s:
            result = await s.execute(
                select(TriagemGinecologica)
                .where(TriagemGinecologica.urgencia == urgencia)
                .order_by(TriagemGinecologica.criado_em.desc())
            )
            return result.scalars().all()

    @staticmethod
    async def total_hoje() -> int:
        async with get_session() as s:
            hoje = datetime.utcnow().date()
            result = await s.execute(
                select(func.count()).select_from(TriagemGinecologica)
                .where(func.date(TriagemGinecologica.criado_em) == hoje)
            )
            return result.scalar()


# ---------------------------------------------------------------------------
# AlertaViolenciaRepo (Fluxo 2)
# ---------------------------------------------------------------------------

class AlertaViolenciaRepo:

    @staticmethod
    async def salvar(
        paciente_id: int,
        medico_id: int,
        nivel_risco: str,
        perigo_imediato: bool,
        criancas_em_risco: bool,
        protocolo_ativado: bool,
        equipe_notificada: list,
        id_documento: str,
        seguimento_agendado: bool,
        sinais_fisicos_enc: str = None,
        sinais_comportamentais_enc: str = None,
        audit_log_enc: str = None,
    ) -> AlertaViolencia:
        async with get_session() as s:
            a = AlertaViolencia(
                paciente_id=paciente_id,
                medico_responsavel_id=medico_id,
                sinais_fisicos_enc=sinais_fisicos_enc,
                sinais_comportamentais_enc=sinais_comportamentais_enc,
                nivel_risco=nivel_risco,
                perigo_imediato=perigo_imediato,
                criancas_em_risco=criancas_em_risco,
                protocolo_ativado=protocolo_ativado,
                equipe_notificada=equipe_notificada,
                id_documento_seguro=id_documento,
                seguimento_agendado=seguimento_agendado,
                audit_log_enc=audit_log_enc,
            )
            s.add(a)
            await s.flush()
            return a

    @staticmethod
    async def listar_ativos() -> list[AlertaViolencia]:
        """Retorna alertas com risco ALTO ou MEDIO sem seguimento concluído."""
        async with get_session() as s:
            result = await s.execute(
                select(AlertaViolencia)
                .where(
                    AlertaViolencia.nivel_risco.in_([RiscoVDEnum.ALTO, RiscoVDEnum.MEDIO]),
                    AlertaViolencia.seguimento_agendado == True,
                )
                .order_by(AlertaViolencia.criado_em.desc())
            )
            return result.scalars().all()

    @staticmethod
    async def total_hoje() -> int:
        async with get_session() as s:
            hoje = datetime.utcnow().date()
            result = await s.execute(
                select(func.count()).select_from(AlertaViolencia)
                .where(func.date(AlertaViolencia.criado_em) == hoje)
            )
            return result.scalar()


# ---------------------------------------------------------------------------
# AcompObstetricoRepo (Fluxo 3)
# ---------------------------------------------------------------------------

class AcompObstetricoRepo:

    @staticmethod
    async def salvar(
        paciente_id: int,
        ig_semanas: int,
        risco_gestacional: str,
        fatores_risco: list,
        orientacoes: str,
        exames_sugeridos: list,
        proxima_consulta: str,
        alertas_urgentes: list,
        medico_id: int = None,
        ig_dias: int = 0,
        historico_obstetrico: str = "G1P0A0",
        comorbidades: list = None,
        sinais_vitais: dict = None,
        exames_recentes: dict = None,
        audit_log: list = None,
    ) -> AcompanhamentoObstetrico:
        async with get_session() as s:
            a = AcompanhamentoObstetrico(
                paciente_id=paciente_id,
                medico_id=medico_id,
                ig_semanas=ig_semanas,
                ig_dias=ig_dias,
                historico_obstetrico=historico_obstetrico,
                comorbidades=comorbidades or [],
                sinais_vitais=sinais_vitais or {},
                exames_recentes=exames_recentes or {},
                risco_gestacional=risco_gestacional,
                fatores_risco=fatores_risco,
                orientacoes_trimestre=orientacoes,
                exames_sugeridos=exames_sugeridos,
                proxima_consulta=proxima_consulta,
                alertas_urgentes=alertas_urgentes,
                audit_log=audit_log or [],
            )
            s.add(a)
            await s.flush()
            return a

    @staticmethod
    async def listar_alto_risco() -> list[AcompanhamentoObstetrico]:
        async with get_session() as s:
            result = await s.execute(
                select(AcompanhamentoObstetrico)
                .where(AcompanhamentoObstetrico.risco_gestacional == RiscoGestacionalEnum.ALTO)
                .order_by(AcompanhamentoObstetrico.criado_em.desc())
            )
            return result.scalars().all()


# ---------------------------------------------------------------------------
# ExamePreventivoRepo (Fluxo 4)
# ---------------------------------------------------------------------------

class ExamePreventivoRepo:

    @staticmethod
    async def salvar_lista(paciente_id: int, exames_vencidos: list[dict]) -> list[ExamePreventivo]:
        """Salva lista de exames vencidos retornada pelo fluxo de prevenção."""
        registros = []
        async with get_session() as s:
            for ex in exames_vencidos:
                e = ExamePreventivo(
                    paciente_id=paciente_id,
                    nome_exame=ex.get("exam", ""),
                    prioridade=ex.get("priority", "média"),
                    guideline_fonte=ex.get("guideline", ""),
                    agendamento_solicitado=True,
                )
                s.add(e)
                registros.append(e)
            await s.flush()
        return registros

    @staticmethod
    async def atualizar_resultado(exame_id: int, resultado: str):
        async with get_session() as s:
            await s.execute(
                update(ExamePreventivo)
                .where(ExamePreventivo.id == exame_id)
                .values(resultado=resultado, data_realizacao=datetime.utcnow())
            )

    @staticmethod
    async def listar_pendentes(paciente_id: int) -> list[ExamePreventivo]:
        async with get_session() as s:
            result = await s.execute(
                select(ExamePreventivo)
                .where(
                    ExamePreventivo.paciente_id == paciente_id,
                    ExamePreventivo.resultado == None,
                )
            )
            return result.scalars().all()


# ---------------------------------------------------------------------------
# LogAuditoriaRepo
# ---------------------------------------------------------------------------

class LogAuditoriaRepo:

    @staticmethod
    async def registrar(
        audit_uuid: str,
        tipo_evento: str,
        profissional_id: str,
        dominio: str,
        acao: str,
        classificacao: str,
        detalhes: dict,
        paciente_hash: str = None,
        sensivel: bool = False,
    ) -> LogAuditoria:
        async with get_session() as s:
            log = LogAuditoria(
                audit_uuid=audit_uuid,
                tipo_evento=tipo_evento,
                profissional_id=profissional_id,
                paciente_hash=paciente_hash,
                dominio=dominio,
                acao=acao,
                classificacao=classificacao,
                detalhes_json=detalhes,
                sensivel=sensivel,
            )
            s.add(log)
            await s.flush()
            return log

    @staticmethod
    async def listar_por_paciente(paciente_hash: str) -> list[LogAuditoria]:
        async with get_session() as s:
            result = await s.execute(
                select(LogAuditoria)
                .where(LogAuditoria.paciente_hash == paciente_hash)
                .order_by(LogAuditoria.timestamp.desc())
            )
            return result.scalars().all()

    @staticmethod
    async def total_por_tipo(tipo: str) -> int:
        async with get_session() as s:
            result = await s.execute(
                select(func.count()).select_from(LogAuditoria)
                .where(LogAuditoria.tipo_evento == tipo)
            )
            return result.scalar()
