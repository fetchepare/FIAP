from .models import (
    Base, Hospital, Medico, Paciente, Prontuario,
    Consulta, TriagemGinecologica, AlertaViolencia,
    AcompanhamentoObstetrico, ExamePreventivo, LogAuditoria,
    get_engine, criar_todas_tabelas,
    EspecialidadeEnum, UrgenciaEnum, RiscoVDEnum,
    RiscoGestacionalEnum, StatusConsultaEnum,
)
from .repositories import (
    inicializar_db, criar_tabelas, get_session,
    HospitalRepo, MedicoRepo, PacienteRepo, ProntuarioRepo,
    ConsultaRepo, TriagemRepo, AlertaViolenciaRepo,
    AcompObstetricoRepo, ExamePreventivoRepo, LogAuditoriaRepo,
)
from .integrations import (
    persistir_triagem, persistir_alerta_vd,
    persistir_obstetrico, persistir_prevencao,
    persistir_consulta,
)

__all__ = [
    "Base", "Hospital", "Medico", "Paciente", "Prontuario",
    "Consulta", "TriagemGinecologica", "AlertaViolencia",
    "AcompanhamentoObstetrico", "ExamePreventivo", "LogAuditoria",
    "get_engine", "criar_todas_tabelas",
    "EspecialidadeEnum", "UrgenciaEnum", "RiscoVDEnum",
    "RiscoGestacionalEnum", "StatusConsultaEnum",
    "inicializar_db", "criar_tabelas", "get_session",
    "HospitalRepo", "MedicoRepo", "PacienteRepo", "ProntuarioRepo",
    "ConsultaRepo", "TriagemRepo", "AlertaViolenciaRepo",
    "AcompObstetricoRepo", "ExamePreventivoRepo", "LogAuditoriaRepo",
    "persistir_triagem", "persistir_alerta_vd",
    "persistir_obstetrico", "persistir_prevencao", "persistir_consulta",
]
