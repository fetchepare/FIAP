"""
Integração LangGraph ↔ Banco de Dados — Hospital Santa Clara

Cada função recebe o estado final de um fluxo LangGraph e persiste
os resultados nas tabelas correspondentes. Chamado nos nós finais
de cada StateGraph.
"""

from __future__ import annotations

import logging
import uuid
from typing import Optional

from .repositories import (
    TriagemRepo, AlertaViolenciaRepo,
    AcompObstetricoRepo, ExamePreventivoRepo,
    ConsultaRepo, LogAuditoriaRepo,
)
from .models import EspecialidadeEnum

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Fluxo 1 — Triagem Ginecológica
# ---------------------------------------------------------------------------

async def persistir_triagem(
    state: dict,
    paciente_id: int,
    medico_id: Optional[int] = None,
) -> int:
    """
    Persiste o resultado do fluxo de triagem no banco.
    Retorna o ID da triagem criada.
    """
    triagem = await TriagemRepo.salvar(
        paciente_id=paciente_id,
        medico_id=medico_id,
        sintomas=state.get("symptoms", ""),
        urgencia=state.get("urgency_level", "ELETIVO"),
        red_flags=state.get("red_flags", []),
        exames_sugeridos=state.get("recommended_exams", []),
        orientacao=state.get("initial_guidance", ""),
        tipo_agendamento=state.get("scheduling_type", "agendamento_regular"),
        duracao=state.get("symptom_duration"),
        sintomas_associados=state.get("associated_symptoms", []),
        historico_relevante=state.get("relevant_history"),
        audit_log=state.get("audit_log", []),
    )

    # Consulta vinculada
    if medico_id:
        await ConsultaRepo.criar(
            paciente_id=paciente_id,
            medico_id=medico_id,
            especialidade=EspecialidadeEnum.GINECOLOGIA,
            queixa=state.get("symptoms", ""),
            conduta=state.get("initial_guidance", ""),
            audit_id=f"triage-{triagem.id}",
        )

    logger.info(f"Triagem {triagem.id} salva — urgência: {state.get('urgency_level')}")
    return triagem.id


# ---------------------------------------------------------------------------
# Fluxo 2 — Violência Doméstica
# ---------------------------------------------------------------------------

async def persistir_alerta_vd(
    state: dict,
    paciente_id: int,
    medico_id: int,
    security_module=None,
) -> Optional[int]:
    """
    Persiste alerta de VD com campos sensíveis encriptados.
    Retorna None se risk_level == NENHUM.
    """
    nivel_risco = getattr(state.get("risk_level"), "value", "NENHUM")
    if nivel_risco == "NENHUM":
        return None

    # Encripta sinais sensíveis se SecurityModule disponível
    def enc(val):
        if security_module and val:
            return security_module.encrypt(str(val))
        return str(val) if val else None

    audit_enc = enc(str(state.get("audit_log", [])))
    fisicos_enc = enc(str(state.get("physical_signs", [])))
    comport_enc = enc(str(state.get("behavioral_signs", [])))

    doc_id = state.get("documentation_id") or f"VD-{paciente_id:04d}-{uuid.uuid4().hex[:6].upper()}"

    alerta = await AlertaViolenciaRepo.salvar(
        paciente_id=paciente_id,
        medico_id=medico_id,
        nivel_risco=nivel_risco,
        perigo_imediato=state.get("immediate_danger", False),
        criancas_em_risco=state.get("children_at_risk", False),
        protocolo_ativado=state.get("security_protocol_activated", False),
        equipe_notificada=state.get("team_notified", []),
        id_documento=doc_id,
        seguimento_agendado=state.get("followup_scheduled", False),
        sinais_fisicos_enc=fisicos_enc,
        sinais_comportamentais_enc=comport_enc,
        audit_log_enc=audit_enc,
    )

    # Auditoria
    await LogAuditoriaRepo.registrar(
        audit_uuid=str(uuid.uuid4()),
        tipo_evento="violence_alert",
        profissional_id=str(medico_id),
        dominio="violencia_domestica",
        acao="alert_triggered",
        classificacao="CRITICAL",
        detalhes={"risco": nivel_risco, "doc_id": doc_id},
        sensivel=True,
    )

    logger.warning(f"Alerta VD {alerta.id} salvo — risco: {nivel_risco}")
    return alerta.id


# ---------------------------------------------------------------------------
# Fluxo 3 — Obstétrico
# ---------------------------------------------------------------------------

async def persistir_obstetrico(
    state: dict,
    paciente_id: int,
    medico_id: Optional[int] = None,
) -> int:
    """Persiste resultado do fluxo obstétrico."""
    risco = getattr(state.get("gestational_risk"), "value", "BAIXO")

    acomp = await AcompObstetricoRepo.salvar(
        paciente_id=paciente_id,
        medico_id=medico_id,
        ig_semanas=state.get("gestational_age_weeks", 0),
        ig_dias=state.get("gestational_age_days", 0),
        historico_obstetrico=state.get("obstetric_history", "G1P0A0"),
        comorbidades=state.get("comorbidities", []),
        sinais_vitais=state.get("current_vitals", {}),
        exames_recentes=state.get("recent_exams", {}),
        risco_gestacional=risco,
        fatores_risco=state.get("risk_factors", []),
        orientacoes=state.get("trimester_guidance", ""),
        exames_sugeridos=state.get("recommended_exams", []),
        proxima_consulta=state.get("next_appointment", ""),
        alertas_urgentes=state.get("urgent_alerts", []),
        audit_log=state.get("audit_log", []),
    )

    if medico_id and state.get("urgent_alerts"):
        await LogAuditoriaRepo.registrar(
            audit_uuid=str(uuid.uuid4()),
            tipo_evento="obstetric_alert",
            profissional_id=str(medico_id),
            dominio="obstetricia",
            acao="urgent_flag",
            classificacao="RESTRICTED",
            detalhes={"alerts": state.get("urgent_alerts"), "ig": state.get("gestational_age_weeks")},
            sensivel=False,
        )

    logger.info(f"Acomp. obstétrico {acomp.id} salvo — risco: {risco}")
    return acomp.id


# ---------------------------------------------------------------------------
# Fluxo 4 — Prevenção
# ---------------------------------------------------------------------------

async def persistir_prevencao(
    state: dict,
    paciente_id: int,
) -> int:
    """Persiste exames preventivos vencidos no banco."""
    overdue = state.get("overdue_exams", [])
    if not overdue:
        return 0

    registros = await ExamePreventivoRepo.salvar_lista(
        paciente_id=paciente_id,
        exames_vencidos=overdue,
    )

    logger.info(f"{len(registros)} exames preventivos salvos para pac {paciente_id}")
    return len(registros)


# ---------------------------------------------------------------------------
# Consulta genérica
# ---------------------------------------------------------------------------

async def persistir_consulta(
    paciente_id: int,
    medico_id: int,
    especialidade: str,
    queixa: str,
    conduta: str = None,
    audit_id: str = None,
    prontuario_id: int = None,
) -> int:
    c = await ConsultaRepo.criar(
        paciente_id=paciente_id,
        medico_id=medico_id,
        prontuario_id=prontuario_id,
        especialidade=EspecialidadeEnum(especialidade),
        queixa=queixa,
        conduta=conduta,
        audit_id=audit_id or str(uuid.uuid4()),
    )
    return c.id
