"""
Seed — Hospital Santa Clara
Popula o banco com dados fictícios:
  1 hospital · 8 médicos · 12 pacientes · prontuários · consultas
  triagens · acompanhamentos obstétricos · exames preventivos
"""

from __future__ import annotations

import asyncio
import random
from datetime import datetime, timedelta

from .models import EspecialidadeEnum
from .repositories import (
    inicializar_db, criar_tabelas,
    HospitalRepo, MedicoRepo, PacienteRepo, ProntuarioRepo,
    ConsultaRepo, TriagemRepo, AlertaViolenciaRepo,
    AcompObstetricoRepo, ExamePreventivoRepo, LogAuditoriaRepo,
)


# ---------------------------------------------------------------------------
# Dados fictícios
# ---------------------------------------------------------------------------

HOSPITAL = {
    "nome":     "Hospital Santa Clara",
    "cnpj":     "12.345.678/0001-99",
    "endereco": "Av. das Flores, 1500 — Jardim Europa — São Paulo / SP",
    "telefone": "(11) 3200-4500",
    "email":    "contato@hospitalsantaclara.com.br",
}

MEDICOS = [
    {"nome": "Dra. Ana Beatriz Ferreira",    "crm": "CRM/SP-123456", "esp": EspecialidadeEnum.GINECOLOGIA,    "email": "ana.ferreira@santaclara.com.br"},
    {"nome": "Dra. Carla Mendonça Lopes",    "crm": "CRM/SP-234567", "esp": EspecialidadeEnum.OBSTETRICIA,   "email": "carla.lopes@santaclara.com.br"},
    {"nome": "Dr. Ricardo Alves Nogueira",   "crm": "CRM/SP-345678", "esp": EspecialidadeEnum.GINECOLOGIA,   "email": "ricardo.nogueira@santaclara.com.br"},
    {"nome": "Dra. Fernanda Costa Ribeiro",  "crm": "CRM/SP-456789", "esp": EspecialidadeEnum.OBSTETRICIA,   "email": "fernanda.ribeiro@santaclara.com.br"},
    {"nome": "Dra. Juliana Martins Souza",   "crm": "CRO/SP-567890", "esp": EspecialidadeEnum.PSICOLOGIA,    "email": "juliana.souza@santaclara.com.br"},
    {"nome": "Assistente Márcia Oliveira",   "crm": "CRESS/SP-78901","esp": EspecialidadeEnum.SERVICO_SOCIAL,"email": "marcia.oliveira@santaclara.com.br"},
    {"nome": "Enf. Paula Cristina Santos",   "crm": "COREN/SP-89012","esp": EspecialidadeEnum.ENFERMAGEM,    "email": "paula.santos@santaclara.com.br"},
    {"nome": "Dr. Henrique Braga Teixeira",  "crm": "CRM/SP-901234", "esp": EspecialidadeEnum.ONCOLOGIA,     "email": "henrique.teixeira@santaclara.com.br"},
]

PACIENTES = [
    # nome, cpf fictício, nascimento, telefone, convenio, comorbidades, hist.familiar
    ("Maria Aparecida Silva",       "111.111.111-11", datetime(1985,  3, 14), "(11) 98001-1001", "Unimed",    [],                          ["câncer de mama materna"]),
    ("Juliana Ferreira Alves",      "222.222.222-22", datetime(1993,  7,  2), "(11) 98001-1002", "Bradesco",  [],                          []),
    ("Fernanda Lima Cardoso",       "333.333.333-33", datetime(1990, 11, 25), "(11) 98001-1003", "SulAmérica",["hipertensão"],             []),
    ("Beatriz Oliveira Gomes",      "444.444.444-44", datetime(1978,  5,  8), "(11) 98001-1004", "Amil",      ["diabetes tipo 2"],         ["câncer de colo uterino"]),
    ("Camila Rodrigues Pereira",    "555.555.555-55", datetime(1999,  1, 19), "(11) 98001-1005", "Particular",  [],                        []),
    ("Lúcia Helena Barbosa",        "666.666.666-66", datetime(1970,  9, 30), "(11) 98001-1006", "Unimed",    ["hipotireoidismo"],         ["osteoporose materna"]),
    ("Patrícia Sousa Mendes",       "777.777.777-77", datetime(2001,  4, 12), "(11) 98001-1007", "Particular",  [],                        []),
    ("Ana Paula Correia Castro",    "888.888.888-88", datetime(1988,  8, 22), "(11) 98001-1008", "Bradesco",  [],                          []),
    ("Roberta Nascimento Freitas",  "999.999.999-99", datetime(1995,  2,  5), "(11) 98001-1009", "SulAmérica",["lúpus eritematoso"],       []),
    ("Simone Teixeira Araújo",      "123.456.789-00", datetime(1982, 12, 17), "(11) 98001-1010", "Amil",      [],                          []),
    ("Vanessa Moura Pinto",         "987.654.321-00", datetime(2003,  6,  3), "(11) 98001-1011", "Particular",  [],                        []),
    ("Cristiane Batista Reis",      "111.222.333-44", datetime(1965, 10, 28), "(11) 98001-1012", "Unimed",    ["diabetes tipo 2","HAS"],   ["câncer de ovário tia"]),
]


def _data_passada(anos: int = 0, meses: int = 0, dias: int = 0) -> datetime:
    return datetime.utcnow() - timedelta(days=anos * 365 + meses * 30 + dias)


async def seed():
    print("🌱  Iniciando seed — Hospital Santa Clara\n")

    inicializar_db()
    await criar_tabelas()

    # ── Hospital ──────────────────────────────────────────────────────────
    hosp = await HospitalRepo.criar(**HOSPITAL)
    print(f"  ✓ Hospital: {hosp.nome}  (id={hosp.id})")

    # ── Médicos ───────────────────────────────────────────────────────────
    medicos_ids: dict[str, int] = {}
    for m in MEDICOS:
        med = await MedicoRepo.criar(
            hospital_id=hosp.id,
            nome=m["nome"], crm=m["crm"],
            especialidade=m["esp"], email=m["email"],
        )
        medicos_ids[m["crm"]] = med.id
        print(f"  ✓ Médico: {med.nome}  [{med.especialidade.value}]  (id={med.id})")

    # IDs por especialidade (para uso mais fácil abaixo)
    id_gine   = medicos_ids["CRM/SP-123456"]   # Ana Beatriz — ginecologia
    id_obst   = medicos_ids["CRM/SP-234567"]   # Carla Mendonça — obstetrícia
    id_gine2  = medicos_ids["CRM/SP-345678"]   # Ricardo — ginecologia
    id_psico  = medicos_ids["CRO/SP-567890"]   # Juliana — psicologia

    print()

    # ── Pacientes + prontuários ───────────────────────────────────────────
    pac_ids: list[int] = []
    pront_ids: list[int] = []
    for i, (nome, cpf, nasc, tel, conv, comor, hist) in enumerate(PACIENTES, start=1):
        pac = await PacienteRepo.criar(
            hospital_id=hosp.id,
            nome=nome, cpf=cpf,
            data_nascimento=nasc,
            telefone=tel, convenio=conv,
            comorbidades=comor,
            historico_familiar=hist,
        )
        pront = await ProntuarioRepo.criar(
            paciente_id=pac.id,
            numero=f"SC-2024-{pac.id:04d}",
        )
        pac_ids.append(pac.id)
        pront_ids.append(pront.id)
        print(f"  ✓ Paciente: {pac.nome}  prontuário: {pront.numero}")

    print()

    # ── Consultas (histórico variado) ─────────────────────────────────────
    consultas_data = [
        # pac_idx, med_crm, especialidade, queixa, conduta
        (0, id_gine,  EspecialidadeEnum.GINECOLOGIA,  "Sangramento intermenstrual há 2 meses",
         "Solicitado US TV, TSH e prolactina. Orientações sobre SUA."),
        (1, id_gine,  EspecialidadeEnum.GINECOLOGIA,  "Dúvida sobre troca de anticoncepcional",
         "Orientação sobre ACO de baixa dose. Quick start explicado."),
        (2, id_obst,  EspecialidadeEnum.OBSTETRICIA,  "Pré-natal de rotina — 24 semanas",
         "GTT 75g solicitado. BP 140/90 — monitorar. Retorno em 2 semanas."),
        (3, id_gine2, EspecialidadeEnum.GINECOLOGIA,  "Resultado de mamografia com nódulo BIRADS 3",
         "US de mama solicitado. Seguimento em 6 meses conforme protocolo."),
        (4, id_gine,  EspecialidadeEnum.GINECOLOGIA,  "Consulta pré-nupcial e planejamento familiar",
         "Orientação completa sobre métodos contraceptivos. Solicitadas sorologias pré-nupciais."),
        (5, id_gine2, EspecialidadeEnum.GINECOLOGIA,  "Fogachos intensos e ressecamento vaginal",
         "EPDS aplicada — score 4. THM discutida, solicitados FSH e densitometria. Retorno em 30 dias."),
        (6, id_gine,  EspecialidadeEnum.GINECOLOGIA,  "Atraso menstrual de 10 dias",
         "Beta-hCG negativo. Ciclo irregular — TSH e prolactina solicitados."),
        (7, id_obst,  EspecialidadeEnum.OBSTETRICIA,  "Pré-natal — 32 semanas, cefaleia intensa",
         "PA 155/100. Exames urgentes solicitados. Internação para observação discutida."),
        (8, id_gine,  EspecialidadeEnum.GINECOLOGIA,  "Dor pélvica crônica há 6 meses",
         "Investigação para endometriose. US TV + laparoscopia diagnóstica agendada."),
        (9, id_gine2, EspecialidadeEnum.GINECOLOGIA,  "Papanicolau com ASC-US",
         "Teste HPV solicitado. Orientações sobre seguimento conforme INCA."),
        (10, id_psico, EspecialidadeEnum.PSICOLOGIA,  "Sintomas depressivos pós-aborto espontâneo",
         "EPDS score 15 — depressão pós-gestacional. Psicoterapia iniciada. Encaminhamento psiquiatria."),
        (11, id_gine2, EspecialidadeEnum.GINECOLOGIA, "Revisão anual — menopausa confirmada",
         "Densitometria solicitada. Mamografia em dia. Orientações de saúde óssea."),
    ]

    for idx, (pac_idx, med_id, esp, queixa, conduta) in enumerate(consultas_data):
        c = await ConsultaRepo.criar(
            paciente_id=pac_ids[pac_idx],
            medico_id=med_id,
            prontuario_id=pront_ids[pac_idx],
            especialidade=esp,
            queixa=queixa,
            conduta=conduta,
            audit_id=f"audit-seed-{idx+1:03d}",
        )
        print(f"  ✓ Consulta: {PACIENTES[pac_idx][0][:20]:<22}  — {queixa[:50]}")

    print()

    # ── Triagens ginecológicas (Fluxo 1) ──────────────────────────────────
    triagens_data = [
        # pac_idx, sintomas, urgência, red_flags, exames
        (4,  "Dor abdominal intensa súbita, sangramento intenso",
             "EMERGENCIA", ["hemorragia intensa", "dor súbita"],
             ["hemograma urgente", "beta-hCG", "US pélvico", "tipagem sanguínea"],
             "🚨 Encaminhar PS imediatamente.", "encaminhamento_imediato_pronto_socorro"),
        (6,  "Corrimento amarelado com odor, prurido há 5 dias",
             "URGENCIA",   ["corrimento com odor"],
             ["bacterioscopia", "cultura vaginal", "VDRL"],
             "Agendar ginecologia em até 24h.", "consulta_24h"),
        (0,  "Irregularidade menstrual há 3 meses, sem dor",
             "ELETIVO",    [],
             ["TSH", "prolactina", "FSH/LH", "US pélvico TV"],
             "Agendamento eletivo. Retornar se piora.", "agendamento_regular"),
        (9,  "Dispareunia progressiva há 2 meses",
             "PRIORITARIO",["dispareunia intensa"],
             ["US pélvico TV", "vaginal swab"],
             "Consulta ginecologia em 72h.", "consulta_72h"),
    ]

    for pac_idx, sint, urg, flags, exames, orient, agend in triagens_data:
        t = await TriagemRepo.salvar(
            paciente_id=pac_ids[pac_idx],
            medico_id=id_gine,
            sintomas=sint, urgencia=urg,
            red_flags=flags, exames_sugeridos=exames,
            orientacao=orient, tipo_agendamento=agend,
            audit_log=[{"step": "seed", "timestamp": datetime.utcnow().isoformat()}],
        )
        print(f"  ✓ Triagem: {PACIENTES[pac_idx][0][:22]:<24} urgência={urg}")

    print()

    # ── Alertas de violência doméstica (Fluxo 2) ──────────────────────────
    alertas_vd = [
        # pac_idx, risco, perigo_imediato, crianças, equipe
        (7, "ALTO",  True,  False, ["ginecologista", "psicologa", "assistente_social", "seguranca_hospitalar"]),
        (1, "MEDIO", False, False, ["psicologa", "assistente_social"]),
    ]

    for pac_idx, risco, perigo, criancas, equipe in alertas_vd:
        a = await AlertaViolenciaRepo.salvar(
            paciente_id=pac_ids[pac_idx],
            medico_id=id_gine,
            nivel_risco=risco,
            perigo_imediato=perigo,
            criancas_em_risco=criancas,
            protocolo_ativado=True,
            equipe_notificada=equipe,
            id_documento=f"VD-{pac_ids[pac_idx]:04d}-{random.randint(1000,9999)}",
            seguimento_agendado=True,
            sinais_fisicos_enc="[ENCRIPTADO]",
            sinais_comportamentais_enc="[ENCRIPTADO]",
            audit_log_enc="[ENCRIPTADO]",
        )
        print(f"  ✓ Alerta VD: {PACIENTES[pac_idx][0][:22]:<24} risco={risco}  doc={a.id_documento_seguro}")

    print()

    # ── Acompanhamentos obstétricos (Fluxo 3) ─────────────────────────────
    obstetricos = [
        # pac_idx, ig_sem, risco, fatores_risco, alertas, orient
        (2,  24, "HABITUAL", [],
         [],
         "2º trimestre: GTT 75g urgente (BP elevada), sulfato ferroso, US morfológico."),
        (7,  32, "ALTO",    ["PA sistólica ≥ 155 mmHg", "cefaleia intensa"],
         ["🚨 Internação para observação — suspeita PE grave"],
         "3º trimestre: CTG contínuo, exames urgentes, obstetra de plantão acionado."),
        (8,  10, "BAIXO",   [],
         [],
         "1º trimestre: Ácido fólico, US com TN 11-13sem, sorologias pré-natal."),
    ]

    for pac_idx, ig, risco, fatores, alertas, orient in obstetricos:
        o = await AcompObstetricoRepo.salvar(
            paciente_id=pac_ids[pac_idx],
            medico_id=id_obst,
            ig_semanas=ig,
            risco_gestacional=risco,
            fatores_risco=fatores,
            orientacoes=orient,
            exames_sugeridos=["hemograma", "urocultura", "US obstétrico"],
            proxima_consulta=f"Em {'2' if risco == 'ALTO' else '4'} semanas ({risco} risco)",
            alertas_urgentes=alertas,
            historico_obstetrico="G1P0A0",
            sinais_vitais={"systolic_bp": 155 if risco == "ALTO" else 115},
            audit_log=[{"step": "seed"}],
        )
        print(f"  ✓ Obs: {PACIENTES[pac_idx][0][:22]:<24} IG={ig}sem  risco={risco}")

    print()

    # ── Exames preventivos vencidos (Fluxo 4) ─────────────────────────────
    exames_seed = [
        # pac_idx, exames
        (0, [{"exam": "mamografia",       "priority": "alta",  "guideline": "INCA 2016"},
             {"exam": "papanicolau",       "priority": "alta",  "guideline": "INCA 2016"}]),
        (3, [{"exam": "mamografia",       "priority": "alta",  "guideline": "INCA + hist.familiar"},
             {"exam": "densitometria_ossea","priority": "média","guideline": "FEBRASGO 2021"}]),
        (5, [{"exam": "densitometria_ossea","priority": "alta", "guideline": "FEBRASGO 2021"},
             {"exam": "colesterol",        "priority": "média", "guideline": "SBC 2019"}]),
        (11,[{"exam": "densitometria_ossea","priority": "alta", "guideline": "FEBRASGO"},
             {"exam": "mamografia",        "priority": "alta",  "guideline": "INCA"},
             {"exam": "glicemia",          "priority": "média", "guideline": "SBD 2023"}]),
    ]

    for pac_idx, exames in exames_seed:
        registros = await ExamePreventivoRepo.salvar_lista(
            paciente_id=pac_ids[pac_idx],
            exames_vencidos=exames,
        )
        nomes = ", ".join(e.nome_exame for e in registros)
        print(f"  ✓ Prev: {PACIENTES[pac_idx][0][:22]:<24} exames=({nomes})")

    print()

    # ── Logs de auditoria ─────────────────────────────────────────────────
    import uuid
    eventos_audit = [
        ("consultation",   "CRM/SP-123456", "ginecologia",       "query",  "CONFIDENTIAL", False),
        ("consultation",   "CRM/SP-234567", "obstetricia",       "query",  "CONFIDENTIAL", False),
        ("violence_alert", "CRM/SP-123456", "violencia_domestica","alert", "CRITICAL",     True),
        ("data_access",    "CRO/SP-567890", "saude_mental",      "read",   "RESTRICTED",   True),
        ("consultation",   "CRM/SP-345678", "ginecologia",       "query",  "CONFIDENTIAL", False),
        ("prevention",     "CRM/SP-123456", "rastreamento",      "check",  "CONFIDENTIAL", False),
    ]

    for tipo, prof, dom, acao, classif, sensivel in eventos_audit:
        await LogAuditoriaRepo.registrar(
            audit_uuid=str(uuid.uuid4()),
            tipo_evento=tipo,
            profissional_id=prof,
            dominio=dom, acao=acao,
            classificacao=classif,
            detalhes={"source": "seed"},
            sensivel=sensivel,
        )

    print(f"  ✓ {len(eventos_audit)} logs de auditoria registrados")
    print()
    print("✅  Seed concluído — banco: hospital_santa_clara.db")
    print(f"   {len(PACIENTES)} pacientes · {len(MEDICOS)} médicos · {len(consultas_data)} consultas")
    print(f"   {len(triagens_data)} triagens · {len(alertas_vd)} alertas VD · {len(obstetricos)} acomp. obstétricos")


if __name__ == "__main__":
    asyncio.run(seed())
