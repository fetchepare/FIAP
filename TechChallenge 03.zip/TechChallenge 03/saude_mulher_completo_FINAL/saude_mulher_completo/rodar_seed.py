"""
Execute este arquivo dentro da pasta saude_mulher:
    python rodar_seed.py
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.repositories import inicializar_db, criar_tabelas
from database.seed import seed


async def main():
    print("Inicializando banco...")
    inicializar_db("sqlite+aiosqlite:///./hospital_santa_clara.db")
    await criar_tabelas()
    print("Tabelas criadas.")
    await seed()
    print("\nPronto! Agora rode: python api.py")


asyncio.run(main())
