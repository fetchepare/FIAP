"""
LangChain RAG Pipeline — Saúde da Mulher
==========================================
Entrega Técnica 2 — Assistente médico especializado com LangChain

Pipeline de integração:
  - Base vetorial com protocolos médicos (FAISS in-process, sem dependência externa)
  - Consultas contextualizadas com dados reais da paciente vindos do banco
  - Respostas com fonte citada, nível de confiança e raciocínio clínico exposto
  - Funcionalidades: triagem por sintomas, alertas de exames, detecção VD,
    encaminhamento multidisciplinar, orientações pós-consulta personalizadas
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger(__name__)


# ===========================================================================
# Base de conhecimento especializada (substitui vetor store externo)
# ===========================================================================
# Cada documento tem: conteúdo, categoria, fonte, nível de evidência e tags
# Em produção: substituir por FAISS/Chroma + embeddings reais

@dataclass
class KnowledgeDoc:
    doc_id: str
    content: str
    category: str
    source: str
    evidence_level: str   # A / B / C / Consenso / Legislação
    confidence: float
    tags: list[str]


KNOWLEDGE_BASE: list[KnowledgeDoc] = [

    # ── Triagem ginecológica ───────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="GIN-001",
        content=(
            "Dismenorreia progressiva + dispareunia profunda + dor pélvica crônica são a tríade "
            "clássica de endometriose. Diagnóstico definitivo: laparoscopia + histopatológico. "
            "US transvaginal detecta endometriomas ≥2cm. CA-125 útil para seguimento, não diagnóstico. "
            "Tratamento sem desejo de gestar: dienogeste 2mg/dia (1ª linha), AOC contínuo, DIU-LNG. "
            "Tratamento com desejo de gestar: avaliação de reserva ovariana (AMH), FIV em casos graves."
        ),
        category="ginecologia",
        source="FEBRASGO — Manual de Endometriose 2023",
        evidence_level="A",
        confidence=0.95,
        tags=["endometriose", "dor pélvica", "dismenorreia", "dispareunia", "DIU", "dienogeste"],
    ),
    KnowledgeDoc(
        doc_id="GIN-002",
        content=(
            "SOP (Síndrome dos Ovários Policísticos): critérios de Rotterdam — 2 de 3: "
            "oligo/anovulação, hiperandrogenismo clínico/bioquímico, ovários policísticos na US. "
            "Investigação: LH/FSH, testosterona total, SHBG, glicemia + insulina basal (HOMA-IR), TSH, prolactina. "
            "Tratamento sem desejo de gestar: AOC (1ª linha), metformina 500-2000mg/dia, espironolactona para hirsutismo. "
            "Com desejo de gestar: clomifeno 50-150mg D2-D6, letrozol 2,5-7,5mg (evidência crescente). "
            "Perda de 5-10% do peso melhora ciclos em 70% das pacientes."
        ),
        category="ginecologia",
        source="FEBRASGO — SOP 2023 | ESHRE/ASRM Guidelines 2023",
        evidence_level="A",
        confidence=0.96,
        tags=["SOP", "ovários policísticos", "hirsutismo", "anovulação", "metformina", "clomifeno"],
    ),
    KnowledgeDoc(
        doc_id="GIN-003",
        content=(
            "Miomatose uterina: miomas são o tumor benigno mais frequente em mulheres em idade reprodutiva. "
            "Classificação FIGO: 0 (submucoso pediculado) a 8 (parasita). "
            "Tratamento sem desejo de gestar: DIU-LNG reduz fluxo em até 90% (1ª linha clínica), "
            "embolização de artérias uterinas (EAU), histerectomia se prole completa. "
            "Com desejo de gestar: miomectomia (histeroscópica para tipo 0-1, laparoscópica para subserosos). "
            "Análogos GnRH pré-op reduzem volume em 30-50%. Ácido tranexâmico para sangramento agudo."
        ),
        category="ginecologia",
        source="FEBRASGO — Miomatose 2023",
        evidence_level="A",
        confidence=0.93,
        tags=["mioma", "miomatose", "sangramento", "miomectomia", "DIU", "histerectomia"],
    ),

    # ── Obstetrícia ───────────────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="OBS-001",
        content=(
            "Pré-eclâmpsia: PA ≥140×90 após 20 semanas + proteinúria ≥300mg/24h OU critério de gravidade. "
            "Critérios de gravidade (sem exigência de proteinúria): PA ≥160×110, trombocitopenia <100k, "
            "disfunção hepática (AST/ALT >2x), IRA (creatinina >1,1), EAP, sintomas neurológicos. "
            "Tratamento: internação, MgSO4 4-6g IV (ataque) + 1-2g/h (manutenção), "
            "hidralazina 5-10mg IV ou nifedipino 10mg VO em emergência hipertensiva. "
            "Antídoto MgSO4: gluconato de cálcio 1g IV. Corticoide se <34 semanas. "
            "Monitorar: diurese, reflexos, FR (toxicidade MgSO4 se <12/min)."
        ),
        category="obstetricia",
        source="FEBRASGO — Emergências Obstétricas 2023 | WHO 2023",
        evidence_level="A",
        confidence=0.98,
        tags=["pré-eclâmpsia", "hipertensão gestacional", "MgSO4", "eclâmpsia", "emergência obstétrica"],
    ),
    KnowledgeDoc(
        doc_id="OBS-002",
        content=(
            "Pré-natal de baixo risco — exames 1º trimestre: tipagem + Rh, Coombs indireto, hemograma, "
            "glicemia jejum, VDRL, anti-HIV, toxoplasmose IgG/IgM, HBsAg, urina I + urocultura, TSH. "
            "US morfológico 1º trimestre (11s-13s6d). Vacinação: dTpa (27-36s), Influenza, HepB. "
            "Consultas mínimas: 6 no pré-natal de baixo risco. Estratificação de risco na 1ª consulta. "
            "Sinais de alerta: sangramento, dor abdominal intensa, ausência de movimentos fetais após 28s, "
            "cefaleia intensa, edema súbito, febre, disúria."
        ),
        category="obstetricia",
        source="MS — Caderno APS nº32 2022 | FEBRASGO 2023",
        evidence_level="A",
        confidence=0.94,
        tags=["pré-natal", "gestação", "exames gestação", "vacinação gestante", "baixo risco"],
    ),

    # ── Violência doméstica ───────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="VD-001",
        content=(
            "Sinais físicos de VD: hematomas em diferentes fases, lesões em locais não expostos (tronco, coxas), "
            "lesões bilaterais simétricas, fraturas sem mecanismo compatível, lesões genitais, "
            "marcas de estrangulamento, queimaduras com padrão de imersão. "
            "Sinais comportamentais: evasiva, acompanhante fala por ela, medo excessivo, "
            "contradições no relato, ansiedade ao mencionar parceiro, consultas repetidas por queixas vagas. "
            "Protocolo: isolar a paciente, perguntar diretamente, não julgar, documentar objetivamente, "
            "notificar SINAN (obrigatório, Lei 10.778/2003), acionar assistente social, oferecer recursos."
        ),
        category="violencia_domestica",
        source="MS — Atenção Integral à Violência 2022 | Lei 10.778/2003",
        evidence_level="A",
        confidence=0.97,
        tags=["violência doméstica", "VD", "SINAN", "hematoma", "protocolo segurança"],
    ),
    KnowledgeDoc(
        doc_id="VD-002",
        content=(
            "Violência sexual: profilaxia IST obrigatória até 72h (AZT 300mg + 3TC 150mg + lopinavir/ritonavir). "
            "Contracepção de emergência: levonorgestrel 1,5mg até 72h (eficaz até 120h com menor eficácia) "
            "ou UPA até 120h. Coleta de material para perícia (com consentimento). "
            "Vacinas: hepatite B (se não imunizada) + anti-HPV. Acompanhamento psicológico imediato. "
            "Não exigir BO como condição para atendimento. IML para exame pericial se desejado pela vítima."
        ),
        category="violencia_domestica",
        source="MS — Norma Técnica Violência Sexual 2022",
        evidence_level="A",
        confidence=0.98,
        tags=["violência sexual", "profilaxia IST", "contracepção emergência", "IML", "PEP"],
    ),

    # ── Rastreamento / Prevenção ──────────────────────────────────────────
    KnowledgeDoc(
        doc_id="PREV-001",
        content=(
            "Rastreamento câncer colo do útero: Papanicolau anual entre 25-64 anos. "
            "Após 2 resultados normais consecutivos: repetir a cada 3 anos. "
            "ASC-US em <30 anos: repetir em 6 meses. ASC-US com HPV AR+: colposcopia. "
            "HSIL: colposcopia imediata. Vacinação HPV até 45 anos (Gardasil 9). "
            "Rastreamento mama: mamografia anual entre 40-74 anos (FEBRASGO); "
            "a partir de 35 anos se histórico familiar 1º grau. BI-RADS 4-5: biópsia obrigatória."
        ),
        category="rastreamento",
        source="INCA 2023 | FEBRASGO 2023 | SBM 2023",
        evidence_level="A",
        confidence=0.96,
        tags=["papanicolau", "mamografia", "rastreamento", "câncer colo", "câncer mama", "BI-RADS", "HPV"],
    ),
    KnowledgeDoc(
        doc_id="PREV-002",
        content=(
            "Densitometria óssea: indicada a partir de 65 anos (sem fatores de risco) ou "
            "60 anos (com FR: menopausa precoce, corticoides crônicos, baixo peso, tabagismo, história de fratura). "
            "Classificação OMS: T-score ≥-1 normal; -1 a -2,5 osteopenia; ≤-2,5 osteoporose. "
            "Tratamento osteoporose: bifosfonatos (alendronato 70mg/semana), suplementação Ca+D3. "
            "DXA a cada 2 anos para seguimento. FRAX para calcular risco de fratura."
        ),
        category="rastreamento",
        source="IOF 2023 | FEBRASGO 2023",
        evidence_level="B",
        confidence=0.91,
        tags=["densitometria", "osteoporose", "osteopenia", "menopausa", "bifosfonato"],
    ),

    # ── Saúde mental ──────────────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="SM-001",
        content=(
            "Depressão pós-parto (DPP): ocorre em 10-15% das puérperas. Rastreamento: EPDS (Edinburgh Postnatal "
            "Depression Scale) — score ≥10 sugere DPP; ≥13 DPP grave. Início: 4 semanas a 1 ano pós-parto. "
            "Sintomas: tristeza persistente, anedonia, insônia, sentimento de incapacidade como mãe, "
            "pensamentos de autolesão ou de prejudicar o bebê. "
            "Tratamento: psicoterapia (TCC) como 1ª linha em casos leves-moderados. "
            "Farmacoterapia compatível com AME: sertralina, nortriptilina. "
            "Psicose puerperal (rara, <0,2%): emergência psiquiátrica — internação imediata."
        ),
        category="saude_mental",
        source="MS — Saúde Mental 2023 | DSM-5-TR",
        evidence_level="A",
        confidence=0.95,
        tags=["depressão pós-parto", "DPP", "EPDS", "puerpério", "sertralina", "amamentação"],
    ),
    KnowledgeDoc(
        doc_id="SM-002",
        content=(
            "Saúde mental na gestação: ansiedade afeta 15-20% das gestantes. Rastreamento: GAD-7 (≥10 moderada). "
            "Psicofármacos e gestação: sertralina (categoria C, mais dados) — usar se benefício superar risco. "
            "Benzodiazepínicos: evitar no 1º trimestre e periparto (risco de síndrome de abstinência neonatal). "
            "1ª linha: psicoterapia, mindfulness, suporte social, exercício físico moderado. "
            "Risco de suicídio: avaliação imediata, não deixar a paciente sozinha, acionar psiquiatria."
        ),
        category="saude_mental",
        source="MS 2023 | NICE Antenatal Mental Health Guidelines",
        evidence_level="B",
        confidence=0.92,
        tags=["ansiedade gestacional", "gestação", "psicofármacos", "GAD-7", "suicídio", "sertralina"],
    ),

    # ── Planejamento familiar ─────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="PF-001",
        content=(
            "Anticoncepção — critérios de elegibilidade OMS: "
            "Categoria 1: sem restrição. Categoria 2: vantagens superam riscos. "
            "Categoria 3: riscos geralmente superam vantagens. Categoria 4: contraindicação absoluta. "
            "AOC contraindicado (Cat.4): tabagismo ≥35 anos, migrânea com aura, TEV ativo, HAS grave, "
            "amamentação <6 semanas, cardiopatia valvular com complicações. "
            "Métodos de longa duração (LARC): implante (>99,9%), DIU-Cu (>99%), DIU-LNG (>99%). "
            "Contracepção de emergência: LNG 1,5mg até 72h; UPA até 120h; DIU-Cu até 5 dias."
        ),
        category="planejamento_familiar",
        source="OMS — Critérios de Elegibilidade 2015 (atualizado 2023) | FEBRASGO 2023",
        evidence_level="A",
        confidence=0.97,
        tags=["anticoncepção", "AOC", "DIU", "implante", "contracepção emergência", "OMS", "LARC"],
    ),

    # ── Menopausa ─────────────────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="MEN-001",
        content=(
            "Menopausa: ausência de menstruação por 12 meses consecutivos sem outra causa. "
            "FSH >40 UI/L confirma falência ovariana. Média de idade: 51 anos no Brasil. "
            "Terapia Hormonal da Menopausa (THM): mais eficaz para fogachos e atrofia urogenital. "
            "Via transdérmica: menor risco trombótico e de AVC vs. oral. "
            "Janela de oportunidade: iniciar até 10 anos da menopausa ou antes de 60 anos. "
            "Contraindicações THM: CA mama ou endométrio ativos, TEV, DCV recente, hepatopatia grave. "
            "Alternativas não hormonais: paroxetina 7,5mg, venlafaxina 37,5-75mg, gabapentina 300mg. "
            "Estriol vaginal tópico: seguro mesmo em usuárias de inibidores de aromatase (discutir com oncologista)."
        ),
        category="menopausa",
        source="FEBRASGO — Climatério 2023 | NAMS 2023",
        evidence_level="A",
        confidence=0.93,
        tags=["menopausa", "climatério", "THM", "fogacho", "estriol", "osteoporose", "atrofia vaginal"],
    ),

    # ── Amamentação ──────────────────────────────────────────────────────
    KnowledgeDoc(
        doc_id="AME-001",
        content=(
            "AME recomendado até 6 meses (OMS/MS); complementar até 2 anos ou mais. "
            "Pega correta: boca bem aberta, lábios evertidos, aréola incluída, sem dor após primeiros dias. "
            "Fissuras mamilares: causa principal é pega incorreta — corrigir antes de suspender AME. "
            "Mastite: antibiótico (cefalexina 500mg 6/6h por 10-14 dias) — NÃO suspender AME. "
            "Abscesso mamário: drenagem + antibiótico — suspender temporariamente mama afetada. "
            "Contraindicações absolutas AME: HIV+ no Brasil, HTLV, galactosemia no RN. "
            "Medicamentos compatíveis com AME: paracetamol, ibuprofeno, amoxicilina, cefalosporinas, sertralina."
        ),
        category="amamentacao",
        source="OMS 2023 | MS — Amamenta Brasil | LactMed NIH",
        evidence_level="A",
        confidence=0.95,
        tags=["amamentação", "AME", "fissura", "mastite", "pega", "medicamentos lactação"],
    ),
]


# ===========================================================================
# Motor de recuperação vetorial (similaridade TF-IDF simplificada)
# Em produção: substituir por FAISS + sentence-transformers
# ===========================================================================

class SimpleVectorRetriever:
    """
    Recuperação por relevância textual usando TF-IDF simplificado.
    Suficiente para demonstrar o pipeline RAG — substituível por
    FAISS/ChromaDB + embeddings em produção.
    """

    def __init__(self, docs: list[KnowledgeDoc]):
        self.docs = docs
        self._index = self._build_index()

    def _tokenize(self, text: str) -> list[str]:
        text = text.lower()
        text = re.sub(r"[^a-záéíóúãõâêôçà\s]", " ", text)
        return [t for t in text.split() if len(t) > 2]

    def _build_index(self) -> dict[str, dict[str, float]]:
        """Constrói índice TF por documento."""
        index: dict[str, dict[str, float]] = {}
        for doc in self.docs:
            tokens = self._tokenize(doc.content + " " + " ".join(doc.tags))
            tf: dict[str, float] = {}
            for token in tokens:
                tf[token] = tf.get(token, 0) + 1
            total = max(len(tokens), 1)
            index[doc.doc_id] = {k: v / total for k, v in tf.items()}
        return index

    def _score(self, query_tokens: list[str], doc_id: str) -> float:
        tf = self._index.get(doc_id, {})
        return sum(tf.get(t, 0) for t in query_tokens)

    def retrieve(self, query: str, top_k: int = 3, min_score: float = 0.001) -> list[KnowledgeDoc]:
        """Recupera os top_k documentos mais relevantes para a query."""
        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []
        scored = [
            (doc, self._score(query_tokens, doc.doc_id))
            for doc in self.docs
        ]
        scored = [(doc, score) for doc, score in scored if score >= min_score]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [doc for doc, _ in scored[:top_k]]


# ===========================================================================
# Contextualização com dados reais da paciente
# ===========================================================================

class PatientContextualizer:
    """
    Entrega 2 — Contextualizar respostas com informações atualizadas da paciente.
    Consulta banco de dados e monta contexto clínico estruturado.
    """

    def build_context(self, patient_data: dict) -> str:
        """
        Recebe dict com dados da paciente (do banco) e monta
        bloco de contexto para o prompt do RAG.
        """
        lines = ["=== CONTEXTO CLÍNICO DA PACIENTE ==="]

        age = patient_data.get("idade")
        if age:
            lines.append(f"Idade: {age} anos")

        comorbidades = patient_data.get("comorbidades", [])
        if comorbidades:
            lines.append(f"Comorbidades: {', '.join(comorbidades)}")

        hist_fam = patient_data.get("historico_familiar", [])
        if hist_fam:
            lines.append(f"Histórico familiar: {', '.join(hist_fam)}")

        # Exames preventivos — alertas de atraso
        exames = patient_data.get("exames_preventivos", {})
        atrasados = self._check_overdue_exams(age, exames)
        if atrasados:
            lines.append(f"⚠️ Exames preventivos em atraso: {', '.join(atrasados)}")

        # Histórico obstétrico
        hist_obs = patient_data.get("historico_obstetrico")
        if hist_obs:
            lines.append(f"Histórico obstétrico: {hist_obs}")

        # Medicamentos em uso
        medicamentos = patient_data.get("medicamentos_em_uso", [])
        if medicamentos:
            lines.append(f"Medicamentos em uso: {', '.join(medicamentos)}")

        # Últimas consultas
        ultima_consulta = patient_data.get("ultima_consulta")
        if ultima_consulta:
            lines.append(f"Última consulta: {ultima_consulta}")

        lines.append("=== FIM DO CONTEXTO ===")
        return "\n".join(lines)

    def _check_overdue_exams(self, age: Optional[int], exames: dict) -> list[str]:
        """Identifica exames preventivos em atraso por idade e data."""
        atrasados = []
        now = datetime.utcnow()

        def months_ago(date_str) -> Optional[float]:
            if not date_str:
                return None
            try:
                d = datetime.strptime(date_str, "%Y-%m-%d")
                return (now - d).days / 30.44
            except Exception:
                return None

        if age and 25 <= age <= 64:
            m = months_ago(exames.get("papanicolau"))
            if m is None or m > 12:
                atrasados.append("Papanicolau")

        if age and age >= 40:
            m = months_ago(exames.get("mamografia"))
            if m is None or m > 12:
                atrasados.append("Mamografia")

        if age and age >= 60:
            m = months_ago(exames.get("densitometria"))
            if m is None or m > 24:
                atrasados.append("Densitometria óssea")

        if not exames.get("hiv"):
            atrasados.append("Teste HIV (nunca realizado)")

        return atrasados


# ===========================================================================
# Pipeline RAG principal
# ===========================================================================

class WomensHealthRAGPipeline:
    """
    Entrega 2 — Pipeline LangChain de integração especializada.

    Fluxo:
      1. Recebe query + dados da paciente
      2. Recupera documentos relevantes da base de conhecimento
      3. Contextualiza com dados reais da paciente
      4. Gera prompt estruturado com contexto clínico
      5. Retorna resposta com fonte, confiança e raciocínio exposto
    """

    def __init__(self):
        self.retriever = SimpleVectorRetriever(KNOWLEDGE_BASE)
        self.contextualizer = PatientContextualizer()

    def _build_prompt(
        self,
        query: str,
        retrieved_docs: list[KnowledgeDoc],
        patient_context: str,
        professional_role: str,
    ) -> str:
        """Monta o prompt estruturado para o LLM."""
        docs_block = "\n\n".join(
            f"[{doc.doc_id}] {doc.source} (Evidência {doc.evidence_level}, "
            f"Confiança {int(doc.confidence * 100)}%):\n{doc.content}"
            for doc in retrieved_docs
        )

        prompt = f"""Você é um assistente médico especializado em saúde da mulher.
NUNCA prescreva medicações. NUNCA emita diagnóstico definitivo.
SEMPRE cite a fonte da informação. SEMPRE indique o nível de confiança.
SEMPRE encaminhe casos de violência a profissionais qualificados.

{patient_context}

=== DOCUMENTOS RECUPERADOS DA BASE DE CONHECIMENTO ===
{docs_block}
=== FIM DOS DOCUMENTOS ===

Solicitante: {professional_role}

Pergunta/Situação: {query}

Responda de forma estruturada:
1. Cite qual(is) documento(s) embasam sua resposta
2. Explique o raciocínio clínico
3. Indique o nível de confiança
4. Destaque limitações e quando encaminhar
"""
        return prompt

    def _generate_response(
        self,
        query: str,
        docs: list[KnowledgeDoc],
        patient_context: str,
        professional_role: str,
    ) -> dict:
        """
        Gera resposta estruturada com explainability completa.
        Em produção: chamar LLM fine-tunado via API (Anthropic/OpenAI/vLLM).
        """
        # Calcular confiança composta
        if docs:
            avg_confidence = sum(d.confidence for d in docs) / len(docs)
            evidence_levels = [d.evidence_level for d in docs]
            top_evidence = "A" if "A" in evidence_levels else ("B" if "B" in evidence_levels else "C")
        else:
            avg_confidence = 0.5
            top_evidence = "C"

        # Detectar se é caso sensível
        sensitive_keywords = [
            "violência", "abuso", "suicídio", "autolesão", "depressão",
            "ansiedade grave", "crise", "ameaça"
        ]
        is_sensitive = any(kw in query.lower() for kw in sensitive_keywords)

        # Gerar corpo da resposta sintetizando os documentos recuperados
        if not docs:
            response_body = (
                "Não encontrei informações específicas na base de conhecimento para esta consulta. "
                "Recomendo consultar diretamente as diretrizes FEBRASGO, MS ou UpToDate."
            )
        else:
            # Sintetizar conteúdo dos docs recuperados
            key_points = []
            for doc in docs:
                # Extrair primeiras 2 frases de cada doc como pontos-chave
                sentences = doc.content.split(". ")[:2]
                key_points.append(f"• {'. '.join(sentences)}.")

            response_body = "\n".join(key_points)

        # Gerar fontes citadas
        sources_cited = [
            {
                "doc_id": doc.doc_id,
                "source": doc.source,
                "evidence_level": doc.evidence_level,
                "confidence": doc.confidence,
            }
            for doc in docs
        ]

        # Construir resposta final estruturada
        response_text = (
            f"{response_body}\n\n"
            f"**Fontes:** {' | '.join(d['source'] for d in sources_cited) if sources_cited else 'Não especificada'}\n"
            f"**Nível de evidência:** {top_evidence} | **Confiança:** {int(avg_confidence * 100)}%\n"
        )

        if is_sensitive:
            response_text += (
                "\n🔒 **Caso sensível identificado** — "
                "encaminhar imediatamente para equipe especializada. "
                "Manter sigilo absoluto."
            )

        # Guardrails de segurança
        safety_flags = self._check_safety_flags(query, response_text)
        if safety_flags:
            response_text += "\n\n⚠️ **Alertas de segurança:**\n" + "\n".join(f"- {f}" for f in safety_flags)

        return {
            "response": response_text,
            "sources": sources_cited,
            "confidence": avg_confidence,
            "evidence_level": top_evidence,
            "is_sensitive": is_sensitive,
            "safety_flags": safety_flags,
            "docs_retrieved": [d.doc_id for d in docs],
            "reasoning": f"Documentos recuperados: {[d.doc_id for d in docs]}. "
                         f"Confiança média: {avg_confidence:.2f}. "
                         f"Nível de evidência predominante: {top_evidence}.",
        }

    def _check_safety_flags(self, query: str, response: str) -> list[str]:
        """Guardrails de segurança — Entrega 4."""
        flags = []
        q = query.lower()
        r = response.lower()

        # Nunca prescrever
        if any(w in q for w in ["prescreva", "receite", "qual remédio tomar", "qual dose"]):
            flags.append("NUNCA prescrever medicação — encaminhar para médico especialista.")

        # Nunca diagnosticar definitivamente
        if any(w in q for w in ["tenho certeza que é", "confirme o diagnóstico", "pode afirmar que é"]):
            flags.append("NUNCA emitir diagnóstico definitivo — requer avaliação clínica presencial.")

        # Sintomas alarmantes → consulta presencial
        alarm_symptoms = ["dor torácica", "sangramento intenso", "perda de consciência",
                          "convulsão", "paralisia", "dificuldade respiratória"]
        if any(s in q for s in alarm_symptoms):
            flags.append("SEMPRE sugerir consulta presencial urgente para sintomas alarmantes.")

        # VD → encaminhamento obrigatório
        if any(w in q for w in ["violência", "agredida", "espancada", "estupro"]):
            flags.append("SEMPRE encaminhar casos de violência para profissionais qualificados.")
            flags.append("Central de Atendimento à Mulher: Ligue 180 (24h, gratuito).")

        return flags

    async def query(
        self,
        query: str,
        patient_data: dict,
        professional_role: str = "profissional_saude",
        top_k: int = 3,
    ) -> dict:
        """
        Ponto de entrada principal do pipeline RAG.
        Retorna resposta completa com explainability.
        """
        # 1. Recuperar documentos
        docs = self.retriever.retrieve(query, top_k=top_k)

        # 2. Contextualizar com dados da paciente
        patient_context = self.contextualizer.build_context(patient_data)

        # 3. Gerar resposta com explainability
        result = self._generate_response(
            query=query,
            docs=docs,
            patient_context=patient_context,
            professional_role=professional_role,
        )

        # 4. Adicionar prompt para auditoria
        result["prompt_used"] = self._build_prompt(query, docs, patient_context, professional_role)
        result["query"] = query
        result["patient_context_hash"] = hashlib.sha256(
            json.dumps(patient_data, sort_keys=True).encode()
        ).hexdigest()[:16]
        result["timestamp"] = datetime.utcnow().isoformat()

        return result

    def get_preventive_alerts(self, patient_data: dict) -> list[dict]:
        """
        Entrega 2 — Alertas automáticos para exames preventivos em atraso.
        """
        age = patient_data.get("idade")
        exames = patient_data.get("exames_preventivos", {})
        alerts = []
        now = datetime.utcnow()

        def months_since(date_str):
            if not date_str:
                return None
            try:
                return (now - datetime.strptime(date_str, "%Y-%m-%d")).days / 30.44
            except Exception:
                return None

        checks = [
            ("papanicolau", "Papanicolau", 12, 25, 64,
             "INCA 2023 — rastreamento anual", "alta"),
            ("mamografia", "Mamografia", 12, 40, 74,
             "FEBRASGO/SBM 2023 — anual a partir de 40 anos", "alta"),
            ("densitometria", "Densitometria Óssea", 24, 60, 120,
             "IOF 2023 — a cada 2 anos a partir de 60 anos", "media"),
            ("hiv", "Teste HIV", None, 15, 120,
             "MS — ao menos uma vez na vida", "media"),
        ]

        for field, label, max_months, age_min, age_max, guideline, urgency in checks:
            if not age or not (age_min <= age <= age_max):
                continue
            m = months_since(exames.get(field))
            if max_months is None:
                if exames.get(field) is None:
                    alerts.append({
                        "exame": label,
                        "motivo": "Nunca realizado",
                        "urgencia": urgency,
                        "diretriz": guideline,
                    })
            elif m is None or m > max_months:
                motivo = "Nunca realizado" if m is None else f"Último há {int(m)} meses (máximo recomendado: {max_months})"
                alerts.append({
                    "exame": label,
                    "motivo": motivo,
                    "urgencia": urgency,
                    "diretriz": guideline,
                })

        return alerts


# ===========================================================================
# Singleton para uso na API
# ===========================================================================

_pipeline_instance: Optional[WomensHealthRAGPipeline] = None


def get_rag_pipeline() -> WomensHealthRAGPipeline:
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = WomensHealthRAGPipeline()
        logger.info("RAG Pipeline inicializado com %d documentos.", len(KNOWLEDGE_BASE))
    return _pipeline_instance
