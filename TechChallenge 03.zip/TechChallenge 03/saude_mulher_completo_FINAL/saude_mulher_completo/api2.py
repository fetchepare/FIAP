"""
API REST — Hospital Santa Clara · Saúde da Mulher
FastAPI completamente integrada com banco de dados SQLite.

Iniciar:
    python api.py
    → http://10.93.81.156:8000          (front-end)
    → http://10.93.81.156:8000/docs     (Swagger interativo com Authorize)

Credenciais demo (senha sempre '1234'):
    CRM/SP-123456  →  Dra. Ana Beatriz Ferreira   (ginecologia)
    CRM/SP-234567  →  Dra. Carla Mendonça Lopes   (obstetricia)
    CRM/SP-345678  →  Dr.  Ricardo Alves Nogueira  (ginecologia)
    CRO/SP-567890  →  Dra. Juliana Martins Souza   (psicologia)
"""
from __future__ import annotations

import logging, os, sys, uuid
from datetime import datetime, timedelta
from typing import Optional

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.openapi.utils import get_openapi
from jose import JWTError, jwt
from pydantic import BaseModel, Field

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.repositories import (
    inicializar_db, criar_tabelas,
    HospitalRepo, MedicoRepo, PacienteRepo, ProntuarioRepo,
    ConsultaRepo, TriagemRepo, AlertaViolenciaRepo,
    AcompObstetricoRepo, ExamePreventivoRepo, LogAuditoriaRepo,
)
from database.integrations import (
    persistir_triagem, persistir_alerta_vd,
    persistir_obstetrico, persistir_prevencao,
)
from database.models import EspecialidadeEnum
from langgraph_flows.clinical_flows import (
    build_gynecological_triage_graph, build_domestic_violence_graph,
    build_obstetric_graph, build_prevention_graph,
    GynecologicalTriageState, DomesticViolenceState,
    ObstetricState, PreventionState,
    UrgencyLevel, ViolenceRisk,
)
from langgraph_flows.professional_qa_flow import (
    build_professional_qa_graph,
    ProfessionalQAState,
    QuestionCategory, ComplexityLevel,
)
from langchain_core.messages import HumanMessage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

JWT_SECRET    = os.environ.get("JWT_SECRET", "santa_clara_dev_2024")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_H  = 8
DB_URL        = os.environ.get("DB_URL", "sqlite+aiosqlite:///./hospital_santa_clara.db")

app = FastAPI(title="Hospital Santa Clara — Saúde da Mulher", version="1.0.0", docs_url="/docs")

# Configurar security scheme para Swagger
security = HTTPBearer(auto_error=False, description="Digite: Bearer <seu_token_jwt>")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

# Customizar OpenAPI para adicionar o botão Authorize
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Digite: Bearer <seu_token_jwt>"
        }
    }
    openapi_schema["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

@app.on_event("startup")
async def startup():
    inicializar_db(DB_URL)
    await criar_tabelas()
    logger.info("Banco pronto: %s", DB_URL)

# ─── JWT ────────────────────────────────────────────────────────────────────
def criar_token(crm: str, nome: str, role: str) -> str:
    return jwt.encode({"sub": crm, "nome": nome, "role": role,
                       "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRE_H)},
                      JWT_SECRET, algorithm=JWT_ALGORITHM)

# ============================================================
# FUNÇÃO CORRETA - NÃO USA HEADER OBRIGATÓRIO
# ============================================================
async def verificar_token(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security),
) -> dict:
    """
    Verifica o token JWT.
    Suporta tanto o botão Authorize do Swagger quanto o header Authorization direto.
    """
    token = None

    # Tentar pegar do Security (botão Authorize do Swagger)
    if credentials:
        token = credentials.credentials

    # Se não tem via Security, tentar do header direto via Request
    else:
        auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
        if auth_header and auth_header.lower().startswith("bearer "):
            token = auth_header[7:]

    if not token:
        raise HTTPException(
            status_code=401,
            detail="Token não fornecido. Use o botão Authorize no topo da página ou envie Authorization: Bearer <seu_token>"
        )

    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except JWTError as e:
        raise HTTPException(401, f"Token expirado ou inválido: {str(e)}")

# ─── Schemas ────────────────────────────────────────────────────────────────
class LoginReq(BaseModel):
    crm: str
    senha: str

class PacienteCreate(BaseModel):
    nome: str
    cpf: Optional[str] = None
    data_nascimento: Optional[str] = None
    telefone: Optional[str] = None
    email: Optional[str] = None
    convenio: Optional[str] = None
    comorbidades: list[str] = []
    historico_familiar: list[str] = []

class TriagemReq(BaseModel):
    paciente_id: int
    sintomas: str = Field(..., min_length=5)
    duracao: Optional[str] = None
    sintomas_associados: list[str] = []
    historico_relevante: Optional[str] = None

class VDReq(BaseModel):
    paciente_id: int
    notas_consulta: str = Field(..., min_length=10)
    criancas_em_risco: bool = False

class ObstetricoReq(BaseModel):
    paciente_id: int
    ig_semanas: int = Field(..., ge=4, le=42)
    ig_dias: int = Field(0, ge=0, le=6)
    historico_obstetrico: str = "G1P0A0"
    comorbidades: list[str] = []
    pa_sistolica: Optional[int] = None
    pa_diastolica: Optional[int] = None

class PrevencaoReq(BaseModel):
    paciente_id: int
    idade: int = Field(..., ge=15, le=100)
    ultimo_papanicolau: Optional[str] = None
    ultima_mamografia: Optional[str] = None
    ultima_densitometria: Optional[str] = None
    historico_familiar: list[str] = []
    comorbidades: list[str] = []

# ─── Auth ────────────────────────────────────────────────────────────────────
@app.post("/auth/login", tags=["Auth"])
async def login(req: LoginReq):
    if req.senha != "1234":
        raise HTTPException(401, "Credenciais inválidas")
    med = await MedicoRepo.buscar_por_crm(req.crm)
    if not med:
        raise HTTPException(401, f"CRM não encontrado: {req.crm}")
    token = criar_token(req.crm, med.nome, med.especialidade.value)
    return {"token": token, "medico_id": med.id, "nome": med.nome,
            "especialidade": med.especialidade.value, "expires_in": JWT_EXPIRE_H * 3600}

# Endpoint para testar autenticação
@app.get("/auth/test", tags=["Auth"])
async def test_auth(token: dict = Depends(verificar_token)):
    """Testa se o token está funcionando - NÃO requer header, usa botão Authorize"""
    return {"status": "ok", "usuario": token.get("nome"), "crm": token.get("sub")}

# ============================================================
# TODO: Adicione AQUI todo o resto do seu código
# (pacientes, fluxos, dashboard, histórico, profissional,
#  tratamentos, VD, coordenação, intake, RAG, segurança)
# ============================================================

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)