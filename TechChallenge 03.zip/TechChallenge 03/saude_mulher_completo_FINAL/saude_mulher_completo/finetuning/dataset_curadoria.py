"""
Curadoria e Preparação de Dataset para Fine-Tuning — Saúde da Mulher
======================================================================
Entrega Técnica 1 — Fine-tuning de LLM com dados médicos especializados

Responsabilidades:
  - Coletar e estruturar exemplos de protocolos médicos especializados
  - Anonimizar dados sensíveis (VD, saúde mental) rigorosamente
  - Preprocessar terminologia médica feminina
  - Balancear dataset entre condições e faixas etárias
  - Exportar no formato Alpaca/ChatML para fine-tuning (LoRA/QLoRA)

Uso:
    python -m finetuning.dataset_curadoria --output data/dataset_saude_mulher.jsonl
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "Você é um assistente médico especializado em saúde da mulher, treinado nos protocolos "
    "do Hospital Santa Clara, diretrizes do Ministério da Saúde, FEBRASGO, INCA, OMS e USPSTF. "
    "Você NUNCA prescreve medicações sem validação de especialista. "
    "Você NUNCA emite diagnósticos definitivos. "
    "Você SEMPRE encaminha casos suspeitos de violência para profissionais qualificados. "
    "Você SEMPRE sugere consulta presencial para sintomas alarmantes. "
    "Você mantém confidencialidade absoluta em casos de violência doméstica. "
    "Suas respostas citam a fonte do protocolo utilizado e indicam o nível de confiança."
)


# ===========================================================================
# Estrutura de exemplo de treinamento
# ===========================================================================

@dataclass
class TrainingExample:
    """Unidade mínima do dataset de fine-tuning no formato ChatML/Alpaca."""
    instruction: str          # pergunta ou situação clínica
    input: str                # contexto adicional (pode ser vazio)
    output: str               # resposta esperada do modelo
    category: str             # categoria do exemplo
    subcategory: str          # subcategoria específica
    source: str               # origem do protocolo (FEBRASGO, MS, INCA...)
    confidence: float         # nível de confiança 0.0–1.0
    age_range: str            # faixa etária alvo
    socioeconomic: str        # perfil socioeconômico representado
    is_sensitive: bool        # True = VD, saúde mental, etc.
    validated_by: str         # especialista validador (anonimizado)
    split: str = "train"      # train / val / test


# ===========================================================================
# Base de exemplos por categoria de protocolo
# ===========================================================================

PROTOCOL_EXAMPLES: list[dict] = [

    # ── 1. Protocolos ginecológicos e obstétricos ──────────────────────────
    {
        "category": "protocolo_ginecologico",
        "subcategory": "triagem_sintomas",
        "source": "FEBRASGO — Manual de Ginecologia 2023",
        "confidence": 0.95,
        "age_range": "18-65",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "ginecoB_anon",
        "instruction": "Paciente de 32 anos relata dor pélvica crônica há 8 meses, dismenorreia progressiva e dispareunia. Como devo conduzir a triagem inicial?",
        "input": "Sem cirurgias prévias. Ciclo regular. Sem uso de contraceptivos.",
        "output": (
            "**Triagem — Suspeita de Endometriose** _(Fonte: FEBRASGO 2023, Nível A | Confiança: 95%)_\n\n"
            "A tríade dismenorreia progressiva + dispareunia profunda + dor pélvica crônica é altamente sugestiva de endometriose.\n\n"
            "**Conduta inicial:**\n"
            "1. Anamnese dirigida: início e progressão da dor, impacto na qualidade de vida (escala EVA), histórico familiar\n"
            "2. Exame físico: toque bimanual (nódulos nos ligamentos uterossacros), especular\n"
            "3. Solicitar: US transvaginal (endometriomas ≥2cm visíveis), CA-125 (valor limitado — mais útil para seguimento)\n"
            "4. Escores validados: Questionário de Sintomas de Endometriose (BSGE)\n\n"
            "⚠️ O diagnóstico definitivo é cirúrgico (laparoscopia + histopatológico). "
            "Este sistema NÃO emite diagnóstico definitivo — encaminhe para ginecologista especializado em endometriose.\n\n"
            "**Urgência:** PRIORITÁRIO — agendar em até 14 dias."
        ),
    },
    {
        "category": "protocolo_obstetrico",
        "subcategory": "emergencia_obstetrica",
        "source": "FEBRASGO — Emergências Obstétricas 2023 | WHO 2023",
        "confidence": 0.98,
        "age_range": "15-45",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "obstetA_anon",
        "instruction": "Gestante de 34 semanas chega com PA 170x110, cefaleia intensa, visão turva e edema +++. Qual o protocolo?",
        "input": "Primigesta. Sem histórico de HAS prévia. Exame: proteinúria 2+ na fita.",
        "output": (
            "**⚠️ EMERGÊNCIA OBSTÉTRICA — Pré-Eclâmpsia Grave** _(Fonte: FEBRASGO/WHO, Nível A | Confiança: 98%)_\n\n"
            "Critérios preenchidos: PA ≥160×110 + sintomas neurológicos + proteinúria. Internação imediata.\n\n"
            "**Protocolo imediato (acionar médico AGORA):**\n"
            "1. Sulfato de Magnésio: 4-6g IV em 15-20min (ataque) → 1-2g/h (manutenção) — profilaxia de eclâmpsia\n"
            "2. Anti-hipertensivo: Hidralazina 5mg IV (repetir a cada 20min se necessário) ou Nifedipino 10mg VO\n"
            "3. Monitorar: diurese (sonda vesical), reflexos patelares, FR (toxicidade MgSO4 se <12/min)\n"
            "4. Antídoto MgSO4: Gluconato de cálcio 1g IV disponível à beira-leito\n"
            "5. CTG contínuo — avaliação do bem-estar fetal\n"
            "6. Corticoide: Betametasona 12mg IM 24/24h (2 doses) para maturidade pulmonar\n"
            "7. Decisão sobre via e momento do parto: equipe obstétrica + neonatologia\n\n"
            "🚨 Este sistema NÃO substitui avaliação presencial imediata. Médico deve ser acionado AGORA."
        ),
    },
    {
        "category": "protocolo_obstetrico",
        "subcategory": "pre_natal",
        "source": "MS — Caderno de Atenção Básica nº32 2022",
        "confidence": 0.93,
        "age_range": "15-45",
        "socioeconomic": "baixo_médio",
        "is_sensitive": False,
        "validated_by": "obstetA_anon",
        "instruction": "Gestante de 10 semanas, primeira consulta pré-natal. Quais exames solicitar?",
        "input": "G1P0A0. 25 anos. SUS. Sem comorbidades referidas.",
        "output": (
            "**Pré-Natal — 1º Trimestre** _(Fonte: MS/Caderno APS nº32, Nível A | Confiança: 93%)_\n\n"
            "**Exames obrigatórios (1º trimestre):**\n"
            "- Tipagem sanguínea e Fator Rh + Coombs indireto\n"
            "- Hemograma completo\n"
            "- Glicemia de jejum\n"
            "- VDRL (sífilis)\n"
            "- Anti-HIV\n"
            "- Toxoplasmose IgG e IgM\n"
            "- HBsAg (Hepatite B)\n"
            "- Urina tipo I + urocultura\n"
            "- TSH\n"
            "- US obstétrico morfológico 1º trimestre (11-13s+6d) — rastreamento aneuploidias\n\n"
            "**Vacinações:** Hepatite B (se não imunizada), dTpa (27-36 semanas), Influenza\n\n"
            "**Próxima consulta:** 14-16 semanas\n\n"
            "⚠️ Estratificar risco gestacional nesta consulta — encaminhar ao pré-natal de alto risco se indicado."
        ),
    },

    # ── 2. Violência doméstica ─────────────────────────────────────────────
    {
        "category": "violencia_domestica",
        "subcategory": "identificacao_sinais",
        "source": "MS — Atenção Integral à Mulher em Situação de Violência 2022 | Lei 10.778/2003",
        "confidence": 0.97,
        "age_range": "15-80",
        "socioeconomic": "todos",
        "is_sensitive": True,
        "validated_by": "social_anon",
        "instruction": "Durante a consulta, percebo que a paciente está evasiva, com hematoma no antebraço coberto por manga longa em dia quente, e o acompanhante responde por ela. O que devo fazer?",
        "input": "Paciente de 38 anos. Veio para queixa de 'dor de cabeça'. Acompanhante masculino presente.",
        "output": (
            "**🔴 Sinais de Alerta — Violência Doméstica Suspeita** _(Fonte: MS/Lei 10.778, Nível A | Confiança: 97%)_\n\n"
            "Sinais identificados: comportamento evasivo + lesão encoberta + acompanhante controlador = alto índice de suspeita.\n\n"
            "**Protocolo imediato:**\n"
            "1. **Separar** a paciente do acompanhante — use pretexto clínico ('preciso fazer o exame físico, aguarde aqui')\n"
            "2. **Perguntar diretamente** em ambiente privado: 'Em casa, alguém já te machucou ou te fez sentir com medo?'\n"
            "3. **Não julgar, não pressionar** — ela revela quando estiver pronta\n"
            "4. **Documentar objetivamente** no prontuário: lesão no antebraço D, 4×2cm, equimose em fase de resolução\n"
            "5. **Notificação SINAN** — obrigatória pela Lei 10.778/2003, independente do consentimento\n"
            "6. Acionar **Assistente Social** ainda neste atendimento\n\n"
            "🔒 SIGILO ABSOLUTO — jamais comentar suspeita na frente do acompanhante.\n\n"
            "📞 Ligue 180 — Central de Atendimento à Mulher (informar à paciente discretamente).\n\n"
            "⚠️ Este sistema SEMPRE encaminha casos suspeitos para profissionais qualificados. "
            "Acionar equipe multidisciplinar imediatamente."
        ),
    },
    {
        "category": "violencia_domestica",
        "subcategory": "notificacao_sinan",
        "source": "Lei 10.778/2003 | Lei Maria da Penha 11.340/2006 | MS 2022",
        "confidence": 0.99,
        "age_range": "todos",
        "socioeconomic": "todos",
        "is_sensitive": True,
        "validated_by": "juridico_anon",
        "instruction": "A paciente confirmou sofrer violência do parceiro mas diz que não quer fazer BO nem notificação. Devo notificar mesmo assim?",
        "input": "",
        "output": (
            "**Notificação Compulsória — Obrigação Legal** _(Fonte: Lei 10.778/2003 | Confiança: 99%)_\n\n"
            "**Sim. A notificação ao SINAN é obrigatória independente do consentimento da vítima.**\n\n"
            "A Lei 10.778/2003 determina que todo profissional de saúde DEVE notificar violência contra a mulher. "
            "Não notificar configura omissão punível.\n\n"
            "**O que notificar:** Ficha de Notificação/Investigação de Violência Interpessoal (SINAN)\n\n"
            "**O que explicar à paciente:**\n"
            "- A notificação vai para a Vigilância Epidemiológica, não para a delegacia automaticamente\n"
            "- O Boletim de Ocorrência é uma decisão dela — você não pode obrigá-la\n"
            "- Você está do lado dela, não contra ela\n\n"
            "**Se há crianças no domicílio:** Notificação ao Conselho Tutelar obrigatória (ECA, Art. 13).\n\n"
            "⚠️ Respeite o tempo dela para outras decisões — mas a notificação SINAN é feita agora."
        ),
    },

    # ── 3. Triagem para câncer ─────────────────────────────────────────────
    {
        "category": "rastreamento_cancer",
        "subcategory": "cancer_colo_utero",
        "source": "INCA — Controle do Câncer do Colo do Útero 2023",
        "confidence": 0.96,
        "age_range": "25-64",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "oncoB_anon",
        "instruction": "Paciente de 28 anos, último Papanicolau há 2 anos. Resultado: ASC-US. Como proceder?",
        "input": "Não vacinada para HPV. Vida sexual ativa. Sem histórico de lesões prévias.",
        "output": (
            "**Resultado ASC-US — Conduta** _(Fonte: INCA 2023, Nível A | Confiança: 96%)_\n\n"
            "ASC-US (células escamosas atípicas de significado indeterminado) é o resultado mais comum e geralmente tem boa evolução.\n\n"
            "**Conduta recomendada pelo INCA:**\n"
            "Repetir colpocitologia em **6 meses** (conduta conservadora preferencial em <30 anos).\n\n"
            "**Alternativa:** Teste de HPV de alto risco reflexo — se disponível e paciente preferir.\n\n"
            "**Se repetição confirmar ASC-US ou resultado mais grave:** encaminhar para **colposcopia**.\n\n"
            "**Sobre vacinação HPV:**\n"
            "Indicada até 45 anos — vacinar mesmo com resultado alterado (não trata infecção existente, mas protege contra outros subtipos).\n\n"
            "⚠️ Este sistema não emite diagnóstico definitivo de lesão cervical. "
            "Seguimento com ginecologista obrigatório."
        ),
    },
    {
        "category": "rastreamento_cancer",
        "subcategory": "cancer_mama",
        "source": "SBM — Diretrizes de Mastologia 2023 | FEBRASGO 2023",
        "confidence": 0.95,
        "age_range": "35-74",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "oncoB_anon",
        "instruction": "Paciente de 42 anos relata nódulo na mama esquerda, indolor, descoberto no autoexame. Qual conduta?",
        "input": "Mãe com câncer de mama diagnosticada aos 52 anos. Sem biópsia prévia.",
        "output": (
            "**Nódulo Mamário — Avaliação Inicial** _(Fonte: SBM/FEBRASGO 2023, Nível A | Confiança: 95%)_\n\n"
            "Nódulo palpável + histórico familiar de 1º grau = investigação prioritária.\n\n"
            "**Conduta imediata:**\n"
            "1. **Exame físico** completo das mamas (tamanho, consistência, mobilidade, pele, linfonodos)\n"
            "2. **Mamografia bilateral** + **US mamária** — complementares, não substitutas\n"
            "   - Mamografia: detecta microcalcificações\n"
            "   - US: diferencia sólido de cístico, avalia mamas densas\n"
            "3. Classificar pelo **BI-RADS** após imageamento\n\n"
            "**BI-RADS e conduta:**\n"
            "- 1-2: Rotina\n- 3: Controle em 6 meses\n- 4-5: **Biópsia obrigatória**\n- 6: Maligno confirmado\n\n"
            "**Histórico familiar:** Solicitar avaliação de risco BRCA (HBOC) se ≥2 familiares de 1º grau ou diagnóstico jovem.\n\n"
            "⚠️ Urgência: PRIORITÁRIO — encaminhar ao mastologista em até 7 dias. "
            "Este sistema NÃO diagnostica câncer."
        ),
    },

    # ── 4. Saúde mental da mulher ──────────────────────────────────────────
    {
        "category": "saude_mental",
        "subcategory": "depressao_pos_parto",
        "source": "MS — Saúde Mental na Atenção Básica 2023 | DSM-5-TR",
        "confidence": 0.94,
        "age_range": "15-45",
        "socioeconomic": "misto",
        "is_sensitive": True,
        "validated_by": "psicoC_anon",
        "instruction": "Puérpera de 28 dias relata choro frequente, insônia, sentir que não é boa mãe e pensamentos de que seria melhor 'desaparecer'. O que fazer?",
        "input": "Parto cesáreo há 28 dias. Amamentando com dificuldade. Sem suporte familiar próximo.",
        "output": (
            "**🔴 ALERTA — Depressão Pós-Parto com Risco** _(Fonte: MS/DSM-5-TR | Confiança: 94%)_\n\n"
            "Pensamento de 'desaparecer' constitui **ideação passiva de morte** — requer avaliação psiquiátrica IMEDIATA.\n\n"
            "**Conduta AGORA:**\n"
            "1. Perguntar diretamente: 'Você tem pensado em se machucar ou tirar sua própria vida?'\n"
            "2. **Não deixar a paciente sozinha** — acionar psicologia e psiquiatria de plantão\n"
            "3. Avaliar rede de apoio imediata — quem pode ficar com ela?\n"
            "4. Aplicar **Escala de Edimburgo** (EPDS) — pontuação ≥13 confirma DPP grave\n\n"
            "**Sobre amamentação e psicofármacos:**\n"
            "Sertralina e nortriptilina têm boa compatibilidade com AME — decisão com psiquiatra.\n\n"
            "🔒 Registrar na consulta com linguagem clínica objetiva.\n\n"
            "⚠️ Este sistema NUNCA prescreve medicação. Psiquiatra deve ser acionado agora. "
            "CVV: 188 (24h, gratuito) — fornecer à paciente."
        ),
    },
    {
        "category": "saude_mental",
        "subcategory": "ansiedade_gestacional",
        "source": "MS — Saúde Mental 2023 | NICE Guidelines Antenatal Mental Health",
        "confidence": 0.91,
        "age_range": "15-45",
        "socioeconomic": "baixo_médio",
        "is_sensitive": True,
        "validated_by": "psicoC_anon",
        "instruction": "Gestante de 20 semanas refere ansiedade intensa, medo de perder o bebê, insônia e dificuldade de concentração no trabalho.",
        "input": "Histórico de aborto espontâneo aos 10 semanas há 1 ano. SUS. Sem acesso fácil a psicólogo.",
        "output": (
            "**Ansiedade Gestacional — Avaliação e Conduta** _(Fonte: MS/NICE 2023, Nível B | Confiança: 91%)_\n\n"
            "Histórico de perda gestacional é fator de risco significativo para ansiedade na gestação atual — resposta esperada e tratável.\n\n"
            "**Rastreamento:** Aplicar GAD-7 (≥10 = ansiedade moderada-grave)\n\n"
            "**Conduta escalonada:**\n"
            "1. **Leve (GAD-7 <10):** Psicoeducação, técnicas de relaxamento, exercício físico moderado\n"
            "2. **Moderada (10-14):** Encaminhar ao CAPS ou psicólogo do NASF — terapia cognitivo-comportamental\n"
            "3. **Grave (≥15):** Avaliação psiquiátrica — considerar farmacoterapia (sertralina, categoria C)\n\n"
            "**Recurso SUS:** CAPS Mulher (se disponível no município) ou CRAS para suporte social\n\n"
            "⚠️ Validar o sofrimento: 'Faz todo sentido você sentir isso depois do que passou.' "
            "Este sistema NÃO prescreve medicação — encaminhar ao profissional adequado."
        ),
    },

    # ── 5. Planejamento familiar e saúde reprodutiva ───────────────────────
    {
        "category": "planejamento_familiar",
        "subcategory": "anticoncepção",
        "source": "FEBRASGO — Anticoncepção 2023 | OMS — Critérios de Elegibilidade",
        "confidence": 0.97,
        "age_range": "15-50",
        "socioeconomic": "todos",
        "is_sensitive": False,
        "validated_by": "ginecoB_anon",
        "instruction": "Paciente de 38 anos, fumante de 20 cigarros/dia, PA 130x85, migrânea com aura. Solicita anticoncepcional oral combinado.",
        "input": "Sem filhos. Deseja anticoncepção eficaz. Não considera métodos de longa duração.",
        "output": (
            "**Anticoncepção — Avaliação de Elegibilidade** _(Fonte: OMS Critérios de Elegibilidade / FEBRASGO 2023, Nível A | Confiança: 97%)_\n\n"
            "**⚠️ AOC CONTRAINDICADO neste caso — OMS Categoria 4 (risco inaceitável):**\n"
            "- Tabagismo ≥15 cigarros/dia + idade ≥35 anos = risco trombótico muito elevado\n"
            "- Migrânea com aura = risco aumentado de AVC com estrogênio\n\n"
            "**Alternativas seguras (OMS Cat. 1-2):**\n"
            "1. **Desogestrel 75mcg** (minipílula) — sem estrogênio, seguro em migrânea com aura\n"
            "2. **DIU de cobre** — não hormonal, 10 anos, altamente eficaz\n"
            "3. **DIU de levonorgestrel** — progestogênio local, mínima absorção sistêmica\n"
            "4. **Implante subdérmico (etonogestrel)** — se considerar LARC, 3 anos, >99% eficácia\n\n"
            "**Reforçar:** cessação do tabagismo reduz risco cardiovascular e amplia opções contraceptivas.\n\n"
            "⚠️ Este sistema não prescreve — apresentar opções ao ginecologista para decisão compartilhada com a paciente."
        ),
    },

    # ── 6. Perguntas frequentes ────────────────────────────────────────────
    {
        "category": "faq",
        "subcategory": "amamentacao",
        "source": "OMS — Alimentação Infantil 2023 | MS — Amamenta Brasil",
        "confidence": 0.95,
        "age_range": "15-45",
        "socioeconomic": "todos",
        "is_sensitive": False,
        "validated_by": "enfermB_anon",
        "instruction": "Tenho uma fissura no mamilo e dor intensa ao amamentar. Devo parar de dar de mamar?",
        "input": "RN de 8 dias. Parto normal. Primeira vez amamentando.",
        "output": (
            "**Fissura Mamilar — Orientação** _(Fonte: MS/OMS, Nível A | Confiança: 95%)_\n\n"
            "**Não suspenda a amamentação** — fissuras geralmente indicam problema de pega, não contraindicação ao AME.\n\n"
            "**Causa mais comum:** pega incorreta — boca do bebê não cobre toda a aréola.\n\n"
            "**O que fazer:**\n"
            "1. Verificar a pega: boca bem aberta, lábios evertidos, aréola incluída (não só o mamilo)\n"
            "2. Iniciar pela mama menos dolorida\n"
            "3. Aplicar **leite materno** no mamilo após cada mamada — cicatrizante natural\n"
            "4. **Lanolina pura** (se disponível) — pode ser aplicada sem remover antes de amamentar\n"
            "5. Deixar os mamilos ao ar após as mamadas\n"
            "6. Compressas mornas antes e frias após para alívio\n\n"
            "**Procurar ajuda se:** febre, vermelhidão intensa, secreção purulenta (mastite).\n\n"
            "💡 Solicitar apoio de consultora de amamentação (IBCLC) — disponível em muitas UBS e maternidades."
        ),
    },
    {
        "category": "faq",
        "subcategory": "menopausa_climatério",
        "source": "FEBRASGO — Climatério 2023 | NAMS 2023",
        "confidence": 0.93,
        "age_range": "40-65",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "ginecoB_anon",
        "instruction": "Tenho 51 anos, sem menstruar há 14 meses, fogachos intensos que me acordam à noite e ressecamento vaginal. O que posso fazer?",
        "input": "Sem histórico de câncer. Não fumante. Hipertensa controlada com losartana.",
        "output": (
            "**Menopausa Confirmada — Opções Terapêuticas** _(Fonte: FEBRASGO/NAMS 2023, Nível A | Confiança: 93%)_\n\n"
            "Você preenche critérios de menopausa (12 meses sem menstruação) com sintomas climatéricos moderados-graves.\n\n"
            "**Opções mais eficazes para fogachos:**\n"
            "1. **Terapia Hormonal da Menopausa (THM)** — tratamento mais eficaz\n"
            "   - Hipertensão controlada NÃO é contraindicação absoluta\n"
            "   - Preferir **via transdérmica** (menor impacto na PA e coagulação)\n"
            "   - Decisão final com ginecologista após avaliação individual\n"
            "2. **Não hormonais (se THM contraindicada):** Paroxetina 7,5mg, Venlafaxina 37,5mg, Gabapentina 300mg/noite\n\n"
            "**Para o ressecamento vaginal:**\n"
            "- **Estriol vaginal tópico** — absorção mínima, muito seguro, não requer progesterona\n"
            "- Lubrificantes e umectantes sem receita para uso imediato\n\n"
            "⚠️ Este sistema não prescreve. Agende com ginecologista para avaliação completa e prescrição. "
            "Mamografia e preventivo em dia? Ótimo momento para verificar."
        ),
    },
    {
        "category": "faq",
        "subcategory": "ciclo_menstrual",
        "source": "FEBRASGO — Distúrbios do Ciclo Menstrual 2023",
        "confidence": 0.90,
        "age_range": "12-50",
        "socioeconomic": "baixo_médio",
        "is_sensitive": False,
        "validated_by": "ginecoB_anon",
        "instruction": "Minha menstruação atrasa sempre, vem a cada 40-50 dias e é muito irregular. Isso é normal?",
        "input": "Paciente de 22 anos. Sem uso de contraceptivos. IMC 28. Tem pelos no rosto.",
        "output": (
            "**Irregularidade Menstrual — Avaliação** _(Fonte: FEBRASGO 2023, Nível B | Confiança: 90%)_\n\n"
            "Ciclos >35 dias (oligomenorreia) com hirsutismo e sobrepeso são altamente sugestivos de **Síndrome dos Ovários Policísticos (SOP)**.\n\n"
            "**A SOP é a causa mais comum de irregularidade menstrual em mulheres jovens.**\n\n"
            "**Investigação recomendada:**\n"
            "- TSH, prolactina, FSH, LH, testosterona total e livre\n"
            "- US transvaginal (morfologia ovariana)\n"
            "- Glicemia de jejum + insulina (resistência insulínica)\n\n"
            "**Enquanto isso:**\n"
            "- Redução de 5-10% do peso melhora significativamente a regularidade menstrual na SOP\n"
            "- Dieta com baixo índice glicêmico ajuda no controle hormonal\n\n"
            "⚠️ Ciclos irregulares não diagnosticados NÃO devem ser ignorados. "
            "Este sistema NÃO faz diagnóstico — agendar com ginecologista para investigação completa."
        ),
    },

    # ── 7. Documentos especializados ──────────────────────────────────────
    {
        "category": "documento_clinico",
        "subcategory": "laudo_us_ginecologico",
        "source": "CFM — Normas de Laudos de Imagem 2023",
        "confidence": 0.88,
        "age_range": "18-65",
        "socioeconomic": "misto",
        "is_sensitive": False,
        "validated_by": "radioA_anon",
        "instruction": "Como estruturar um laudo de ultrassonografia transvaginal para uma paciente com suspeita de endometriose?",
        "input": "",
        "output": (
            "**Estrutura de Laudo — US Transvaginal (Endometriose)** _(Fonte: CFM/ISUOG | Confiança: 88%)_\n\n"
            "**1. Identificação:** Nome (anonimizado no sistema), data, examinador, equipamento\n\n"
            "**2. Útero:**\n"
            "- Posição (anteversoflexão / retroversão)\n"
            "- Dimensões (comprimento × largura × espessura) em cm\n"
            "- Ecotextura (homogênea/heterogênea)\n"
            "- Contorno (regular/irregular)\n"
            "- Endométrio: espessura e aspecto\n\n"
            "**3. Ovários (bilateral):**\n"
            "- Dimensões\n"
            "- Presença de cistos: tamanho, conteúdo (ground-glass = sugestivo de endometrioma), vascularização ao Doppler\n"
            "- Mobilidade (aderências = ovário 'fixo')\n\n"
            "**4. Fundo de saco de Douglas:** obliterado (sinal slide positivo/negativo)\n\n"
            "**5. Achados adicionais:** ascite, hidrossalpinge, nódulos nos ligamentos uterossacros\n\n"
            "**6. Impressão diagnóstica:** descrever achados sem diagnóstico definitivo se não há confirmação histopatológica.\n\n"
            "⚠️ Laudo deve ser assinado por médico especialista. Este sistema apoia estruturação, não emite laudo oficial."
        ),
    },
    {
        "category": "documento_clinico",
        "subcategory": "relatorio_atendimento_vd",
        "source": "MS — Normas Técnicas para Atenção à Violência 2022",
        "confidence": 0.97,
        "age_range": "todos",
        "socioeconomic": "todos",
        "is_sensitive": True,
        "validated_by": "social_anon",
        "instruction": "Como redigir o prontuário de uma paciente com suspeita de violência doméstica sem expô-la a riscos?",
        "input": "",
        "output": (
            "**Documentação Segura — Violência Doméstica** _(Fonte: MS 2022, Nível A | Confiança: 97%)_\n\n"
            "**Princípios:** objetivo, descritivo, sem julgamentos, sem identificar o agressor pelo nome.\n\n"
            "**Estrutura recomendada:**\n\n"
            "**Queixa principal:** Usar aspas para o relato literal da paciente.\n"
            "Ex: Paciente refere 'caí da escada' ao ser questionada sobre equimose em região periorbital D.\n\n"
            "**Achados físicos:** Descrever localização, dimensões, coloração e fase das lesões.\n"
            "Ex: Equimose de 3×2cm em região periorbital direita, coloração verde-amarelada, "
            "sugestiva de trauma há 5-7 dias.\n\n"
            "**Comportamento observado:** Descrever objetivamente, sem interpretação.\n"
            "Ex: Paciente apresentou-se ansiosa, evitando contato visual, respondendo monossilabicamente em presença do acompanhante.\n\n"
            "**Inconsistências:** Registrar sem acusar.\n"
            "Ex: Mecanismo de trauma relatado (queda de escada) é inconsistente com a distribuição e fase das lesões.\n\n"
            "**Conduta:** Notificação SINAN realizada (nº XXXX). Assistente social acionada. Recursos informados.\n\n"
            "🔒 Prontuário marcado como RESTRITO — acesso somente à equipe responsável."
        ),
    },
]


# ===========================================================================
# Pipeline de preprocessamento
# ===========================================================================

class MedicalTextPreprocessor:
    """
    Preprocessamento especializado para terminologia médica feminina.
    Entrega 1 — Técnicas de preprocessing específicas.
    """

    # Abreviações clínicas comuns em ginecologia/obstetrícia
    ABBREV_MAP = {
        r"\bIG\b": "idade gestacional",
        r"\bDUM\b": "data da última menstruação",
        r"\bPA\b": "pressão arterial",
        r"\bRN\b": "recém-nascido",
        r"\bAME\b": "aleitamento materno exclusivo",
        r"\bDPP\b": "depressão pós-parto",
        r"\bSOP\b": "síndrome dos ovários policísticos",
        r"\bASC-US\b": "células escamosas atípicas de significado indeterminado",
        r"\bHPV\b": "papilomavírus humano",
        r"\bVD\b": "violência doméstica",
        r"\bACO\b": "anticoncepcionais orais combinados",
        r"\bTHM\b": "terapia hormonal da menopausa",
        r"\bFIV\b": "fertilização in vitro",
        r"\bIUI\b": "inseminação intrauterina",
        r"\bCTG\b": "cardiotocografia",
        r"\bEPDS\b": "Escala de Depressão Pós-Parto de Edimburgo",
    }

    # Termos sensíveis a remover/anonimizar
    PII_PATTERNS = [
        (r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b", "[CPF_ANONIMIZADO]"),
        (r"\b\d{7,8}-?\d{1}\b", "[RG_ANONIMIZADO]"),
        (r"\b[A-Z][a-z]+ [A-Z][a-z]+\b", "[NOME_ANONIMIZADO]"),
        (r"\b(?:Rua|Av\.|Avenida|R\.)\s+\S+(?:\s+\S+){0,3},?\s*\d+", "[ENDERECO_ANONIMIZADO]"),
        (r"\b\d{2}/\d{2}/\d{4}\b", "[DATA_ANONIMIZADA]"),
        (r"\b\(\d{2}\)\s*\d{4,5}-?\d{4}\b", "[TELEFONE_ANONIMIZADO]"),
    ]

    def normalize(self, text: str) -> str:
        """Normaliza unicode, remove acentos duplos, padroniza espaços."""
        text = unicodedata.normalize("NFC", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def expand_abbreviations(self, text: str) -> str:
        """Expande abreviações clínicas para treinamento mais rico."""
        for pattern, expansion in self.ABBREV_MAP.items():
            text = re.sub(pattern, expansion, text)
        return text

    def anonymize(self, text: str) -> str:
        """Remove PII rigorosamente — obrigatório para dados de VD e saúde mental."""
        for pattern, replacement in self.PII_PATTERNS:
            text = re.sub(pattern, replacement, text)
        return text

    def hash_identifier(self, identifier: str) -> str:
        """Pseudonimização de identificadores para auditoria."""
        return hashlib.sha256(identifier.encode()).hexdigest()[:16]

    def preprocess(self, text: str, anonymize: bool = True) -> str:
        text = self.normalize(text)
        text = self.expand_abbreviations(text)
        if anonymize:
            text = self.anonymize(text)
        return text


# ===========================================================================
# Balanceamento e curadoria
# ===========================================================================

class DatasetCurator:
    """
    Curadoria final do dataset.
    Entrega 1 — Balanceamento e inclusão de perfis socioeconômicos.
    """

    def __init__(self):
        self.preprocessor = MedicalTextPreprocessor()

    def _to_training_example(self, raw: dict) -> TrainingExample:
        proc = self.preprocessor
        is_sensitive = raw.get("is_sensitive", False)
        return TrainingExample(
            instruction=proc.preprocess(raw["instruction"], anonymize=is_sensitive),
            input=proc.preprocess(raw.get("input", ""), anonymize=is_sensitive),
            output=proc.preprocess(raw["output"], anonymize=is_sensitive),
            category=raw["category"],
            subcategory=raw["subcategory"],
            source=raw["source"],
            confidence=raw.get("confidence", 0.9),
            age_range=raw.get("age_range", "adulto"),
            socioeconomic=raw.get("socioeconomic", "misto"),
            is_sensitive=is_sensitive,
            validated_by=raw.get("validated_by", "pendente"),
        )

    def balance(self, examples: list[TrainingExample]) -> list[TrainingExample]:
        """
        Garante representatividade entre categorias, faixas etárias
        e perfis socioeconômicos. Emite warnings para categorias sub-representadas.
        """
        from collections import Counter
        cats = Counter(e.category for e in examples)
        ages = Counter(e.age_range for e in examples)
        socios = Counter(e.socioeconomic for e in examples)

        logger.info(f"Categorias: {dict(cats)}")
        logger.info(f"Faixas etárias: {dict(ages)}")
        logger.info(f"Perfis socioeconômicos: {dict(socios)}")

        # Alertar categorias com < 2 exemplos
        for cat, count in cats.items():
            if count < 2:
                logger.warning(f"Categoria sub-representada: '{cat}' ({count} exemplo). Adicionar mais exemplos.")

        return examples

    def split(self, examples: list[TrainingExample], train=0.8, val=0.1) -> list[TrainingExample]:
        """Divide em train/val/test estratificado por categoria."""
        import random
        from collections import defaultdict
        random.seed(42)

        by_cat: dict[str, list] = defaultdict(list)
        for ex in examples:
            by_cat[ex.category].append(ex)

        result = []
        for cat_examples in by_cat.values():
            random.shuffle(cat_examples)
            n = len(cat_examples)
            n_train = max(1, int(n * train))
            n_val = max(0, int(n * val))
            for i, ex in enumerate(cat_examples):
                if i < n_train:
                    ex.split = "train"
                elif i < n_train + n_val:
                    ex.split = "val"
                else:
                    ex.split = "test"
                result.append(ex)
        return result

    def to_alpaca_format(self, ex: TrainingExample) -> dict:
        """Exporta no formato Alpaca para fine-tuning com LoRA/QLoRA."""
        return {
            "system": SYSTEM_PROMPT,
            "instruction": ex.instruction,
            "input": ex.input,
            "output": ex.output,
            "metadata": {
                "category": ex.category,
                "subcategory": ex.subcategory,
                "source": ex.source,
                "confidence": ex.confidence,
                "age_range": ex.age_range,
                "socioeconomic": ex.socioeconomic,
                "is_sensitive": ex.is_sensitive,
                "split": ex.split,
                "validated_by": ex.validated_by,
                "generated_at": datetime.utcnow().isoformat(),
            },
        }

    def to_chatml_format(self, ex: TrainingExample) -> dict:
        """Exporta no formato ChatML para modelos instruction-tuned."""
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        if ex.input:
            messages.append({"role": "user", "content": f"{ex.instruction}\n\nContexto: {ex.input}"})
        else:
            messages.append({"role": "user", "content": ex.instruction})
        messages.append({"role": "assistant", "content": ex.output})
        return {
            "messages": messages,
            "metadata": {
                "category": ex.category,
                "source": ex.source,
                "confidence": ex.confidence,
                "split": ex.split,
                "is_sensitive": ex.is_sensitive,
            },
        }

    def build_and_export(self, output_dir: str = "finetuning/data") -> dict:
        """Pipeline completo: curar → balancear → dividir → exportar."""
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        # 1. Converter exemplos brutos
        examples = [self._to_training_example(r) for r in PROTOCOL_EXAMPLES]
        logger.info(f"Total de exemplos carregados: {len(examples)}")

        # 2. Balancear
        examples = self.balance(examples)

        # 3. Dividir
        examples = self.split(examples)

        # 4. Exportar Alpaca (JSONL)
        alpaca_path = Path(output_dir) / "dataset_saude_mulher_alpaca.jsonl"
        chatml_path = Path(output_dir) / "dataset_saude_mulher_chatml.jsonl"

        counts = {"train": 0, "val": 0, "test": 0}
        with open(alpaca_path, "w", encoding="utf-8") as fa, \
             open(chatml_path, "w", encoding="utf-8") as fc:
            for ex in examples:
                fa.write(json.dumps(self.to_alpaca_format(ex), ensure_ascii=False) + "\n")
                fc.write(json.dumps(self.to_chatml_format(ex), ensure_ascii=False) + "\n")
                counts[ex.split] += 1

        # 5. Manifesto
        manifest = {
            "generated_at": datetime.utcnow().isoformat(),
            "total_examples": len(examples),
            "splits": counts,
            "categories": list({e.category for e in examples}),
            "sources": list({e.source for e in examples}),
            "files": {
                "alpaca": str(alpaca_path),
                "chatml": str(chatml_path),
            },
            "system_prompt_hash": hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest()[:16],
        }
        manifest_path = Path(output_dir) / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))

        logger.info(f"Dataset exportado: {counts}")
        return manifest


# ===========================================================================
# Entry point
# ===========================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
    curator = DatasetCurator()
    manifest = curator.build_and_export()
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
