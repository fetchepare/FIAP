"""
Módulo de Segurança — Assistente Médico Saúde da Mulher

Implementa:
- Controle de acesso baseado em papéis (RBAC)
- Criptografia AES-256-GCM para dados sensíveis
- Hashing seguro com bcrypt/PBKDF2
- Logging de auditoria imutável
- Anonimização de dados
- Rate limiting por sessão
- Conformidade LGPD
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import time
import uuid
from base64 import b64encode, b64decode
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import IntEnum
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enumerações de segurança
# ---------------------------------------------------------------------------

class DataClassification(IntEnum):
    """Níveis de classificação de dados conforme LGPD."""
    PUBLIC = 1
    INTERNAL = 2
    CONFIDENTIAL = 3
    RESTRICTED = 4       # dados sensíveis: saúde mental, VD
    CRITICAL = 5         # risco de vida imediato


class UserRole(str):
    GYNECOLOGIST = "gynecologist"
    OBSTETRICIAN = "obstetrician"
    NURSE = "nurse"
    PSYCHOLOGIST = "psychologist"
    SOCIAL_WORKER = "social_worker"
    RADIOLOGIST = "radiologist"
    ADMIN = "admin"
    SECURITY_TEAM = "security_team"      # acesso a dados VD


# Mapeamento de permissões por papel
ROLE_PERMISSIONS: dict[str, dict[str, set[str]]] = {
    UserRole.GYNECOLOGIST: {
        "ginecologia": {"read", "write", "suggest"},
        "obstetricia": {"read", "write", "suggest"},
        "rastreamento_oncologico": {"read", "write"},
        "menopausa": {"read", "write", "suggest"},
        "violencia_domestica": {"read", "write"},
        "saude_mental": {"read"},
    },
    UserRole.OBSTETRICIAN: {
        "obstetricia": {"read", "write", "suggest"},
        "ginecologia": {"read"},
        "violencia_domestica": {"read"},
        "saude_mental": {"read"},
    },
    UserRole.NURSE: {
        "ginecologia": {"read"},
        "obstetricia": {"read"},
        "rastreamento_oncologico": {"read"},
        "violencia_domestica": {"read"},
        "saude_mental": {"read"},
    },
    UserRole.PSYCHOLOGIST: {
        "saude_mental": {"read", "write", "suggest"},
        "violencia_domestica": {"read", "write"},
        "ginecologia": {"read"},
    },
    UserRole.SOCIAL_WORKER: {
        "violencia_domestica": {"read", "write"},
        "saude_mental": {"read"},
    },
    UserRole.SECURITY_TEAM: {
        "violencia_domestica": {"read", "write", "alert"},
    },
    UserRole.ADMIN: {
        "*": {"read", "write", "suggest", "admin"},
    },
}


# ---------------------------------------------------------------------------
# Criptografia
# ---------------------------------------------------------------------------

class EncryptionService:
    """
    Criptografia AES-256-GCM para dados sensíveis.
    Cada operação de criptografia gera um nonce único.
    """

    KEY_SIZE = 32  # 256 bits

    def __init__(self, master_key: Optional[bytes] = None):
        if master_key:
            self._key = master_key
        else:
            # Em produção: carregar de vault (HashiCorp Vault, AWS KMS, Azure Key Vault)
            raw_key = os.environ.get("ENCRYPTION_MASTER_KEY", "")
            if not raw_key:
                logger.warning("ENCRYPTION_MASTER_KEY não configurada — usando chave efêmera insegura")
                raw_key = "chave_apenas_para_desenvolvimento_nao_usar_em_producao"

            salt = os.environ.get("ENCRYPTION_SALT", "saude_mulher_salt_v1").encode()
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=self.KEY_SIZE,
                salt=salt,
                iterations=600_000,
                backend=default_backend(),
            )
            self._key = kdf.derive(raw_key.encode())

        self._aesgcm = AESGCM(self._key)

    def encrypt(self, plaintext: str) -> str:
        """Encripta string e retorna base64(nonce + ciphertext)."""
        nonce = os.urandom(12)  # 96 bits para AES-GCM
        ciphertext = self._aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
        combined = nonce + ciphertext
        return b64encode(combined).decode("utf-8")

    def decrypt(self, encrypted_b64: str) -> str:
        """Decripta string a partir de base64(nonce + ciphertext)."""
        combined = b64decode(encrypted_b64.encode("utf-8"))
        nonce = combined[:12]
        ciphertext = combined[12:]
        plaintext = self._aesgcm.decrypt(nonce, ciphertext, None)
        return plaintext.decode("utf-8")

    def encrypt_dict(self, data: dict) -> str:
        """Encripta dicionário completo como JSON."""
        return self.encrypt(json.dumps(data, ensure_ascii=False, default=str))

    def decrypt_dict(self, encrypted_b64: str) -> dict:
        """Decripta e parseia JSON."""
        return json.loads(self.decrypt(encrypted_b64))


# ---------------------------------------------------------------------------
# Controle de Acesso (RBAC)
# ---------------------------------------------------------------------------

@dataclass
class Professional:
    id: str
    name: str
    role: str
    crm_crn: str
    specialties: list[str] = field(default_factory=list)
    active: bool = True
    mfa_enabled: bool = True


class AccessControlService:
    """RBAC para controle de acesso a domínios clínicos."""

    def __init__(self):
        self._professionals: dict[str, Professional] = {}
        self._sessions: dict[str, dict] = {}
        self._failed_attempts: dict[str, list[float]] = defaultdict(list)

    def register_professional(self, professional: Professional):
        self._professionals[professional.id] = professional
        logger.info(f"Profissional registrado: {professional.id} ({professional.role})")

    def authenticate(self, professional_id: str, credential: str) -> Optional[str]:
        """
        Autentica profissional e retorna token de sessão.
        Em produção: integrar com AD/LDAP hospitalar + MFA.
        """
        prof = self._professionals.get(professional_id)
        if not prof or not prof.active:
            self._record_failed_attempt(professional_id)
            return None

        # Verifica lockout (5 tentativas em 15 minutos)
        if self._is_locked_out(professional_id):
            logger.warning(f"Conta bloqueada por tentativas excessivas: {professional_id}")
            return None

        # Em produção: verificar hash da credencial com bcrypt
        session_token = str(uuid.uuid4())
        self._sessions[session_token] = {
            "professional_id": professional_id,
            "role": prof.role,
            "created_at": time.time(),
            "expires_at": time.time() + 28800,  # 8 horas
        }
        logger.info(f"Sessão criada: {professional_id} ({prof.role})")
        return session_token

    def authorize(self, professional_id: str, domain: str, action: str) -> bool:
        """Verifica se profissional tem permissão para a ação no domínio."""
        prof = self._professionals.get(professional_id)
        if not prof or not prof.active:
            return False

        permissions = ROLE_PERMISSIONS.get(prof.role, {})

        # Admin tem acesso total
        if "*" in permissions:
            return True

        domain_perms = permissions.get(domain, set())
        return action in domain_perms

    def _record_failed_attempt(self, professional_id: str):
        self._failed_attempts[professional_id].append(time.time())

    def _is_locked_out(self, professional_id: str) -> bool:
        now = time.time()
        recent = [
            t for t in self._failed_attempts[professional_id]
            if now - t < 900  # 15 minutos
        ]
        self._failed_attempts[professional_id] = recent
        return len(recent) >= 5


# ---------------------------------------------------------------------------
# Rate Limiting
# ---------------------------------------------------------------------------

class RateLimiter:
    """Limita requisições por sessão para evitar abuso."""

    def __init__(self, max_requests: int = 100, window_seconds: int = 3600):
        self.max_requests = max_requests
        self.window = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(list)

    def check(self, session_id: str) -> bool:
        """Retorna True se a requisição é permitida."""
        now = time.time()
        window_start = now - self.window
        recent = [t for t in self._requests[session_id] if t > window_start]
        self._requests[session_id] = recent

        if len(recent) >= self.max_requests:
            return False

        self._requests[session_id].append(now)
        return True


# ---------------------------------------------------------------------------
# Logging de Auditoria
# ---------------------------------------------------------------------------

@dataclass
class AuditEntry:
    audit_id: str
    timestamp: str
    event_type: str
    professional_id: str
    patient_id_hash: Optional[str]
    domain: Optional[str]
    action: str
    classification: str
    details: dict
    ip_hash: Optional[str] = None
    session_id: Optional[str] = None
    # Campos para VD — sempre encriptados
    sensitive: bool = False


class AuditLogger:
    """
    Logger de auditoria imutável com suporte a logs sensíveis encriptados.
    Em produção: usar banco append-only (PostgreSQL com RLS, ou S3 + CloudTrail).
    """

    def __init__(
        self,
        encryption_service: EncryptionService,
        log_path: str = "./logs/audit.jsonl",
        sensitive_log_path: str = "./logs/audit_sensitive.enc",
    ):
        self.encryption = encryption_service
        self.log_path = log_path
        self.sensitive_log_path = sensitive_log_path

        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        os.makedirs(os.path.dirname(sensitive_log_path), exist_ok=True)

    def _write_entry(self, entry: AuditEntry):
        data = asdict(entry)
        if entry.sensitive:
            # Logs sensíveis (VD) encriptados
            encrypted = self.encryption.encrypt(json.dumps(data, ensure_ascii=False))
            with open(self.sensitive_log_path, "a", encoding="utf-8") as f:
                f.write(encrypted + "\n")
        else:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data, ensure_ascii=False) + "\n")

    def log_consultation(
        self,
        professional_id: str,
        patient_id: Optional[str],
        domain: str,
        question_hash: str,
        response_hash: str,
        validation_result: dict,
        timestamp: str,
        session_id: str = "",
    ) -> str:
        audit_id = str(uuid.uuid4())
        is_sensitive = domain in ("violencia_domestica", "saude_mental")

        entry = AuditEntry(
            audit_id=audit_id,
            timestamp=timestamp,
            event_type="consultation",
            professional_id=professional_id,
            patient_id_hash=patient_id,
            domain=domain,
            action="query",
            classification=DataClassification.RESTRICTED.name if is_sensitive else DataClassification.CONFIDENTIAL.name,
            details={
                "question_hash": question_hash,
                "response_hash": response_hash,
                "validation": validation_result,
            },
            session_id=session_id,
            sensitive=is_sensitive,
        )

        self._write_entry(entry)
        return audit_id

    def log_unauthorized_access(self, professional_id: str, domain: str):
        entry = AuditEntry(
            audit_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow().isoformat(),
            event_type="unauthorized_access",
            professional_id=professional_id,
            patient_id_hash=None,
            domain=domain,
            action="denied",
            classification=DataClassification.CRITICAL.name,
            details={"reason": "insufficient_permissions"},
            sensitive=False,
        )
        self._write_entry(entry)
        logger.warning(f"Acesso não autorizado: {professional_id} → {domain}")

    def log_violence_alert(
        self,
        professional_id: str,
        patient_id_hash: str,
        risk_level: str,
        immediate_danger: bool,
    ) -> str:
        audit_id = str(uuid.uuid4())
        entry = AuditEntry(
            audit_id=audit_id,
            timestamp=datetime.utcnow().isoformat(),
            event_type="violence_alert",
            professional_id=professional_id,
            patient_id_hash=patient_id_hash,
            domain="violencia_domestica",
            action="alert_triggered",
            classification=DataClassification.CRITICAL.name,
            details={
                "risk_level": risk_level,
                "immediate_danger": immediate_danger,
                "team_notification": "SENT",
            },
            sensitive=True,
        )
        self._write_entry(entry)
        logger.critical(f"ALERTA VD — {patient_id_hash} — Risco: {risk_level}")
        return audit_id

    def log_data_access(
        self,
        professional_id: str,
        resource: str,
        patient_id_hash: str,
        classification: DataClassification,
    ):
        """Log de acesso a qualquer dado sensível (LGPD art. 37)."""
        entry = AuditEntry(
            audit_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow().isoformat(),
            event_type="data_access",
            professional_id=professional_id,
            patient_id_hash=patient_id_hash,
            domain=None,
            action="read",
            classification=classification.name,
            details={"resource": resource},
            sensitive=classification >= DataClassification.RESTRICTED,
        )
        self._write_entry(entry)


# ---------------------------------------------------------------------------
# Módulo de Segurança Unificado
# ---------------------------------------------------------------------------

class SecurityModule:
    """
    Ponto de entrada unificado para todos os serviços de segurança.
    Injetado em todas as camadas da aplicação.
    """

    def __init__(self):
        self.encryption = EncryptionService()
        self.access_control = AccessControlService()
        self.rate_limiter = RateLimiter()
        self._secret = os.environ.get(
            "HMAC_SECRET", "secret_para_desenvolvimento_apenas"
        ).encode()

    def authorize(self, professional_id: str, domain: str, action: str) -> bool:
        return self.access_control.authorize(professional_id, domain, action)

    def encrypt(self, data: str) -> str:
        return self.encryption.encrypt(data)

    def decrypt(self, data: str) -> str:
        return self.encryption.decrypt(data)

    def hash(self, data: str) -> str:
        """Hash HMAC-SHA256 determinístico para rastreabilidade sem expor PII."""
        return hmac.new(self._secret, data.encode(), hashlib.sha256).hexdigest()

    def anonymize_patient_id(self, patient_id: str) -> str:
        """Pseudonimização: mesmo ID sempre produz o mesmo hash."""
        return self.hash(f"patient:{patient_id}")[:16]

    def validate_professional_token(self, token: str) -> Optional[dict]:
        session = self.access_control._sessions.get(token)
        if not session:
            return None
        if time.time() > session["expires_at"]:
            del self.access_control._sessions[token]
            return None
        return session
