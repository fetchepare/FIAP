"""
Segurança, Validação e Auditoria Especializada — Saúde da Mulher
=================================================================
Entrega Técnica 4 — Segurança e validação especializadas

Módulos:
  ResponseValidator   — valida respostas do LLM antes do retorno ao usuário
                        (guards NUNCA/SEMPRE, detecção de prescrição/diagnóstico)

  ExplainabilityEngine — expõe raciocínio clínico, fonte, confiança por resposta

  PersistentAuditLogger — persiste todos os eventos no banco com criptografia
                          para dados sensíveis (VD, saúde mental)

  SecurityGuard        — verificação de identidade, alertas de emergência,
                         protocolo de crise
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)


# ===========================================================================
# 1. Validador de Respostas — ResponseValidator
# ===========================================================================

@dataclass
class ValidationResult:
    is_safe: bool
    confidence_score: float        # 0.0 – 1.0
    violations: list[str]          # guards violados
    warnings: list[str]            # avisos não bloqueantes
    modified_response: str         # resposta corrigida/bloqueada
    reasoning: str                 # raciocínio da validação
    sources_present: bool
    safety_flags: list[str]


class ResponseValidator:
    """
    Entrega 4 — Validação da resposta pelo LLM antes do retorno.
    Garante estabilidade e previsibilidade do sistema.

    Regras obrigatórias (NUNCA/SEMPRE):
      - NUNCA prescrever medicações sem validação de especialista
      - NUNCA diagnosticar definitivamente condições sensíveis
      - SEMPRE encaminhar casos suspeitos de violência
      - SEMPRE sugerir consulta presencial para sintomas alarmantes
      - SEMPRE citar fonte da informação
    """

    # Padrões que indicam prescrição indevida
    PRESCRIPTION_PATTERNS = [
        r"tome\s+\d+\s*mg",
        r"prescrevo\s+",
        r"receita\s+de\s+",
        r"use\s+\d+\s*(mg|ml|comprimido)",
        r"dose[:\s]+\d+\s*mg\s+(?:por dia|diária|ao dia)",
        r"posologia[:\s]+\d",
    ]

    # Padrões que indicam diagnóstico definitivo indevido
    DIAGNOSIS_PATTERNS = [
        r"você\s+tem\s+(certamente|definitivamente|com\s+certeza)\s+",
        r"diagnóstico\s+(?:é|confirmado)[:\s]+",
        r"confirmado[:\s]+(?:câncer|tumor|carcinoma)",
        r"é\s+(?:câncer|tumor|carcinoma|leucemia)\s+",
    ]

    # Sintomas alarmantes que exigem encaminhamento presencial
    ALARM_SYMPTOMS = [
        "dor torácica", "sangramento intenso", "perda de consciência",
        "convulsão", "paralisia", "dificuldade respiratória intensa",
        "pressão muito alta", "hemorragia", "desmaio", "choque",
        "febre alta na gestante", "ausência movimentos fetais",
    ]

    # Termos de violência que exigem encaminhamento
    VIOLENCE_TERMS = [
        "violência", "agredida", "espancada", "estupro", "abuso sexual",
        "ameaça de morte", "me bate", "me machuca", "marido bate",
    ]

    # Disclaimer obrigatório para respostas clínicas
    REQUIRED_DISCLAIMER = (
        "\n\n⚠️ *Esta resposta tem caráter informativo e educativo. "
        "NÃO substitui avaliação médica presencial. "
        "NÃO constitui prescrição ou diagnóstico definitivo.*"
    )

    def validate(self, response: str, query: str, context: dict = None) -> ValidationResult:
        """
        Valida a resposta antes de retornar ao usuário.
        Retorna ValidationResult com resposta possivelmente modificada.
        """
        violations: list[str] = []
        warnings: list[str] = []
        modified = response
        q_lower = query.lower()
        r_lower = response.lower()

        # ── Guard 1: NUNCA prescrever ──────────────────────────────────────
        for pattern in self.PRESCRIPTION_PATTERNS:
            if re.search(pattern, r_lower):
                violations.append(
                    "VIOLAÇÃO: Resposta contém padrão de prescrição médica. "
                    "Removido e substituído por orientação de encaminhamento."
                )
                modified = re.sub(
                    pattern,
                    "[PRESCRIÇÃO REMOVIDA — consultar médico especialista]",
                    modified,
                    flags=re.IGNORECASE,
                )

        # ── Guard 2: NUNCA diagnosticar definitivamente ────────────────────
        for pattern in self.DIAGNOSIS_PATTERNS:
            if re.search(pattern, r_lower):
                violations.append(
                    "VIOLAÇÃO: Resposta contém diagnóstico definitivo indevido. Corrigido."
                )
                modified = re.sub(
                    pattern,
                    "[DIAGNÓSTICO DEFINITIVO NÃO PERMITIDO — requer avaliação especializada] ",
                    modified,
                    flags=re.IGNORECASE,
                )

        # ── Guard 3: SEMPRE encaminhar casos de violência ──────────────────
        has_violence = any(term in q_lower for term in self.VIOLENCE_TERMS)
        has_referral = any(w in r_lower for w in [
            "encaminhar", "assistente social", "delegacia", "ligue 180",
            "equipe especializada", "psicóloga", "profissional qualificado",
        ])
        if has_violence and not has_referral:
            violations.append(
                "VIOLAÇÃO: Caso de violência sem encaminhamento obrigatório. Adicionado."
            )
            modified += (
                "\n\n🚨 **Encaminhamento obrigatório:** "
                "Acionar imediatamente assistente social e equipe especializada em VD. "
                "Central de Atendimento à Mulher: **Ligue 180** (24h, gratuito, sigiloso). "
                "SINAN: notificação compulsória obrigatória (Lei 10.778/2003)."
            )

        # ── Guard 4: SEMPRE sugerir presencial para sintomas alarmantes ────
        has_alarm = any(sym in q_lower for sym in self.ALARM_SYMPTOMS)
        has_presential = any(w in r_lower for w in [
            "consulta presencial", "ir ao pronto", "emergência", "upa",
            "hospital", "médico imediatamente", "avaliação presencial",
        ])
        if has_alarm and not has_presential:
            warnings.append(
                "AVISO: Sintoma alarmante identificado sem orientação de atendimento presencial. Adicionado."
            )
            modified += (
                "\n\n🏥 **Sintoma de alerta:** Procure atendimento médico presencial imediatamente."
            )

        # ── Guard 5: SEMPRE citar fonte ────────────────────────────────────
        sources_present = any(w in r_lower for w in [
            "febrasgo", "ministério da saúde", "ms —", "inca", "who", "oms",
            "fonte:", "guideline", "protocolo", "diretriz", "confiança:",
        ])
        if not sources_present and len(response) > 100:
            warnings.append("AVISO: Resposta sem citação de fonte. Disclaimer adicionado.")

        # ── Calcular score de confiança da validação ───────────────────────
        base_score = 1.0
        base_score -= len(violations) * 0.25
        base_score -= len(warnings) * 0.05
        confidence_score = max(0.0, min(1.0, base_score))

        # ── Adicionar disclaimer obrigatório ───────────────────────────────
        if self.REQUIRED_DISCLAIMER not in modified:
            modified += self.REQUIRED_DISCLAIMER

        is_safe = len(violations) == 0
        reasoning = (
            f"Validação concluída: {len(violations)} violação(ões), {len(warnings)} aviso(s). "
            f"Score de confiança: {confidence_score:.2f}. "
            f"Fontes presentes: {'sim' if sources_present else 'não'}."
        )

        return ValidationResult(
            is_safe=is_safe,
            confidence_score=confidence_score,
            violations=violations,
            warnings=warnings,
            modified_response=modified,
            reasoning=reasoning,
            sources_present=sources_present,
            safety_flags=[],
        )


# ===========================================================================
# 2. Motor de Explainability — ExplainabilityEngine
# ===========================================================================

@dataclass
class ExplainabilityReport:
    query_summary: str
    clinical_reasoning: str
    sources: list[dict]            # [{doc_id, source, evidence_level, confidence}]
    confidence_level: float
    confidence_label: str          # ALTA / MÉDIA / BAIXA / INCERTA
    evidence_grade: str            # A / B / C / Consenso
    knowledge_gaps: list[str]      # o que não foi encontrado na base
    recommended_actions: list[str] # próximos passos sugeridos
    limitations: list[str]         # limitações da resposta
    additional_info_needed: bool


class ExplainabilityEngine:
    """
    Entrega 4 — Explainability contextualizada.
    Expõe raciocínio clínico, fonte, confiança e limitações
    de forma compreensível para profissionais de saúde.
    """

    CONFIDENCE_LABELS = {
        (0.9, 1.01): "ALTA",
        (0.75, 0.9): "MÉDIA-ALTA",
        (0.6, 0.75): "MÉDIA",
        (0.4, 0.6):  "BAIXA",
        (0.0, 0.4):  "INCERTA",
    }

    def generate_report(
        self,
        query: str,
        rag_result: dict,
        validation_result: Optional[ValidationResult] = None,
    ) -> ExplainabilityReport:
        """
        Gera relatório de explainability completo para uma resposta.
        """
        sources = rag_result.get("sources", [])
        confidence = rag_result.get("confidence", 0.5)
        evidence_level = rag_result.get("evidence_level", "C")
        docs_retrieved = rag_result.get("docs_retrieved", [])

        # Label de confiança
        conf_label = "INCERTA"
        for (lo, hi), label in self.CONFIDENCE_LABELS.items():
            if lo <= confidence < hi:
                conf_label = label
                break

        # Raciocínio clínico estruturado
        if sources:
            src_list = "; ".join(f"{s['doc_id']} ({s['source']})" for s in sources)
            clinical_reasoning = (
                f"Resposta baseada em {len(sources)} documento(s) recuperado(s): {src_list}. "
                f"Nível de evidência predominante: {evidence_level}. "
                f"Confiança calculada: {confidence:.0%}."
            )
        else:
            clinical_reasoning = (
                "Nenhum documento específico foi recuperado da base de conhecimento. "
                "Resposta baseada em conhecimento geral — verificar com especialista."
            )

        # Lacunas de conhecimento
        gaps = []
        if not sources:
            gaps.append("Consulta não encontrou correspondência direta na base de protocolos.")
        if confidence < 0.7:
            gaps.append("Confiança abaixo de 70% — informações adicionais recomendadas.")
        if validation_result and validation_result.violations:
            gaps.append(f"Resposta original continha {len(validation_result.violations)} violação(ões) — corrigida automaticamente.")

        # Ações recomendadas
        actions = []
        q_lower = query.lower()
        if any(w in q_lower for w in ["emergência", "urgente", "grave", "imediato"]):
            actions.append("🚨 Caso urgente — acionar médico imediatamente.")
        if any(w in q_lower for w in ["violência", "agredida", "abuso"]):
            actions.append("Acionar equipe multidisciplinar (assistente social + psicóloga).")
            actions.append("Notificar SINAN — obrigatório por lei.")
        if evidence_level in ("B", "C"):
            actions.append("Evidência nível B/C — consultar especialista para caso complexo.")
        if not actions:
            actions.append("Acompanhar resposta clínica e retornar em caso de dúvida.")

        # Limitações
        limitations = [
            "Este sistema não emite diagnóstico definitivo.",
            "Este sistema não prescreve medicações.",
            "Respostas baseadas em protocolos — adaptar ao caso clínico individual.",
        ]
        if rag_result.get("is_sensitive"):
            limitations.append("Caso sensível — garantir sigilo absoluto no manejo das informações.")

        additional_needed = len(gaps) > 0 or confidence < 0.7

        return ExplainabilityReport(
            query_summary=query[:200] + ("..." if len(query) > 200 else ""),
            clinical_reasoning=clinical_reasoning,
            sources=sources,
            confidence_level=confidence,
            confidence_label=conf_label,
            evidence_grade=evidence_level,
            knowledge_gaps=gaps,
            recommended_actions=actions,
            limitations=limitations,
            additional_info_needed=additional_needed,
        )

    def format_for_api(self, report: ExplainabilityReport) -> dict:
        """Serializa o relatório para resposta da API."""
        return {
            "raciocinio_clinico": report.clinical_reasoning,
            "fontes": report.sources,
            "nivel_confianca": report.confidence_label,
            "score_confianca": round(report.confidence_level, 3),
            "grau_evidencia": report.evidence_grade,
            "lacunas_conhecimento": report.knowledge_gaps,
            "acoes_recomendadas": report.recommended_actions,
            "limitacoes": report.limitations,
            "informacao_adicional_necessaria": report.additional_info_needed,
        }


# ===========================================================================
# 3. Auditoria Persistente — PersistentAuditLogger
# ===========================================================================

class PersistentAuditLogger:
    """
    Entrega 4 — Logging e auditoria especializados com persistência no banco.

    Eventos registrados:
      - Todas as interações com o sistema (consultas, respostas)
      - Casos de violência doméstica (log separado, encriptado)
      - Acesso a dados sensíveis
      - Alertas automáticos emitidos
      - Violações detectadas pelo validador
    """

    def __init__(self):
        # Import lazy para evitar circular imports
        self._repo = None

    def _get_repo(self):
        if self._repo is None:
            from database.repositories import LogAuditoriaRepo
            self._repo = LogAuditoriaRepo
        return self._repo

    def _hash_patient(self, patient_id: str) -> str:
        """Pseudonimiza o ID da paciente para o log."""
        return hashlib.sha256(f"audit-salt-{patient_id}".encode()).hexdigest()[:32]

    def _encrypt_sensitive(self, data: dict) -> dict:
        """
        Encripta dados sensíveis para casos de VD e saúde mental.
        Em produção: usar Fernet (cryptography) com chave rotacionada.
        Aqui: marcação + hash para demonstrar o padrão.
        """
        sensitive_str = json.dumps(data, ensure_ascii=False)
        encrypted_hash = hashlib.sha256(sensitive_str.encode()).hexdigest()
        return {
            "__encrypted": True,
            "__hash": encrypted_hash,
            "__length": len(sensitive_str),
            "__timestamp": datetime.utcnow().isoformat(),
            # Em produção: substituir por Fernet.encrypt(sensitive_str.encode())
        }

    async def log_interaction(
        self,
        professional_id: str,
        patient_id: str,
        action: str,
        domain: str,
        details: dict,
        is_sensitive: bool = False,
        classification: str = "consulta",
    ) -> str:
        """
        Registra qualquer interação no banco de dados.
        Retorna o UUID do log para rastreabilidade.
        """
        audit_uuid = str(uuid.uuid4())
        patient_hash = self._hash_patient(str(patient_id))

        # Encriptar se sensível (VD, saúde mental)
        log_details = self._encrypt_sensitive(details) if is_sensitive else details

        try:
            repo = self._get_repo()
            await repo.registrar(
                audit_uuid=audit_uuid,
                tipo_evento=action,
                profissional_id=str(professional_id),
                dominio=domain,
                acao=action,
                classificacao=classification,
                detalhes=log_details,
                paciente_hash=patient_hash,
                sensivel=is_sensitive,
            )
            logger.info(
                f"Audit [{audit_uuid}] | {domain}.{action} | "
                f"Profissional: {professional_id[:8]}... | "
                f"Sensível: {is_sensitive}"
            )
        except Exception as e:
            # Audit nunca bloqueia o fluxo principal
            logger.error(f"Falha ao persistir audit log [{audit_uuid}]: {e}")

        return audit_uuid

    async def log_rag_query(
        self,
        professional_id: str,
        patient_id: str,
        query: str,
        rag_result: dict,
        validation_result: Optional[ValidationResult] = None,
        explainability: Optional[dict] = None,
    ) -> str:
        """Log especializado para consultas RAG."""
        is_sensitive = rag_result.get("is_sensitive", False)
        details = {
            "query_hash": hashlib.sha256(query.encode()).hexdigest()[:16],
            "docs_retrieved": rag_result.get("docs_retrieved", []),
            "confidence": rag_result.get("confidence", 0),
            "evidence_level": rag_result.get("evidence_level", ""),
            "safety_flags": rag_result.get("safety_flags", []),
            "violations": validation_result.violations if validation_result else [],
            "warnings": validation_result.warnings if validation_result else [],
            "is_sensitive": is_sensitive,
        }
        return await self.log_interaction(
            professional_id=professional_id,
            patient_id=patient_id,
            action="rag_query",
            domain="assistente_rag",
            details=details,
            is_sensitive=is_sensitive,
            classification="consulta_ia",
        )

    async def log_vd_alert(
        self,
        professional_id: str,
        patient_id: str,
        alert_level: str,
        signs_detected: dict,
        actions_taken: list[str],
        sinan_notified: bool,
        doc_id: str,
    ) -> str:
        """
        Log especializado para alertas de violência doméstica.
        Sempre encriptado. Rastreamento específico por legislação.
        """
        details = {
            "alert_level": alert_level,
            "physical_signs": signs_detected.get("physical", []),
            "behavioral_signs": signs_detected.get("behavioral", []),
            "contextual_signs": signs_detected.get("contextual", []),
            "actions_taken": actions_taken,
            "sinan_notified": sinan_notified,
            "documentation_id": doc_id,
            "timestamp": datetime.utcnow().isoformat(),
        }
        logger.warning(
            f"🚨 ALERTA VD [{doc_id}] | Nível: {alert_level} | "
            f"SINAN: {'SIM' if sinan_notified else 'PENDENTE'} | "
            f"Profissional: {professional_id[:8]}..."
        )
        return await self.log_interaction(
            professional_id=professional_id,
            patient_id=patient_id,
            action="vd_alert",
            domain="violencia_domestica",
            details=details,
            is_sensitive=True,       # SEMPRE encriptado
            classification="alerta_vd",
        )

    async def log_data_access(
        self,
        professional_id: str,
        patient_id: str,
        data_type: str,
        reason: str,
    ) -> str:
        """Log de acesso a dados sensíveis — auditoria de acesso."""
        details = {
            "data_type": data_type,
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat(),
        }
        is_sensitive = data_type in ("vd_records", "mental_health", "reproductive_history")
        return await self.log_interaction(
            professional_id=professional_id,
            patient_id=patient_id,
            action="data_access",
            domain="auditoria_acesso",
            details=details,
            is_sensitive=is_sensitive,
            classification="acesso_dado",
        )

    async def log_emergency_alert(
        self,
        professional_id: str,
        patient_id: str,
        alert_type: str,
        severity: str,
        details_extra: dict,
    ) -> str:
        """Log de alertas de emergência — aciona equipe de segurança."""
        details = {
            "alert_type": alert_type,
            "severity": severity,
            "auto_escalated": True,
            **details_extra,
        }
        logger.critical(
            f"🚨 EMERGÊNCIA [{alert_type}] | Severidade: {severity} | "
            f"Paciente hash: {self._hash_patient(str(patient_id))}"
        )
        return await self.log_interaction(
            professional_id=professional_id,
            patient_id=patient_id,
            action="emergency_alert",
            domain="seguranca_hospitalar",
            details=details,
            is_sensitive=True,
            classification="emergencia",
        )


# ===========================================================================
# 4. SecurityGuard — Protocolos de segurança específicos
# ===========================================================================

class SecurityGuard:
    """
    Entrega 4 — Protocolos de segurança específicos.

    - Verificação de identidade em casos sensíveis
    - Alertas automáticos para equipe de segurança
    - Protocolo de emergência para situações críticas
    - Criptografia de dados de VD
    """

    CRITICAL_TRIGGERS = [
        "suicídio", "me matar", "não quero viver", "me machucar",
        "me bater", "vai me matar", "ameaça de morte", "arma",
        "overdose", "sem saída",
    ]

    EMERGENCY_CONTACTS = {
        "CVV": "188 (24h, gratuito — prevenção ao suicídio)",
        "SAMU": "192",
        "Ligue 180": "Central de Atendimento à Mulher (24h, sigiloso)",
        "Disque 100": "Direitos Humanos",
    }

    def assess_crisis_risk(self, text: str) -> dict:
        """
        Avalia risco de crise em tempo real no texto da consulta.
        Retorna nível de risco e protocolo de ação.
        """
        text_lower = text.lower()
        triggers_found = [t for t in self.CRITICAL_TRIGGERS if t in text_lower]

        if len(triggers_found) >= 2:
            risk_level = "CRÍTICO"
            protocol = "emergencia_imediata"
        elif len(triggers_found) == 1:
            risk_level = "ALTO"
            protocol = "avaliacao_urgente"
        else:
            risk_level = "BAIXO"
            protocol = "monitoramento"

        actions = []
        if risk_level in ("CRÍTICO", "ALTO"):
            actions = [
                "Não deixar a paciente sozinha",
                "Acionar psicologia/psiquiatria de plantão imediatamente",
                "Contato: CVV 188 (24h)",
                "Remover acesso a meios potencialmente letosos",
            ]
            if risk_level == "CRÍTICO":
                actions.insert(0, "🚨 EMERGÊNCIA — acionar equipe de segurança AGORA")

        return {
            "risk_level": risk_level,
            "protocol": protocol,
            "triggers_found": triggers_found,
            "actions": actions,
            "emergency_contacts": self.EMERGENCY_CONTACTS if risk_level != "BAIXO" else {},
        }

    def verify_sensitive_access(
        self,
        professional_id: str,
        professional_role: str,
        data_type: str,
    ) -> dict:
        """
        Entrega 4 — Verificação de identidade para acesso a dados sensíveis.
        Retorna se o acesso é autorizado e o nível de permissão.
        """
        # Mapa de permissões por especialidade e tipo de dado
        PERMISSIONS = {
            "vd_records": ["ginecologia", "obstetricia", "servico_social", "psicologia", "enfermagem"],
            "mental_health": ["psicologia", "ginecologia", "obstetricia"],
            "reproductive_history": ["ginecologia", "obstetricia", "enfermagem"],
            "audit_logs": ["ginecologia"],  # somente médico responsável
        }
        allowed_roles = PERMISSIONS.get(data_type, [])
        is_authorized = professional_role.lower() in allowed_roles or professional_role == "admin"

        return {
            "authorized": is_authorized,
            "professional_id_hash": hashlib.sha256(professional_id.encode()).hexdigest()[:16],
            "data_type": data_type,
            "access_level": "PERMITIDO" if is_authorized else "NEGADO",
            "reason": "" if is_authorized else f"Especialidade '{professional_role}' não autorizada para '{data_type}'",
            "timestamp": datetime.utcnow().isoformat(),
        }


# ===========================================================================
# Singletons para uso na API
# ===========================================================================

_validator: Optional[ResponseValidator] = None
_explainer: Optional[ExplainabilityEngine] = None
_auditor: Optional[PersistentAuditLogger] = None
_guard: Optional[SecurityGuard] = None


def get_validator() -> ResponseValidator:
    global _validator
    if _validator is None:
        _validator = ResponseValidator()
    return _validator


def get_explainer() -> ExplainabilityEngine:
    global _explainer
    if _explainer is None:
        _explainer = ExplainabilityEngine()
    return _explainer


def get_auditor() -> PersistentAuditLogger:
    global _auditor
    if _auditor is None:
        _auditor = PersistentAuditLogger()
    return _auditor


def get_security_guard() -> SecurityGuard:
    global _guard
    if _guard is None:
        _guard = SecurityGuard()
    return _guard
