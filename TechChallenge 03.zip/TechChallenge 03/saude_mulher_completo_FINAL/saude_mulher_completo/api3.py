"""
API REST — Hospital Santa Clara · Saúde da Mulher
FastAPI completamente integrada com banco de dados SQLite.

Iniciar:
	python api.py
	→ http://10.93.81.156:8000		  (front-end)
	→ http://10.93.81.156:8000/docs	 (Swagger interativo com Authorize)

Credenciais demo (senha sempre '1234'):
	CRM/SP-123456  →  Dra. Ana Beatriz Ferreira   (ginecologia)
	CRM/SP-234567  →  Dra. Carla Mendonça Lopes   (obstetricia)
	CRM/SP-345678  →  Dr.  Ricardo Alves Nogueira  (ginecologia)
	CRO/SP-567890  →  Dra. Juliana Martins Souza   (psicologia)
"""
from __future__ import annotations

import logging, os, sys, uuid
from datetime import datetime, timedelta
from typing import Optional

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from jose import JWTError, jwt
from pydantic import BaseModel, Field

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.repositories import (
	inicializar_db, criar_tabelas,
	HospitalRepo, MedicoRepo, PacienteRepo, ProntuarioRepo,
	ConsultaRepo, TriagemRepo, AlertaViolenciaRepo,
	AcompObstetricoRepo, ExamePreventivoRepo, LogAuditoriaRepo,
)
from database.integrations import (
	persistir_triagem, persistir_alerta_vd,
	persistir_obstetrico, persistir_prevencao,
)
from database.models import EspecialidadeEnum
from langgraph_flows.clinical_flows import (
	build_gynecological_triage_graph, build_domestic_violence_graph,
	build_obstetric_graph, build_prevention_graph,
	GynecologicalTriageState, DomesticViolenceState,
	ObstetricState, PreventionState,
	UrgencyLevel, ViolenceRisk,
)
from langgraph_flows.professional_qa_flow import (
	build_professional_qa_graph,
	ProfessionalQAState,
	QuestionCategory, ComplexityLevel,
)
from langchain_core.messages import HumanMessage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

JWT_SECRET	= os.environ.get("JWT_SECRET", "santa_clara_dev_2024")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_H  = 8
DB_URL		= os.environ.get("DB_URL", "sqlite+aiosqlite:///./hospital_santa_clara.db")

app = FastAPI(title="Hospital Santa Clara — Saúde da Mulher", version="1.0.0", docs_url="/docs")

# Configurar security scheme para Swagger
security = HTTPBearer(auto_error=False, description="Digite: Bearer <seu_token_jwt>")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
				   allow_methods=["*"], allow_headers=["*"])

# Customizar OpenAPI para adicionar o botão Authorize
def custom_openapi():
	if app.openapi_schema:
		return app.openapi_schema
	
	from fastapi.openapi.utils import get_openapi
	openapi_schema = get_openapi(
		title=app.title,
		version=app.version,
		description=app.description,
		routes=app.routes,
	)
	
	openapi_schema["components"]["securitySchemes"] = {
		"BearerAuth": {
			"type": "http",
			"scheme": "bearer",
			"bearerFormat": "JWT",
			"description": "Digite: Bearer <seu_token_jwt>"
		}
	}
	openapi_schema["security"] = [{"BearerAuth": []}]
	
	app.openapi_schema = openapi_schema
	return app.openapi_schema

app.openapi = custom_openapi

@app.on_event("startup")
async def startup():
	inicializar_db(DB_URL)
	await criar_tabelas()
	logger.info("Banco pronto: %s", DB_URL)

# ─── JWT ────────────────────────────────────────────────────────────────────
def criar_token(crm: str, nome: str, role: str) -> str:
	return jwt.encode({"sub": crm, "nome": nome, "role": role,
					   "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRE_H)},
					  JWT_SECRET, algorithm=JWT_ALGORITHM)

# Suporta tanto o botão Authorize do Swagger quanto o header Authorization direto
async def verificar_token(
	request: Request,
	credentials: Optional[HTTPAuthorizationCredentials] = Security(security),
) -> dict:
	"""
	Verifica o token JWT.
	Suporta tanto o header Authorization direto quanto o botão Authorize do Swagger.
	"""
	token = None

	# Tentar pegar do Security (botão Authorize do Swagger)
	if credentials:
		token = credentials.credentials

	# Se não tem via Security, tentar do header direto via Request
	else:
		auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
		if auth_header and auth_header.lower().startswith("bearer "):
			token = auth_header[7:]

	if not token:
		raise HTTPException(
			status_code=401,
			detail="Token não fornecido. Use Authorization: Bearer <seu_token>"
		)

	try:
		return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
	except JWTError as e:
		raise HTTPException(401, f"Token expirado ou inválido: {str(e)}")

# ─── Schemas ────────────────────────────────────────────────────────────────
class LoginReq(BaseModel):
	crm: str
	senha: str

class PacienteCreate(BaseModel):
	nome: str
	cpf: Optional[str] = None
	data_nascimento: Optional[str] = None
	telefone: Optional[str] = None
	email: Optional[str] = None
	convenio: Optional[str] = None
	comorbidades: list[str] = []
	historico_familiar: list[str] = []

class TriagemReq(BaseModel):
	paciente_id: int
	sintomas: str = Field(..., min_length=5)
	duracao: Optional[str] = None
	sintomas_associados: list[str] = []
	historico_relevante: Optional[str] = None

class VDReq(BaseModel):
	paciente_id: int
	notas_consulta: str = Field(..., min_length=10)
	criancas_em_risco: bool = False

class ObstetricoReq(BaseModel):
	paciente_id: int
	ig_semanas: int = Field(..., ge=4, le=42)
	ig_dias: int = Field(0, ge=0, le=6)
	historico_obstetrico: str = "G1P0A0"
	comorbidades: list[str] = []
	pa_sistolica: Optional[int] = None
	pa_diastolica: Optional[int] = None

class PrevencaoReq(BaseModel):
	paciente_id: int
	idade: int = Field(..., ge=15, le=100)
	ultimo_papanicolau: Optional[str] = None
	ultima_mamografia: Optional[str] = None
	ultima_densitometria: Optional[str] = None
	historico_familiar: list[str] = []
	comorbidades: list[str] = []

# ─── Auth ────────────────────────────────────────────────────────────────────
@app.post("/auth/login", tags=["Auth"])
async def login(req: LoginReq):
	if req.senha != "1234":
		raise HTTPException(401, "Credenciais inválidas")
	med = await MedicoRepo.buscar_por_crm(req.crm)
	if not med:
		raise HTTPException(401, f"CRM não encontrado: {req.crm}")
	token = criar_token(req.crm, med.nome, med.especialidade.value)
	return {"token": token, "medico_id": med.id, "nome": med.nome,
			"especialidade": med.especialidade.value, "expires_in": JWT_EXPIRE_H * 3600}

# ─── Pacientes ───────────────────────────────────────────────────────────────
@app.get("/pacientes", tags=["Pacientes"])
async def listar_pacientes(token: dict = Depends(verificar_token)):
	pacientes = await PacienteRepo.listar_todos()
	result = []
	for p in pacientes:
		pront = await ProntuarioRepo.buscar_por_paciente(p.id)
		result.append({"id": p.id, "nome": p.nome, "telefone": p.telefone,
					   "convenio": p.convenio, "comorbidades": p.comorbidades or [],
					   "historico_familiar": p.historico_familiar or [],
					   "prontuario": pront.numero if pront else None})
	return result

@app.get("/pacientes/{pid}", tags=["Pacientes"])
async def detalhe_paciente(pid: int, token: dict = Depends(verificar_token)):
	pac = await PacienteRepo.buscar_por_id(pid)
	if not pac:
		raise HTTPException(404, "Paciente não encontrada")
	pront   = await ProntuarioRepo.buscar_por_paciente(pid)
	consult = await ConsultaRepo.listar_por_paciente(pid)
	exames  = await ExamePreventivoRepo.listar_pendentes(pid)
	return {"id": pac.id, "nome": pac.nome,
			"data_nascimento": pac.data_nascimento.strftime("%d/%m/%Y") if pac.data_nascimento else None,
			"telefone": pac.telefone, "email": pac.email, "convenio": pac.convenio,
			"comorbidades": pac.comorbidades or [], "historico_familiar": pac.historico_familiar or [],
			"prontuario": pront.numero if pront else None,
			"total_consultas": len(consult), "exames_pendentes": len(exames),
			"ultima_consulta": consult[0].data_hora.strftime("%d/%m/%Y %H:%M") if consult else None}

@app.post("/pacientes", tags=["Pacientes"])
async def criar_paciente(req: PacienteCreate, token: dict = Depends(verificar_token)):
	hosplist = await HospitalRepo.listar_todos()
	hosp_id  = hosplist[0].id if hosplist else 1
	nasc = datetime.strptime(req.data_nascimento, "%Y-%m-%d") if req.data_nascimento else None
	pac  = await PacienteRepo.criar(hospital_id=hosp_id, nome=req.nome, cpf=req.cpf,
									 data_nascimento=nasc, telefone=req.telefone,
									 email=req.email, convenio=req.convenio,
									 comorbidades=req.comorbidades,
									 historico_familiar=req.historico_familiar)
	await ProntuarioRepo.criar(pac.id, f"SC-{datetime.now().year}-{pac.id:04d}")
	return {"id": pac.id, "nome": pac.nome, "mensagem": "Paciente cadastrada com sucesso"}

# ─── Fluxo 1: Triagem ────────────────────────────────────────────────────────
@app.post("/fluxos/triagem", tags=["Fluxos"])
async def executar_triagem(req: TriagemReq, token: dict = Depends(verificar_token)):
	pac = await PacienteRepo.buscar_por_id(req.paciente_id)
	if not pac: raise HTTPException(404, "Paciente não encontrada")
	med = await MedicoRepo.buscar_por_crm(token["sub"])
	med_id = med.id if med else None

	graph  = build_gynecological_triage_graph()
	state: GynecologicalTriageState = {
		"messages": [HumanMessage(content=req.sintomas)],
		"patient_id": str(req.paciente_id), "symptoms": req.sintomas,
		"symptom_duration": req.duracao, "associated_symptoms": req.sintomas_associados,
		"relevant_history": req.historico_relevante, "risk_analysis": None,
		"urgency_level": None, "red_flags": [], "recommended_exams": [],
		"initial_guidance": None, "scheduling_type": None,
		"current_step": "start", "audit_log": [], "error": None,
	}
	result = await graph.ainvoke(state, config={"configurable": {"thread_id": f"t-{uuid.uuid4().hex[:8]}"}})
	tid	= await persistir_triagem(result, req.paciente_id, med_id)
	await LogAuditoriaRepo.registrar(str(uuid.uuid4()), "triage", token["sub"],
									  "ginecologia", "run", "CONFIDENTIAL", {"id": tid})
	urg = result.get("urgency_level", UrgencyLevel.ELECTIVE)
	return {"id": tid,
			"urgencia": urg.value if hasattr(urg, "value") else str(urg),
			"red_flags": result.get("red_flags", []),
			"exames_sugeridos": result.get("recommended_exams", []),
			"orientacao": result.get("initial_guidance", ""),
			"tipo_agendamento": result.get("scheduling_type", "agendamento_regular")}

# ─── Fluxo 2: Violência Doméstica ────────────────────────────────────────────
@app.post("/fluxos/violencia", tags=["Fluxos"])
async def executar_vd(req: VDReq, token: dict = Depends(verificar_token)):
	pac = await PacienteRepo.buscar_por_id(req.paciente_id)
	if not pac: raise HTTPException(404, "Paciente não encontrada")
	med	= await MedicoRepo.buscar_por_crm(token["sub"])
	med_id = med.id if med else 1

	graph  = build_domestic_violence_graph()
	state: DomesticViolenceState = {
		"messages": [HumanMessage(content=req.notas_consulta)],
		"patient_id": str(req.paciente_id), "professional_id": token["sub"],
		"alert_signs": [], "physical_signs": [], "behavioral_signs": [],
		"risk_level": None, "immediate_danger": False, "children_at_risk": req.criancas_em_risco,
		"security_protocol_activated": False, "team_notified": [], "documentation_id": None,
		"followup_scheduled": False, "current_step": "start", "audit_log": [], "error": None,
	}
	result = await graph.ainvoke(state, config={"configurable": {"thread_id": f"vd-{uuid.uuid4().hex[:8]}"}})
	risco  = result.get("risk_level", ViolenceRisk.NONE)
	rv	 = risco.value if hasattr(risco, "value") else str(risco)
	aid	= None
	if rv != "NENHUM":
		aid = await persistir_alerta_vd(result, req.paciente_id, med_id)
	acoes  = {"NENHUM": "Sem sinais de alerta. Continuar acompanhamento de rotina.",
			   "BAIXO": "Acompanhamento psicológico sugerido. Reavaliar na próxima consulta.",
			   "MEDIO": "Equipe multidisciplinar notificada. Documentação registrada.",
			   "ALTO":  "🚨 PROTOCOLO DE EMERGÊNCIA ATIVADO. Equipe notificada imediatamente."}
	return {"id": aid, "nivel_risco": rv,
			"perigo_imediato": result.get("immediate_danger", False),
			"protocolo_ativado": result.get("security_protocol_activated", False),
			"equipe_notificada": result.get("team_notified", []),
			"id_documento": result.get("documentation_id"),
			"acao_requerida": acoes.get(rv, "")}

# ─── Fluxo 3: Obstétrico ─────────────────────────────────────────────────────
@app.post("/fluxos/obstetrico", tags=["Fluxos"])
async def executar_obstetrico(req: ObstetricoReq, token: dict = Depends(verificar_token)):
	pac = await PacienteRepo.buscar_por_id(req.paciente_id)
	if not pac: raise HTTPException(404, "Paciente não encontrada")
	med	= await MedicoRepo.buscar_por_crm(token["sub"])
	med_id = med.id if med else None
	vitals = {}
	if req.pa_sistolica:  vitals["systolic_bp"]  = req.pa_sistolica
	if req.pa_diastolica: vitals["diastolic_bp"] = req.pa_diastolica

	graph  = build_obstetric_graph()
	state: ObstetricState = {
		"messages": [], "patient_id": str(req.paciente_id),
		"gestational_age_weeks": req.ig_semanas, "gestational_age_days": req.ig_dias,
		"obstetric_history": req.historico_obstetrico, "comorbidities": req.comorbidades,
		"comorbidades": req.comorbidades, "current_vitals": vitals, "recent_exams": {},
		"fetal_wellbeing": None, "gestational_risk": None, "risk_factors": [],
		"trimester_guidance": None, "recommended_exams": [], "next_appointment": None,
		"urgent_alerts": [], "current_step": "start", "audit_log": [], "error": None,
	}
	result = await graph.ainvoke(state, config={"configurable": {"thread_id": f"ob-{uuid.uuid4().hex[:8]}"}})
	oid	= await persistir_obstetrico(result, req.paciente_id, med_id)
	risco  = result.get("gestational_risk")
	rv	 = risco.value if hasattr(risco, "value") else str(risco or "BAIXO")
	return {"id": oid, "risco_gestacional": rv,
			"fatores_risco": result.get("risk_factors", []),
			"orientacoes": result.get("trimester_guidance", ""),
			"exames_sugeridos": result.get("recommended_exams", []),
			"proxima_consulta": result.get("next_appointment", ""),
			"alertas_urgentes": result.get("urgent_alerts", [])}

# ─── Fluxo 4: Prevenção ──────────────────────────────────────────────────────
@app.post("/fluxos/prevencao", tags=["Fluxos"])
async def executar_prevencao(req: PrevencaoReq, token: dict = Depends(verificar_token)):
	pac = await PacienteRepo.buscar_por_id(req.paciente_id)
	if not pac: raise HTTPException(404, "Paciente não encontrada")
	last = {}
	if req.ultimo_papanicolau:	last["papanicolau"]	   = req.ultimo_papanicolau
	if req.ultima_mamografia:	 last["mamografia"]		= req.ultima_mamografia
	if req.ultima_densitometria:  last["densitometria_ossea"] = req.ultima_densitometria

	graph  = build_prevention_graph()
	state: PreventionState = {
		"messages": [], "patient_id": str(req.paciente_id),
		"age": req.idade, "last_exams": last,
		"family_history": req.historico_familiar, "comorbidities": req.comorbidades,
		"reproductive_history": {}, "overdue_exams": [], "upcoming_exams": [],
		"preventive_guidance": None, "scheduled_appointments": [],
		"reminders_set": False, "current_step": "start", "audit_log": [], "error": None,
	}
	result = await graph.ainvoke(state, config={"configurable": {"thread_id": f"pv-{uuid.uuid4().hex[:8]}"}})
	qtd	= await persistir_prevencao(result, req.paciente_id)
	return {"exames_vencidos": result.get("overdue_exams", []),
			"exames_proximos": result.get("upcoming_exams", []),
			"orientacoes": result.get("preventive_guidance", ""),
			"agendamentos_solicitados": qtd}

# ─── Dashboard ───────────────────────────────────────────────────────────────
@app.get("/dashboard", tags=["Dashboard"])
async def dashboard(token: dict = Depends(verificar_token)):
	from database.repositories import get_session
	from database.models import TriagemGinecologica, Paciente as PM
	from sqlalchemy import select
	total	= await PacienteRepo.total()
	consults = await ConsultaRepo.total_hoje()
	triagens = await TriagemRepo.total_hoje()
	vd	   = await AlertaViolenciaRepo.total_hoje()
	medicos  = [{"id": m.id, "nome": m.nome, "crm": m.crm,
				 "especialidade": m.especialidade.value}
				for m in await MedicoRepo.listar_todos()]
	async with get_session() as s:
		rows = await s.execute(
			select(TriagemGinecologica, PM.nome)
			.join(PM, PM.id == TriagemGinecologica.paciente_id)
			.order_by(TriagemGinecologica.criado_em.desc()).limit(8))
		ultimas = [{"id": t.id, "paciente": nome,
					"urgencia": t.urgencia.value if hasattr(t.urgencia,"value") else t.urgencia,
					"sintomas": (t.sintomas[:55]+"...") if len(t.sintomas)>55 else t.sintomas,
					"data": t.criado_em.strftime("%d/%m %H:%M")}
				   for t, nome in rows.all()]
	return {"total_pacientes": total, "consultas_hoje": consults,
			"triagens_hoje": triagens, "alertas_vd_hoje": vd,
			"medicos": medicos, "ultimas_triagens": ultimas}

@app.get("/historico/triagens/{pid}", tags=["Histórico"])
async def hist_triagens(pid: int, token: dict = Depends(verificar_token)):
	from database.repositories import get_session
	from database.models import TriagemGinecologica
	from sqlalchemy import select
	async with get_session() as s:
		rows = await s.execute(select(TriagemGinecologica)
							   .where(TriagemGinecologica.paciente_id == pid)
							   .order_by(TriagemGinecologica.criado_em.desc()))
	return [{"id": t.id, "urgencia": t.urgencia.value if hasattr(t.urgencia,"value") else t.urgencia,
			 "sintomas": t.sintomas, "red_flags": t.red_flags or [],
			 "exames": t.exames_sugeridos or [], "orientacao": t.orientacao_inicial,
			 "data": t.criado_em.strftime("%d/%m/%Y %H:%M")}
			for t in rows.scalars().all()]

@app.get("/historico/obstetrico/{pid}", tags=["Histórico"])
async def hist_obstetrico(pid: int, token: dict = Depends(verificar_token)):
	from database.repositories import get_session
	from database.models import AcompanhamentoObstetrico
	from sqlalchemy import select
	async with get_session() as s:
		rows = await s.execute(select(AcompanhamentoObstetrico)
							   .where(AcompanhamentoObstetrico.paciente_id == pid)
							   .order_by(AcompanhamentoObstetrico.criado_em.desc()))
	return [{"id": o.id, "ig": f"{o.ig_semanas}s{o.ig_dias}d",
			 "risco": o.risco_gestacional.value if hasattr(o.risco_gestacional,"value") else o.risco_gestacional,
			 "fatores": o.fatores_risco or [], "orientacoes": o.orientacoes_trimestre,
			 "alertas": o.alertas_urgentes or [], "data": o.criado_em.strftime("%d/%m/%Y %H:%M")}
			for o in rows.scalars().all()]

@app.get("/historico/exames/{pid}", tags=["Histórico"])
async def hist_exames(pid: int, token: dict = Depends(verificar_token)):
	return [{"id": e.id, "exame": e.nome_exame, "prioridade": e.prioridade,
			 "guideline": e.guideline_fonte, "agendado": e.agendamento_solicitado,
			 "data": e.criado_em.strftime("%d/%m/%Y")}
			for e in await ExamePreventivoRepo.listar_pendentes(pid)]

@app.get("/health", tags=["Sistema"])
async def health():
	return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

@app.get("/", include_in_schema=False)
async def frontend():
	f = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend.html")
	return FileResponse(f) if os.path.exists(f) else HTMLResponse("<h1>frontend.html não encontrado</h1>")

if __name__ == "__main__":
	uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)

class DuvidaProfissionalReq(BaseModel):
	pergunta: str = Field(..., min_length=10, description="Dúvida clínica do profissional")
	contexto_paciente: Optional[str] = Field(
		None,
		description="Contexto clínico anonimizado da paciente, se aplicável"
	)

@app.post("/profissional/duvida", tags=["Dúvidas Profissionais"])
async def responder_duvida_profissional(
	req: DuvidaProfissionalReq,
	token: dict = Depends(verificar_token),
):
	"""
	Responde dúvidas clínicas de profissionais de saúde especializados.

	Classifica a dúvida por categoria (ginecologia, obstetrícia, oncologia,
	violência doméstica, saúde mental, farmacologia, etc.) e complexidade,
	retorna resposta embasada em guidelines (FEBRASGO, INCA, MS, OMS, USPSTF)
	com referências e alertas clínicos relevantes.

	- **pergunta**: dúvida clínica em linguagem livre (mínimo 10 caracteres)
	- **contexto_paciente**: opcional — dados clínicos anonimizados para resposta mais precisa
	"""
	import uuid as _uuid
	question_id = _uuid.uuid4().hex[:12]

	graph = build_professional_qa_graph()
	initial_state: ProfessionalQAState = {
		"messages": [HumanMessage(content=req.pergunta)],
		"professional_id": token["sub"],
		"professional_role": token.get("role", "profissional_saude"),
		"question_id": question_id,
		"question_text": req.pergunta,
		"patient_context": req.contexto_paciente,
		"category": None,
		"complexity": None,
		"keywords": [],
		"clinical_context": None,
		"answer": None,
		"references": [],
		"caveats": [],
		"current_step": "start",
		"audit_log": [],
		"error": None,
	}

	result = await graph.ainvoke(
		initial_state,
		config={"configurable": {"thread_id": f"qa-{question_id}"}},
	)

	# Extrair a resposta da última AIMessage
	from langchain_core.messages import AIMessage as _AIMessage
	resposta_texto = ""
	for msg in reversed(result.get("messages", [])):
		if isinstance(msg, _AIMessage) and msg.content:
			resposta_texto = msg.content
			break

	# Fallback: qualquer mensagem que não seja a pergunta original
	if not resposta_texto:
		for msg in reversed(result.get("messages", [])):
			if hasattr(msg, "content") and msg.content and msg.content != req.pergunta:
				resposta_texto = msg.content
				break

	return {
		"question_id": question_id,
		"pergunta": req.pergunta,
		"categoria": result.get("category", "geral"),
		"complexidade": result.get("complexity", "simples"),
		"palavras_chave": result.get("keywords", []),
		"resposta": result.get("answer", ""),
		"referencias": result.get("references", []),
		"alertas": result.get("caveats", []),
		"resposta_completa": resposta_texto,
		"timestamp": datetime.utcnow().isoformat(),
	}


@app.get("/profissional/categorias", tags=["Dúvidas Profissionais"])
async def listar_categorias(token: dict = Depends(verificar_token)):
	"""
	Lista as categorias clínicas suportadas pelo módulo de dúvidas profissionais.
	"""
	return {
		"categorias": [
			{"id": "ginecologia",			  "descricao": "Ginecologia geral — endometriose, mioma, distúrbios menstruais, menopausa"},
			{"id": "obstetricia",			  "descricao": "Obstetrícia — pré-natal, complicações gestacionais, puerpério"},
			{"id": "oncologia",				"descricao": "Oncologia ginecológica — câncer de colo, mama, ovário"},
			{"id": "violencia_domestica",	  "descricao": "Violência doméstica e sexual — protocolo, notificação compulsória"},
			{"id": "saude_mental",			 "descricao": "Saúde mental da mulher — depressão, ansiedade, psicofármacos na gestação"},
			{"id": "preventivo_rastreamento",  "descricao": "Prevenção e rastreamento — papanicolau, mamografia, densitometria"},
			{"id": "farmacologia",			 "descricao": "Farmacologia — anticoncepção, medicamentos na gestação e lactação"},
			{"id": "procedimentos",			"descricao": "Procedimentos ginecológico-obstétricos — indicações, contraindicações"},
			{"id": "geral",					"descricao": "Saúde da mulher — perguntas gerais não classificadas acima"},
		],
		"instrucoes": (
			"Envie sua dúvida via POST /profissional/duvida. "
			"Para respostas mais precisas em casos clínicos, inclua o campo 'contexto_paciente' "
			"com dados anonimizados (sem nome, CPF ou informações identificáveis)."
		),
	}

# ─── Módulo: Tratamentos Reprodutivos ────────────────────────────────────────
from langgraph_flows.advanced_flows import (
	build_reproductive_treatment_graph, ReproductiveTreatmentState,
	build_vd_alert_graph, VDAlertState,
	build_multidisciplinary_graph, MultidisciplinaryState,
)

class TratamentoReprodutivoReq(BaseModel):
	paciente_id: int
	idade: int = Field(..., ge=12, le=90)
	queixa_principal: str = Field(..., min_length=5)
	desejo_gestar: bool = False
	contraindicacao_hormonal: bool = False
	anticoncepcao_atual: Optional[str] = None
	comorbidades: list[str] = []
	tratamentos_anteriores: list[str] = []

@app.post("/fluxos/tratamento-reprodutivo", tags=["Módulos Avançados"])
async def sugerir_tratamento_reprodutivo(
	req: TratamentoReprodutivoReq,
	token: dict = Depends(verificar_token),
):
	"""
	Sugere tratamentos para questões reprodutivas com abordagem trauma-informed.
	Cobre SOP, endometriose, miomatose, infertilidade, menopausa,
	distúrbios menstruais e abortamento recorrente.
	"""
	qid = uuid.uuid4().hex[:12]
	graph = build_reproductive_treatment_graph()
	initial: ReproductiveTreatmentState = {
		"messages": [HumanMessage(content=req.queixa_principal)],
		"patient_id": str(req.paciente_id),
		"age": req.idade,
		"main_complaint": req.queixa_principal,
		"condition": None,
		"wants_to_conceive": req.desejo_gestar,
		"current_contraception": req.anticoncepcao_atual,
		"comorbidities": req.comorbidades,
		"previous_treatments": req.tratamentos_anteriores,
		"hormone_contraindication": req.contraindicacao_hormonal,
		"treatment_line": None,
		"treatment_plan": None,
		"non_pharmacological": [],
		"followup_plan": None,
		"referrals": [],
		"sensitivity_notes": [],
		"current_step": "start",
		"audit_log": [],
		"error": None,
	}
	result = await graph.ainvoke(initial, config={"configurable": {"thread_id": f"repr-{qid}"}})

	from langchain_core.messages import AIMessage as _AI
	resposta = next((m.content for m in reversed(result.get("messages", [])) if isinstance(m, _AI) and m.content), "")

	return {
		"condicao_identificada": result.get("condition", "geral"),
		"linha_tratamento": result.get("treatment_line", "primeira_linha"),
		"plano_tratamento": result.get("treatment_plan", ""),
		"nao_farmacologico": result.get("non_pharmacological", []),
		"followup": result.get("followup_plan", ""),
		"encaminhamentos": result.get("referrals", []),
		"notas_sensibilidade": result.get("sensitivity_notes", []),
		"resposta_completa": resposta,
		"timestamp": datetime.utcnow().isoformat(),
	}


# ─── Módulo: Alerta VD Aprofundado ───────────────────────────────────────────

class AlertaVDReq(BaseModel):
	paciente_id: int
	notas_consulta: str = Field(..., min_length=10)
	criancas_envolvidas: bool = False

@app.post("/fluxos/alerta-vd", tags=["Módulos Avançados"])
async def emitir_alerta_vd(
	req: AlertaVDReq,
	token: dict = Depends(verificar_token),
):
	"""
	Emite alerta estruturado para casos suspeitos de violência doméstica.
	Detecta sinais físicos, comportamentais e contextuais, calcula nível
	de risco (CRÍTICO / ALTO / MODERADO / VIGILÂNCIA) e gera protocolo
	completo com conduta clínica, obrigações legais e plano de segurança.
	"""
	qid = uuid.uuid4().hex[:12]
	graph = build_vd_alert_graph()
	initial: VDAlertState = {
		"messages": [HumanMessage(content=req.notas_consulta)],
		"patient_id": str(req.paciente_id),
		"professional_id": token["sub"],
		"consultation_notes": req.notas_consulta,
		"physical_signs": [],
		"behavioral_signs": [],
		"contextual_signs": [],
		"alert_level": None,
		"immediate_risk": False,
		"children_involved": req.criancas_envolvidas,
		"elder_involved": False,
		"sinan_required": False,
		"immediate_actions": [],
		"clinical_conduct": [],
		"legal_obligations": [],
		"safety_plan": [],
		"support_resources": [],
		"trauma_informed_approach": [],
		"documentation_id": None,
		"alert_message": None,
		"current_step": "start",
		"audit_log": [],
		"error": None,
	}
	result = await graph.ainvoke(initial, config={"configurable": {"thread_id": f"vda-{qid}"}})

	from langchain_core.messages import AIMessage as _AI
	alerta_msg = next((m.content for m in reversed(result.get("messages", [])) if isinstance(m, _AI) and m.content), "")

	return {
		"nivel_alerta": result.get("alert_level", "VIGILÂNCIA"),
		"risco_imediato": result.get("immediate_risk", False),
		"sinan_obrigatorio": result.get("sinan_required", False),
		"criancas_envolvidas": result.get("children_involved", False),
		"sinais_fisicos": result.get("physical_signs", []),
		"sinais_comportamentais": result.get("behavioral_signs", []),
		"sinais_contextuais": result.get("contextual_signs", []),
		"acoes_imediatas": result.get("immediate_actions", []),
		"conduta_clinica": result.get("clinical_conduct", []),
		"obrigacoes_legais": result.get("legal_obligations", []),
		"plano_seguranca": result.get("safety_plan", []),
		"recursos_apoio": result.get("support_resources", []),
		"abordagem_trauma": result.get("trauma_informed_approach", []),
		"id_documentacao": result.get("documentation_id", ""),
		"mensagem_alerta": alerta_msg,
		"timestamp": datetime.utcnow().isoformat(),
	}


# ─── Módulo: Coordenação Multidisciplinar ────────────────────────────────────

class CoordMultidisciplinarReq(BaseModel):
	paciente_id: int
	tipo_caso: str = Field(..., description="vd | reproductive | infertility | mental_health | obstetric")
	resumo_caso: str = Field(..., min_length=10)
	urgencia: str = Field(default="eletivo", description="imediata | 24h | 72h | eletivo")
	nivel_alerta: Optional[str] = None

@app.post("/fluxos/coordenacao-multidisciplinar", tags=["Módulos Avançados"])
async def coordenar_equipe_multidisciplinar(
	req: CoordMultidisciplinarReq,
	token: dict = Depends(verificar_token),
):
	"""
	Coordena atendimento multidisciplinar entre Ginecologista, Psicóloga
	e Assistente Social. Gera plano integrado com atribuições, prazos,
	cronograma de seguimento e protocolo de comunicação segura.
	"""
	qid = uuid.uuid4().hex[:12]
	graph = build_multidisciplinary_graph()
	initial: MultidisciplinaryState = {
		"messages": [HumanMessage(content=req.resumo_caso)],
		"patient_id": str(req.paciente_id),
		"case_type": req.tipo_caso,
		"case_summary": req.resumo_caso,
		"urgency": req.urgencia,
		"alert_level": req.nivel_alerta,
		"required_roles": [],
		"team_assignments": [],
		"coordination_plan": None,
		"communication_protocol": [],
		"followup_schedule": [],
		"case_sensitivities": [],
		"current_step": "start",
		"audit_log": [],
		"error": None,
	}
	result = await graph.ainvoke(initial, config={"configurable": {"thread_id": f"multi-{qid}"}})

	from langchain_core.messages import AIMessage as _AI
	plano_msg = next((m.content for m in reversed(result.get("messages", [])) if isinstance(m, _AI) and m.content), "")

	return {
		"tipo_caso": req.tipo_caso,
		"urgencia": req.urgencia,
		"equipe_necessaria": result.get("required_roles", []),
		"atribuicoes": result.get("team_assignments", []),
		"cronograma_followup": result.get("followup_schedule", []),
		"protocolo_comunicacao": result.get("communication_protocol", []),
		"sensibilidades": result.get("case_sensitivities", []),
		"plano_completo": plano_msg,
		"timestamp": datetime.utcnow().isoformat(),
	}

# ─── Fluxo Unificado de Intake ────────────────────────────────────────────────
from langgraph_flows.unified_intake import build_unified_intake_graph, IntakeState

class IntakeReq(BaseModel):
	paciente_id: int
	idade: int = Field(..., ge=12, le=90)
	notas_consulta: str = Field(default="", description="Notas livres da consulta atual")
	queixa_reprodutiva: str = Field(default="", description="Queixa reprodutiva em texto livre")
	desejo_gestar: bool = False
	contraindicacao_hormonal: bool = False
	comorbidades: list[str] = []
	tratamentos_anteriores: list[str] = []
	criancas_no_domicilio: bool = False
	ultimo_papanicolau: Optional[str] = None
	ultima_mamografia: Optional[str] = None
	ultima_densitometria: Optional[str] = None
	ultimo_hiv: Optional[str] = None
	ultima_hepatite_b: Optional[str] = None
	historico_familiar: list[str] = []

@app.post("/fluxos/intake-unificado", tags=["Intake Unificado"])
async def executar_intake_unificado(
	req: IntakeReq,
	token: dict = Depends(verificar_token),
):
	"""
	Fluxo mestre de intake — percorre automaticamente 5 etapas em sequência:

	**Etapa 1** — Verifica exames ginecológicos preventivos pendentes

	**Etapa 2** — Avalia queixa reprodutiva e sugere tratamento de 1ª linha

	**Etapa 3** — Analisa notas em busca de sinais de violência doméstica

	**Etapa 4** — Monta plano multidisciplinar (se VD detectada ou caso complexo)

	**Etapa 5** — Compila sumário clínico completo para o prontuário

	Etapas 3 e 4 são condicionais — só executadas quando necessário.
	"""
	intake_id = uuid.uuid4().hex[:12]
	graph = build_unified_intake_graph()

	# Buscar nome da paciente para exibição
	pac = await get_patient(req.paciente_id, token)
	patient_name = pac.get("nome", f"Paciente #{req.paciente_id}") if pac else f"Paciente #{req.paciente_id}"

	initial: IntakeState = {
		"messages": [HumanMessage(content=req.notas_consulta or req.queixa_reprodutiva or "Intake iniciado")],
		"patient_id": str(req.paciente_id),
		"professional_id": token["sub"],
		"intake_id": intake_id,
		"patient_name": patient_name,
		"age": req.idade,
		"consultation_notes": req.notas_consulta,
		"reproductive_complaint": req.queixa_reprodutiva,
		"wants_to_conceive": req.desejo_gestar,
		"hormone_contraindication": req.contraindicacao_hormonal,
		"comorbidities": req.comorbidades,
		"previous_treatments": req.tratamentos_anteriores,
		"children_in_household": req.criancas_no_domicilio,
		"last_papanicolau": req.ultimo_papanicolau,
		"last_mammography": req.ultima_mamografia,
		"last_bone_density": req.ultima_densitometria,
		"last_hiv_test": req.ultimo_hiv,
		"last_hepatitis_b": req.ultima_hepatite_b,
		"family_history": req.historico_familiar,
		# Saídas iniciais vazias
		"pending_exams": [], "exam_summary": None,
		"reproductive_condition": None, "treatment_suggestion": None,
		"non_pharmacological": [], "referrals": [], "sensitivity_notes": [],
		"vd_detected": False, "vd_alert_level": None,
		"vd_physical_signs": [], "vd_behavioral_signs": [], "vd_contextual_signs": [],
		"vd_immediate_actions": [], "vd_legal_obligations": [], "vd_safety_plan": [],
		"vd_documentation_id": None, "sinan_required": False,
		"team_required": False, "team_assignments": [], "followup_schedule": [],
		"coordination_plan": None, "clinical_summary": None,
		"overall_urgency": "ELETIVO", "alerts_count": 0,
		"current_step": "start", "completed_steps": [], "audit_log": [], "error": None,
	}

	result = await graph.ainvoke(initial, config={"configurable": {"thread_id": f"intake-{intake_id}"}})

	return {
		"intake_id": intake_id,
		"urgencia_geral": result.get("overall_urgency", "ELETIVO"),
		"alertas_count": result.get("alerts_count", 0),
		"etapas_concluidas": result.get("completed_steps", []),
		# Etapa 1
		"exames_pendentes": result.get("pending_exams", []),
		"resumo_exames": result.get("exam_summary", ""),
		# Etapa 2
		"condicao_reprodutiva": result.get("reproductive_condition", ""),
		"sugestao_tratamento": result.get("treatment_suggestion", ""),
		"nao_farmacologico": result.get("non_pharmacological", []),
		"encaminhamentos": result.get("referrals", []),
		"notas_sensibilidade": result.get("sensitivity_notes", []),
		# Etapa 3
		"vd_detectada": result.get("vd_detected", False),
		"vd_nivel": result.get("vd_alert_level"),
		"vd_acoes_imediatas": result.get("vd_immediate_actions", []),
		"vd_obrigacoes_legais": result.get("vd_legal_obligations", []),
		"vd_plano_seguranca": result.get("vd_safety_plan", []),
		"sinan_obrigatorio": result.get("sinan_required", False),
		"vd_doc_id": result.get("vd_documentation_id"),
		# Etapa 4
		"equipe_acionada": result.get("team_required", False),
		"atribuicoes_equipe": result.get("team_assignments", []),
		"cronograma_followup": result.get("followup_schedule", []),
		"plano_coordenacao": result.get("coordination_plan", ""),
		# Etapa 5
		"sumario_clinico": result.get("clinical_summary", ""),
		"timestamp": datetime.utcnow().isoformat(),
	}

async def get_patient(pid: int, token: dict) -> dict:
	"""Helper para buscar dados da paciente."""
	try:
		from database.repositories import get_patient_by_id
		from database.integrations import get_db_session
		async with get_db_session() as db:
			p = await get_patient_by_id(db, pid)
			return {"nome": p.nome} if p else {}
	except Exception:
		return {}

# ─── Entrega 2: Assistente RAG ────────────────────────────────────────────────
from langchain_rag.rag_pipeline import get_rag_pipeline
from security.validator_explainability import (
	get_validator, get_explainer, get_auditor, get_security_guard,
)

class RAGQueryReq(BaseModel):
	paciente_id: int
	query: str = Field(..., min_length=5, description="Pergunta ou situação clínica")
	dados_paciente: dict = Field(default_factory=dict, description="Dados clínicos da paciente")

@app.post("/assistente/consulta", tags=["Assistente RAG"])
async def consulta_assistente_rag(
	req: RAGQueryReq,
	token: dict = Depends(verificar_token),
):
	"""
	Entrega 2 — Assistente médico especializado com LangChain RAG.

	Pipeline: query → recuperação de protocolos → contextualização com dados da paciente
	→ validação de segurança → explainability → resposta com fonte e nível de confiança.
	"""
	pipeline   = get_rag_pipeline()
	validator  = get_validator()
	explainer  = get_explainer()
	auditor	= get_auditor()
	guard	  = get_security_guard()

	# 1. Avaliar risco de crise antes de processar
	crisis = guard.assess_crisis_risk(req.query)

	# 2. Executar pipeline RAG
	rag_result = await pipeline.query(
		query=req.query,
		patient_data=req.dados_paciente,
		professional_role=token.get("role", "profissional_saude"),
	)

	# 3. Validar resposta (guardrails NUNCA/SEMPRE)
	val_result = validator.validate(
		response=rag_result.get("response", ""),
		query=req.query,
	)

	# 4. Gerar explainability
	exp_report = explainer.generate_report(
		query=req.query,
		rag_result=rag_result,
		validation_result=val_result,
	)

	# 5. Persistir auditoria no banco
	audit_id = await auditor.log_rag_query(
		professional_id=token["sub"],
		patient_id=str(req.paciente_id),
		query=req.query,
		rag_result=rag_result,
		validation_result=val_result,
		explainability=explainer.format_for_api(exp_report),
	)

	return {
		"resposta": val_result.modified_response,
		"resposta_validada": val_result.is_safe,
		"violacoes_corrigidas": val_result.violations,
		"avisos": val_result.warnings,
		"explainability": explainer.format_for_api(exp_report),
		"risco_crise": crisis,
		"audit_id": audit_id,
		"timestamp": datetime.utcnow().isoformat(),
	}

@app.get("/assistente/alertas-preventivos/{paciente_id}", tags=["Assistente RAG"])
async def alertas_exames_preventivos(
	paciente_id: int,
	idade: int,
	token: dict = Depends(verificar_token),
):
	"""
	Entrega 2 — Alertas automáticos para exames preventivos em atraso.
	"""
	pipeline = get_rag_pipeline()
	auditor  = get_auditor()

	# Em produção: buscar dados reais do banco
	patient_data = {"idade": idade, "exames_preventivos": {}}
	alerts = pipeline.get_preventive_alerts(patient_data)

	await auditor.log_data_access(
		professional_id=token["sub"],
		patient_id=str(paciente_id),
		data_type="preventive_exams",
		reason="alertas_automaticos",
	)

	return {
		"paciente_id": paciente_id,
		"alertas": alerts,
		"total": len(alerts),
		"timestamp": datetime.utcnow().isoformat(),
	}


# ─── Entrega 4: Auditoria e Segurança ────────────────────────────────────────

class AcessoDadosReq(BaseModel):
	paciente_id: int
	tipo_dado: str = Field(..., description="vd_records | mental_health | reproductive_history")
	motivo: str

@app.post("/seguranca/verificar-acesso", tags=["Segurança"])
async def verificar_acesso_dado_sensivel(
	req: AcessoDadosReq,
	token: dict = Depends(verificar_token),
):
	"""
	Entrega 4 — Verificação de identidade para acesso a dados sensíveis.
	Valida se a especialidade do profissional tem permissão para o tipo de dado.
	"""
	guard   = get_security_guard()
	auditor = get_auditor()

	result = guard.verify_sensitive_access(
		professional_id=token["sub"],
		professional_role=token.get("role", ""),
		data_type=req.tipo_dado,
	)

	await auditor.log_data_access(
		professional_id=token["sub"],
		patient_id=str(req.paciente_id),
		data_type=req.tipo_dado,
		reason=req.motivo,
	)

	if not result["authorized"]:
		raise HTTPException(status_code=403, detail=result["reason"])

	return result

@app.get("/seguranca/auditoria/{paciente_id}", tags=["Segurança"])
async def listar_auditoria_paciente(
	paciente_id: int,
	token: dict = Depends(verificar_token),
):
	"""
	Entrega 4 — Rastreamento de todas as interações com os dados da paciente.
	Acesso restrito ao médico responsável.
	"""
	from database.repositories import LogAuditoriaRepo
	import hashlib as _h

	auditor = get_auditor()
	pac_hash = _h.sha256(f"audit-salt-{paciente_id}".encode()).hexdigest()[:32]

	await auditor.log_data_access(
		professional_id=token["sub"],
		patient_id=str(paciente_id),
		data_type="audit_logs",
		reason="consulta_auditoria",
	)

	logs = await LogAuditoriaRepo.listar_por_paciente(pac_hash)
	return {
		"paciente_hash": pac_hash,
		"total_registros": len(logs),
		"logs": [
			{
				"uuid": l.audit_uuid,
				"timestamp": l.timestamp.isoformat() if l.timestamp else None,
				"evento": l.tipo_evento,
				"dominio": l.dominio,
				"acao": l.acao,
				"classificacao": l.classificacao,
				"sensivel": l.sensivel,
			}
			for l in logs
		],
	}

class DatasetExportReq(BaseModel):
	output_dir: str = Field(default="finetuning/data")

@app.post("/finetuning/exportar-dataset", tags=["Fine-Tuning"])
async def exportar_dataset_finetuning(
	req: DatasetExportReq,
	token: dict = Depends(verificar_token),
):
	"""
	Entrega 1 — Exporta o dataset curado para fine-tuning (formato Alpaca + ChatML).
	Inclui preprocessamento, anonimização e divisão train/val/test.
	"""
	from finetuning.dataset_curadoria import DatasetCurator
	auditor = get_auditor()

	curator = DatasetCurator()
	manifest = curator.build_and_export(output_dir=req.output_dir)

	await auditor.log_interaction(
		professional_id=token["sub"],
		patient_id="system",
		action="dataset_export",
		domain="finetuning",
		details=manifest,
		is_sensitive=False,
		classification="admin",
	)

	return manifest