"""
Modelos SQLAlchemy — Hospital Santa Clara
Tabelas para todas as entidades do sistema clínico LangGraph.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, ForeignKey,
    Integer, JSON, String, Text, create_engine, text,
)
from sqlalchemy.orm import DeclarativeBase, relationship

# ---------------------------------------------------------------------------
# Base e engine
# ---------------------------------------------------------------------------

class Base(DeclarativeBase):
    pass


def get_engine(db_url: str = "sqlite:///./hospital_santa_clara.db"):
    return create_engine(db_url, echo=False, future=True)


def criar_todas_tabelas(engine):
    Base.metadata.create_all(engine)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class EspecialidadeEnum(str, PyEnum):
    GINECOLOGIA       = "ginecologia"
    OBSTETRICIA       = "obstetricia"
    PSICOLOGIA        = "psicologia"
    SERVICO_SOCIAL    = "servico_social"
    ENFERMAGEM        = "enfermagem"
    RADIOLOGIA        = "radiologia"
    ONCOLOGIA         = "oncologia"

class UrgenciaEnum(str, PyEnum):
    EMERGENCIA = "EMERGENCIA"
    URGENCIA   = "URGENCIA"
    PRIORITARIO = "PRIORITARIO"
    ELETIVO    = "ELETIVO"

class RiscoVDEnum(str, PyEnum):
    ALTO   = "ALTO"
    MEDIO  = "MEDIO"
    BAIXO  = "BAIXO"
    NENHUM = "NENHUM"

class RiscoGestacionalEnum(str, PyEnum):
    ALTO     = "ALTO"
    HABITUAL = "HABITUAL"
    BAIXO    = "BAIXO"

class StatusConsultaEnum(str, PyEnum):
    AGENDADA   = "agendada"
    REALIZADA  = "realizada"
    CANCELADA  = "cancelada"
    URGENCIA   = "urgencia"


# ---------------------------------------------------------------------------
# Hospital
# ---------------------------------------------------------------------------

class Hospital(Base):
    __tablename__ = "hospitais"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    nome       = Column(String(120), nullable=False)
    cnpj       = Column(String(18), unique=True)
    endereco   = Column(String(255))
    telefone   = Column(String(20))
    email      = Column(String(100))
    criado_em  = Column(DateTime, default=datetime.utcnow)

    medicos    = relationship("Medico",   back_populates="hospital")
    pacientes  = relationship("Paciente", back_populates="hospital")

    def __repr__(self):
        return f"<Hospital {self.nome}>"


# ---------------------------------------------------------------------------
# Médico / Profissional
# ---------------------------------------------------------------------------

class Medico(Base):
    __tablename__ = "medicos"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    hospital_id   = Column(Integer, ForeignKey("hospitais.id"), nullable=False)
    nome          = Column(String(120), nullable=False)
    crm           = Column(String(20), unique=True, nullable=False)
    especialidade = Column(Enum(EspecialidadeEnum), nullable=False)
    email         = Column(String(100))
    telefone      = Column(String(20))
    ativo         = Column(Boolean, default=True)
    criado_em     = Column(DateTime, default=datetime.utcnow)

    hospital      = relationship("Hospital",    back_populates="medicos")
    consultas     = relationship("Consulta",    back_populates="medico")
    triagens      = relationship("TriagemGinecologica", back_populates="medico")
    alertas_vd    = relationship("AlertaViolencia",     back_populates="medico_responsavel")
    acomp_obs     = relationship("AcompanhamentoObstetrico", back_populates="medico")

    def __repr__(self):
        return f"<Medico {self.nome} — {self.crm}>"


# ---------------------------------------------------------------------------
# Paciente
# ---------------------------------------------------------------------------

class Paciente(Base):
    __tablename__ = "pacientes"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    hospital_id     = Column(Integer, ForeignKey("hospitais.id"), nullable=False)
    nome            = Column(String(120), nullable=False)
    cpf_hash        = Column(String(64), unique=True)          # nunca armazena CPF puro
    data_nascimento = Column(DateTime)
    telefone        = Column(String(20))
    email           = Column(String(100))
    endereco        = Column(String(255))
    convenio        = Column(String(80))
    # histórico clínico resumido
    comorbidades    = Column(JSON, default=list)
    historico_familiar = Column(JSON, default=list)
    criado_em       = Column(DateTime, default=datetime.utcnow)
    atualizado_em   = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    hospital        = relationship("Hospital",   back_populates="pacientes")
    consultas       = relationship("Consulta",   back_populates="paciente")
    triagens        = relationship("TriagemGinecologica",      back_populates="paciente")
    alertas_vd      = relationship("AlertaViolencia",          back_populates="paciente")
    acomp_obs       = relationship("AcompanhamentoObstetrico", back_populates="paciente")
    exames_prev     = relationship("ExamePreventivo",          back_populates="paciente")
    prontuarios     = relationship("Prontuario",               back_populates="paciente")

    def __repr__(self):
        return f"<Paciente {self.nome}>"


# ---------------------------------------------------------------------------
# Prontuário
# ---------------------------------------------------------------------------

class Prontuario(Base):
    __tablename__ = "prontuarios"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    paciente_id = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    numero      = Column(String(20), unique=True, nullable=False)
    criado_em   = Column(DateTime, default=datetime.utcnow)
    observacoes = Column(Text)

    paciente    = relationship("Paciente", back_populates="prontuarios")
    consultas   = relationship("Consulta", back_populates="prontuario")

    def __repr__(self):
        return f"<Prontuário {self.numero}>"


# ---------------------------------------------------------------------------
# Consulta
# ---------------------------------------------------------------------------

class Consulta(Base):
    __tablename__ = "consultas"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    prontuario_id  = Column(Integer, ForeignKey("prontuarios.id"))
    paciente_id    = Column(Integer, ForeignKey("pacientes.id"),  nullable=False)
    medico_id      = Column(Integer, ForeignKey("medicos.id"),    nullable=False)
    data_hora      = Column(DateTime, default=datetime.utcnow)
    especialidade  = Column(Enum(EspecialidadeEnum))
    status         = Column(Enum(StatusConsultaEnum), default=StatusConsultaEnum.AGENDADA)
    queixa_principal = Column(Text)
    anamnese       = Column(Text)
    conduta        = Column(Text)
    prescricao     = Column(Text)           # somente registros; prescrição real feita pelo médico
    audit_id       = Column(String(36))     # vínculo com AuditLogger
    criado_em      = Column(DateTime, default=datetime.utcnow)

    paciente       = relationship("Paciente",   back_populates="consultas")
    medico         = relationship("Medico",     back_populates="consultas")
    prontuario     = relationship("Prontuario", back_populates="consultas")

    def __repr__(self):
        return f"<Consulta {self.id} — {self.paciente_id}>"


# ---------------------------------------------------------------------------
# Triagem Ginecológica (Fluxo 1)
# ---------------------------------------------------------------------------

class TriagemGinecologica(Base):
    __tablename__ = "triagens_ginecologicas"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    paciente_id         = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    medico_id           = Column(Integer, ForeignKey("medicos.id"))
    sintomas            = Column(Text, nullable=False)
    duracao             = Column(String(80))
    sintomas_associados = Column(JSON, default=list)
    historico_relevante = Column(Text)
    # resultados do fluxo LangGraph
    urgencia            = Column(Enum(UrgenciaEnum))
    red_flags           = Column(JSON, default=list)
    exames_sugeridos    = Column(JSON, default=list)
    orientacao_inicial  = Column(Text)
    tipo_agendamento    = Column(String(80))
    audit_log           = Column(JSON, default=list)
    criado_em           = Column(DateTime, default=datetime.utcnow)

    paciente            = relationship("Paciente", back_populates="triagens")
    medico              = relationship("Medico",   back_populates="triagens")

    def __repr__(self):
        return f"<Triagem {self.id} — urgência: {self.urgencia}>"


# ---------------------------------------------------------------------------
# Alerta de Violência Doméstica (Fluxo 2) — dados encriptados na app
# ---------------------------------------------------------------------------

class AlertaViolencia(Base):
    __tablename__ = "alertas_violencia"

    id                          = Column(Integer, primary_key=True, autoincrement=True)
    paciente_id                 = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    medico_responsavel_id       = Column(Integer, ForeignKey("medicos.id"),   nullable=False)
    # todos os campos abaixo chegam já encriptados pelo SecurityModule
    sinais_fisicos_enc          = Column(Text)
    sinais_comportamentais_enc  = Column(Text)
    nivel_risco                 = Column(Enum(RiscoVDEnum))
    perigo_imediato             = Column(Boolean, default=False)
    criancas_em_risco           = Column(Boolean, default=False)
    protocolo_ativado           = Column(Boolean, default=False)
    equipe_notificada           = Column(JSON, default=list)
    id_documento_seguro         = Column(String(20), unique=True)
    seguimento_agendado         = Column(Boolean, default=False)
    audit_log_enc               = Column(Text)    # log encriptado
    criado_em                   = Column(DateTime, default=datetime.utcnow)

    paciente              = relationship("Paciente", back_populates="alertas_vd")
    medico_responsavel    = relationship("Medico",   back_populates="alertas_vd")

    def __repr__(self):
        return f"<AlertaVD {self.id} — risco: {self.nivel_risco}>"


# ---------------------------------------------------------------------------
# Acompanhamento Obstétrico (Fluxo 3)
# ---------------------------------------------------------------------------

class AcompanhamentoObstetrico(Base):
    __tablename__ = "acompanhamentos_obstetricos"

    id                      = Column(Integer, primary_key=True, autoincrement=True)
    paciente_id             = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    medico_id               = Column(Integer, ForeignKey("medicos.id"))
    ig_semanas              = Column(Integer)
    ig_dias                 = Column(Integer, default=0)
    historico_obstetrico    = Column(String(20))          # ex: G2P1A0
    comorbidades            = Column(JSON, default=list)
    sinais_vitais           = Column(JSON, default=dict)
    exames_recentes         = Column(JSON, default=dict)
    risco_gestacional       = Column(Enum(RiscoGestacionalEnum))
    fatores_risco           = Column(JSON, default=list)
    orientacoes_trimestre   = Column(Text)
    exames_sugeridos        = Column(JSON, default=list)
    proxima_consulta        = Column(String(80))
    alertas_urgentes        = Column(JSON, default=list)
    audit_log               = Column(JSON, default=list)
    criado_em               = Column(DateTime, default=datetime.utcnow)

    paciente                = relationship("Paciente", back_populates="acomp_obs")
    medico                  = relationship("Medico",   back_populates="acomp_obs")

    def __repr__(self):
        return f"<AcompObs {self.id} — IG {self.ig_semanas}sem — risco {self.risco_gestacional}>"


# ---------------------------------------------------------------------------
# Exame Preventivo (Fluxo 4)
# ---------------------------------------------------------------------------

class ExamePreventivo(Base):
    __tablename__ = "exames_preventivos"

    id                      = Column(Integer, primary_key=True, autoincrement=True)
    paciente_id             = Column(Integer, ForeignKey("pacientes.id"), nullable=False)
    nome_exame              = Column(String(80), nullable=False)
    data_realizacao         = Column(DateTime)
    data_vencimento         = Column(DateTime)
    prioridade              = Column(String(10))        # alta / média / baixa
    guideline_fonte         = Column(String(120))
    resultado               = Column(Text)
    lembrete_enviado        = Column(Boolean, default=False)
    agendamento_solicitado  = Column(Boolean, default=False)
    criado_em               = Column(DateTime, default=datetime.utcnow)

    paciente                = relationship("Paciente", back_populates="exames_prev")

    def __repr__(self):
        return f"<ExamePrev {self.nome_exame} — pac {self.paciente_id}>"


# ---------------------------------------------------------------------------
# Log de Auditoria (espelho relacional do AuditLogger)
# ---------------------------------------------------------------------------

class LogAuditoria(Base):
    __tablename__ = "logs_auditoria"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    audit_uuid       = Column(String(36), unique=True, nullable=False)
    timestamp        = Column(DateTime, default=datetime.utcnow)
    tipo_evento      = Column(String(40))     # consultation / violence_alert / data_access / ...
    profissional_id  = Column(String(40))
    paciente_hash    = Column(String(64))
    dominio          = Column(String(40))
    acao             = Column(String(40))
    classificacao    = Column(String(20))
    detalhes_json    = Column(JSON, default=dict)
    sensivel         = Column(Boolean, default=False)  # se True, detalhes estão encriptados

    def __repr__(self):
        return f"<Log {self.tipo_evento} — {self.timestamp}>"
