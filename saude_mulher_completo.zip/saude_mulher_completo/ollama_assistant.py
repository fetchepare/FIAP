"""
ollama_assistant.py — Integração com Ollama (LLM local)
Hospital Santa Clara · Saúde da Mulher

Requer: pip install langchain-ollama

E o Ollama rodando localmente:
    ollama serve
    ollama pull llama3

Variáveis de ambiente opcionais:

    OLLAMA_BASE_URL  →  padrão: http://localhost:11434
    OLLAMA_MODEL     →  padrão: llama3
"""
from __future__ import annotations

import logging
import os
from typing import Optional

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)

# ─── Configuração ─────────────────────────────────────────────────────────────

OLLAMA_BASE_URL: str = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
#OLLAMA_MODEL:    str = os.environ.get("OLLAMA_MODEL", "llama3")
OLLAMA_MODEL: str = os.environ.get("OLLAMA_MODEL", "gemma2:2b")

SYSTEM_PROMPT = """Você é um assistente clínico especializado em saúde da mulher,
integrado ao sistema do Hospital Santa Clara. Seu papel é apoiar profissionais de saúde
com informações baseadas em evidências sobre ginecologia, obstetrícia, oncologia
ginecológica, saúde mental da mulher e prevenção.

Diretrizes:
- Responda sempre em português do Brasil.
- Seja objetivo e clinicamente preciso.
- Não faça diagnósticos definitivos; ofereça orientações baseadas em guidelines.
- Em casos de risco de vida, indique protocolo de emergência.
- Preserve a privacidade da paciente — nunca solicite dados identificadores.
- Ao final de respostas complexas, indique fontes ou guidelines relevantes (FEBRASGO,
  CFM, MS, WHO, ACOG) quando pertinente.
"""


# ─── Cliente singleton ────────────────────────────────────────────────────────

_llm: Optional[ChatOllama] = None


def get_ollama_llm() -> ChatOllama:
    """Retorna instância singleton do ChatOllama."""
    global _llm
    if _llm is None:
        _llm = ChatOllama(
            base_url=OLLAMA_BASE_URL,
            model=OLLAMA_MODEL,
            temperature=0.3,       # respostas mais determinísticas para uso clínico
            num_predict=1024,      # máximo de tokens na resposta
        )
        logger.info("Ollama inicializado: %s / modelo: %s", OLLAMA_BASE_URL, OLLAMA_MODEL)
    return _llm


# ─── Função principal ─────────────────────────────────────────────────────────

async def consultar_ollama(
    pergunta: str,
    contexto_paciente: Optional[str] = None,
    role_profissional: str = "profissional_saude",
) -> dict:
    """
    Envia uma pergunta clínica ao Ollama e retorna a resposta estruturada.

    Args:
        pergunta:           Dúvida ou situação clínica em texto livre.
        contexto_paciente:  Dados anonimizados da paciente (opcional).
        role_profissional:  Especialidade do profissional logado.

    Returns:
        dict com 'resposta', 'modelo' e 'tokens_usados'.
    """
    llm = get_ollama_llm()

    # Monta o prompt com contexto opcional
    user_content = pergunta
    if contexto_paciente:
        user_content = (
            f"Contexto clínico (anonimizado):\n{contexto_paciente}\n\n"
            f"Pergunta:\n{pergunta}"
        )

    messages = [
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(content=user_content),
    ]

    try:
        response = await llm.ainvoke(messages)
        resposta_texto = response.content

        # Metadados de uso (podem não estar disponíveis em todos os modelos)
        usage = getattr(response, "usage_metadata", None)
        tokens = {}
        if usage:
            tokens = {
                "prompt":     getattr(usage, "input_tokens", 0),
                "completion": getattr(usage, "output_tokens", 0),
            }

        return {
            "resposta":      resposta_texto,
            "modelo":        OLLAMA_MODEL,
            "tokens_usados": tokens,
            "erro":          None,
        }

    except Exception as exc:
        logger.error("Erro ao consultar Ollama: %s", exc)
        return {
            "resposta":      None,
            "modelo":        OLLAMA_MODEL,
            "tokens_usados": {},
            "erro":          str(exc),
        }


async def verificar_ollama_disponivel() -> dict:
    """Verifica se o Ollama está acessível (usado no health-check)."""
    try:
        llm = get_ollama_llm()
        resp = await llm.ainvoke([HumanMessage(content="ping")])
        return {"disponivel": True, "modelo": OLLAMA_MODEL, "resposta_teste": resp.content[:80]}
    except Exception as exc:
        return {"disponivel": False, "modelo": OLLAMA_MODEL, "erro": str(exc)}
